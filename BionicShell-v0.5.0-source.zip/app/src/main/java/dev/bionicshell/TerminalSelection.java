package dev.bionicshell;

public final class TerminalSelection {
    private int mStartLine;
    private int mStartCol;
    private int mEndLine;
    private int mEndCol;
    private boolean mActive;

    public void set(int startLine, int startCol, int endLine, int endCol) {
        mStartLine = startLine;
        mStartCol = startCol;
        mEndLine = endLine;
        mEndCol = endCol;
        mActive = true;
        normalize();
    }

    public void clear() {
        mActive = false;
        mStartLine = 0;
        mStartCol = 0;
        mEndLine = 0;
        mEndCol = 0;
    }

    public boolean isActive() {
        return mActive;
    }

    public boolean isEmpty() {
        return !mActive || (mStartLine == mEndLine && mStartCol == mEndCol);
    }

    public boolean contains(int line, int col) {
        if (isEmpty()) {
            return false;
        }
        if (line < mStartLine || line > mEndLine) {
            return false;
        }
        if (line == mStartLine && col < mStartCol) {
            return false;
        }
        if (line == mEndLine && col >= mEndCol) {
            return false;
        }
        return true;
    }

    public int getStartLine() {
        return mStartLine;
    }

    public int getStartCol() {
        return mStartCol;
    }

    public int getEndLine() {
        return mEndLine;
    }

    public int getEndCol() {
        return mEndCol;
    }

    private void normalize() {
        if (mStartLine > mEndLine || (mStartLine == mEndLine && mStartCol > mEndCol)) {
            int line = mStartLine;
            int col = mStartCol;
            mStartLine = mEndLine;
            mStartCol = mEndCol;
            mEndLine = line;
            mEndCol = col;
        }
    }
}
