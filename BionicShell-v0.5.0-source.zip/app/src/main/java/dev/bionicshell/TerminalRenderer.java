package dev.bionicshell;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.DisplayMetrics;

public final class TerminalRenderer {
    public static final int DEFAULT_FG = 0xffe6e6e6;
    public static final int DEFAULT_BG = 0xff101010;
    public static final int SELECT_BG = 0xff264f78;
    public static final int CURSOR = 0xffd0d0d0;

    private static final int[] PALETTE = new int[] {
            0xff000000, 0xffcd3131, 0xff0dbc79, 0xffe5e510,
            0xff2472c8, 0xffbc3fbc, 0xff11a8cd, 0xffe5e5e5,
            0xff666666, 0xfff14c4c, 0xff23d18b, 0xfff5f543,
            0xff3b8eea, 0xffd670d6, 0xff29b8db, 0xffffffff
    };

    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float mCharWidth;
    private final float mLineHeight;
    private final float mAscent;

    public TerminalRenderer(Context context) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        mPaint.setTypeface(Typeface.MONOSPACE);
        mPaint.setTextSize(14.0f * metrics.scaledDensity);
        mPaint.setStyle(Paint.Style.FILL);
        mCharWidth = mPaint.measureText("M");
        mLineHeight = -mPaint.ascent() + mPaint.descent();
        mAscent = -mPaint.ascent();
    }

    public float getCharWidth() {
        return mCharWidth;
    }

    public float getLineHeight() {
        return mLineHeight;
    }

    public void render(Canvas canvas, ScreenBuffer buffer, int topLine,
                       TerminalSelection selection, boolean drawCursor) {
        canvas.drawColor(DEFAULT_BG);
        int rows = buffer.getRows();
        int cols = buffer.getColumns();
        int lineCount = buffer.getLineCount();
        int start = Math.max(0, topLine);
        int cursorLine = buffer.getCursorRow() + buffer.getVisibleStart();
        int cursorCol = buffer.getCursorCol();
        boolean showCursor = drawCursor && buffer.isCursorVisible();
        for (int row = 0; row < rows; row++) {
            int line = start + row;
            if (line >= lineCount) {
                break;
            }
            float y = (row * mLineHeight) + mAscent;
            for (int col = 0; col < cols; col++) {
                int flags = buffer.getFlagsAt(line, col);
                int codePoint = buffer.getCodePointAt(line, col);
                if (codePoint == 0 && (flags & ScreenBuffer.FLAG_WIDE) != 0) {
                    continue;
                }
                int cells = (flags & ScreenBuffer.FLAG_WIDE) != 0 ? 2 : 1;
                boolean selected = selection != null && selection.contains(line, col);
                boolean cursor = showCursor && line == cursorLine && col == cursorCol;
                int fg = color(buffer.getFgAt(line, col), DEFAULT_FG);
                int bg = color(buffer.getBgAt(line, col), DEFAULT_BG);
                if ((flags & ScreenBuffer.FLAG_REVERSE) != 0) {
                    int temp = fg;
                    fg = bg;
                    bg = temp;
                }
                if ((flags & ScreenBuffer.FLAG_BOLD) != 0) {
                    fg = brighten(fg);
                }
                if (selected) {
                    bg = SELECT_BG;
                }
                if (cursor) {
                    fg = DEFAULT_BG;
                    bg = CURSOR;
                }
                float x = col * mCharWidth;
                float width = cells * mCharWidth;
                if (bg != DEFAULT_BG || selected || cursor) {
                    mPaint.setColor(bg);
                    canvas.drawRect(x, row * mLineHeight, x + width,
                            (row + 1) * mLineHeight, mPaint);
                }
                if (codePoint != 0) {
                    mPaint.setColor(fg);
                    mPaint.setFakeBoldText((flags & ScreenBuffer.FLAG_BOLD) != 0);
                    mPaint.setUnderlineText(false);
                    canvas.drawText(new String(Character.toChars(codePoint)), x, y, mPaint);
                }
                if ((flags & ScreenBuffer.FLAG_UNDERLINE) != 0) {
                    mPaint.setColor(fg);
                    mPaint.setStrokeWidth(1.0f);
                    canvas.drawLine(x, row * mLineHeight + mLineHeight - 2.0f,
                            x + width, row * mLineHeight + mLineHeight - 2.0f, mPaint);
                }
            }
        }
        mPaint.setFakeBoldText(false);
        mPaint.setUnderlineText(false);
    }

    private static int color(int value, int fallback) {
        if (value == ScreenBuffer.DEFAULT_FG || value == ScreenBuffer.DEFAULT_BG) {
            return fallback;
        }
        if ((value & 0xff000000) == ScreenBuffer.COLOR_RGB) {
            return 0xff000000 | (value & 0x00ffffff);
        }
        if (value >= 0 && value < 16) {
            return PALETTE[value];
        }
        if (value >= 16 && value < 232) {
            int index = value - 16;
            int r = index / 36;
            int g = (index / 6) % 6;
            int b = index % 6;
            return 0xff000000 | (cube(r) << 16) | (cube(g) << 8) | cube(b);
        }
        if (value >= 232 && value < 256) {
            int level = 8 + ((value - 232) * 10);
            return 0xff000000 | (level << 16) | (level << 8) | level;
        }
        return fallback;
    }

    private static int cube(int value) {
        return value == 0 ? 0 : 55 + value * 40;
    }

    private static int brighten(int color) {
        int r = Math.min(255, ((color >> 16) & 0xff) + 32);
        int g = Math.min(255, ((color >> 8) & 0xff) + 32);
        int b = Math.min(255, (color & 0xff) + 32);
        return 0xff000000 | (r << 16) | (g << 8) | b;
    }
}
