package dev.bionicshell;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class ModelRepository {
    private ModelRepository() {
    }

    public static File modelsDir(Context context) {
        return RuntimePaths.models(context);
    }

    public static List<ModelInfo> list(Context context) {
        File dir = modelsDir(context);
        if (!dir.isDirectory() && !dir.mkdirs()) {
            return new ArrayList<ModelInfo>();
        }
        File[] files = dir.listFiles();
        List<ModelInfo> result = new ArrayList<ModelInfo>();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                File file = files[i];
                if (file.isFile() && file.getName().toLowerCase(Locale.US).endsWith(".gguf")) {
                    result.add(new ModelInfo(file));
                }
            }
        }
        Collections.sort(result, new Comparator<ModelInfo>() {
            public int compare(ModelInfo first, ModelInfo second) {
                return first.getName().compareToIgnoreCase(second.getName());
            }
        });
        return result;
    }

    public static ModelInfo importFromUri(Context context, Uri uri, String displayName)
            throws IOException {
        File dir = modelsDir(context);
        if (!dir.isDirectory() && !dir.mkdirs()) {
            throw new IOException("cannot create models directory");
        }
        InputStream input = context.getContentResolver().openInputStream(uri);
        if (input == null) {
            throw new IOException("cannot open model URI");
        }
        File temporary = new File(dir, ".import-" + System.nanoTime() + ".part");
        File target = null;
        FileOutputStream output = null;
        try {
            output = new FileOutputStream(temporary);
            byte[] buffer = new byte[65536];
            while (true) {
                int count = input.read(buffer);
                if (count < 0) {
                    break;
                }
                if (count > 0) {
                    output.write(buffer, 0, count);
                }
            }
            output.flush();
            output.close();
            output = null;
            target = uniqueTarget(dir, safeName(displayName));
            if (!temporary.renameTo(target)) {
                throw new IOException("cannot move imported model into place");
            }
        } catch (IOException exception) {
            deleteQuietly(temporary);
            if (target != null && target.exists()) {
                deleteQuietly(target);
            }
            throw exception;
        } finally {
            try {
                input.close();
            } catch (IOException ignored) {
            }
            if (output != null) {
                try {
                    output.close();
                } catch (IOException ignored) {
                }
            }
        }
        return new ModelInfo(target);
    }

    public static String safeName(String displayName) {
        String value = displayName == null ? "" : displayName;
        int slash = Math.max(value.lastIndexOf('/'), value.lastIndexOf('\\'));
        if (slash >= 0) {
            value = value.substring(slash + 1);
        }
        value = value.replaceAll("[^A-Za-z0-9._-]", "_");
        if (value.length() == 0) {
            value = "model.gguf";
        }
        if (!value.toLowerCase(Locale.US).endsWith(".gguf")) {
            value = value + ".gguf";
        }
        if (value.length() > 120) {
            value = value.substring(0, 115) + ".gguf";
        }
        return value;
    }

    private static File uniqueTarget(File dir, String name) {
        File target = new File(dir, name);
        if (!target.exists()) {
            return target;
        }
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String extension = dot > 0 ? name.substring(dot) : "";
        int suffix = 1;
        while (true) {
            target = new File(dir, base + "-" + suffix + extension);
            if (!target.exists()) {
                return target;
            }
            suffix++;
        }
    }

    private static void deleteQuietly(File file) {
        if (file != null && file.exists()) {
            file.delete();
        }
    }

    public static final class ModelInfo {
        private final File mFile;
        private final String mName;
        private final long mSize;

        ModelInfo(File file) {
            mFile = file;
            mName = file.getName();
            mSize = file.length();
        }

        public File getFile() {
            return mFile;
        }

        public String getName() {
            return mName;
        }

        public long getSize() {
            return mSize;
        }
    }
}
