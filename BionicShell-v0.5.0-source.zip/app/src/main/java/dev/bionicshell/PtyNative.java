package dev.bionicshell;

public final class PtyNative {
    static {
        System.loadLibrary("pty");
    }

    private PtyNative() {
    }

    public static native int open(String[] argv, String[] envp, String cwd, int rows, int cols, int[] pidOut);

    public static native void resize(int fd, int rows, int cols);

    public static native void close(int fd);

    public static native void signal(int pid, int signal);

    public static native int waitFor(int pid);
}
