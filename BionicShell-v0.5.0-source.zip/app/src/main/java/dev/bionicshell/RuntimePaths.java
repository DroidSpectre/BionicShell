package dev.bionicshell;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public final class RuntimePaths {
    private RuntimePaths() {
    }

    public static File home(Context context) {
        return context.getFilesDir();
    }

    public static File models(Context context) {
        return new File(home(context), "models");
    }

    public static File logs(Context context) {
        return new File(home(context), "logs");
    }

    public static File tmp(Context context) {
        return new File(home(context), "tmp");
    }

    public static void ensure(Context context) throws IOException {
        File[] dirs = new File[] { home(context), models(context), logs(context), tmp(context) };
        for (int i = 0; i < dirs.length; i++) {
            File dir = dirs[i];
            if (!dir.isDirectory() && !dir.mkdirs()) {
                throw new IOException("cannot create " + dir.getAbsolutePath());
            }
        }
        if (!home(context).canWrite()) {
            throw new IOException("home is not writable: " + home(context).getAbsolutePath());
        }
        writeMkshrc(context);
    }

    public static String[] environment(Context context) {
        String nativeDir = context.getApplicationInfo().nativeLibraryDir;
        String home = home(context).getAbsolutePath();
        return new String[] {
                "HOME=" + home,
                "TMPDIR=" + tmp(context).getAbsolutePath(),
                "PATH=/system/bin",
                "SHELL=/system/bin/sh",
                "TERM=xterm-256color",
                "LANG=C.UTF-8",
                "LD_LIBRARY_PATH=" + nativeDir,
                "ENV=" + new File(home(context), ".mkshrc").getAbsolutePath(),
                "PWD=" + home,
                "PS1=$ "
        };
    }

    public static void writeMkshrc(Context context) throws IOException {
        String nativeDir = context.getApplicationInfo().nativeLibraryDir;
        String content = "umask 077\n"
                + "PS1='$ '\n"
                + "export PS1\n"
                + "alias llama-cli='" + nativeDir + "/liblauncher.so llama-cli'\n"
                + "alias llama-server='" + nativeDir + "/liblauncher.so llama-server'\n"
                + "alias ll='ls -al'\n";
        File target = new File(home(context), ".mkshrc");
        FileOutputStream output = new FileOutputStream(target);
        Writer writer = new OutputStreamWriter(output, "UTF-8");
        try {
            writer.write(content);
            writer.flush();
        } finally {
            writer.close();
        }
    }
}
