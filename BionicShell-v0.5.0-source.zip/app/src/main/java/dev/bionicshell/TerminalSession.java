package dev.bionicshell;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.system.OsConstants;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public final class TerminalSession {
    public interface Listener {
        void onScreenChanged();

        void onExit(int status);
    }

    private final ScreenBuffer mBuffer;
    private final AnsiParser mParser;
    private final Object mBufferLock = new Object();
    private final Object mWriteLock = new Object();
    private final ParcelFileDescriptor mPty;
    private final InputStream mInput;
    private final OutputStream mOutput;
    private final int mPid;
    private final Handler mMainHandler;
    private final Thread mReader;
    private volatile boolean mRunning = true;
    private volatile boolean mScreenPosted;
    private volatile Listener mListener;

    private TerminalSession(ParcelFileDescriptor pty, int pid, int rows, int cols, Listener listener)
            throws IOException {
        mPty = pty;
        mPid = pid;
        mBuffer = new ScreenBuffer(rows, cols);
        mParser = new AnsiParser(mBuffer);
        mInput = new FileInputStream(pty.getFileDescriptor());
        mOutput = new FileOutputStream(pty.getFileDescriptor());
        mListener = listener;
        mMainHandler = new Handler(Looper.getMainLooper());
        mReader = new Thread(new Runnable() {
            public void run() {
                readLoop();
            }
        }, "bionicshell-pty");
        mReader.start();
    }

    public static TerminalSession start(Context context, int rows, int cols, Listener listener)
            throws IOException {
        RuntimePaths.ensure(context);
        int safeRows = Math.max(4, rows);
        int safeCols = Math.max(20, cols);
        int[] pid = new int[1];
        int fd;
        try {
            fd = PtyNative.open(
                    new String[] { "/system/bin/sh", "-i" },
                    RuntimePaths.environment(context),
                    RuntimePaths.home(context).getAbsolutePath(),
                    safeRows,
                    safeCols,
                    pid);
        } catch (LinkageError error) {
            throw new IOException("native PTY library is unavailable", error);
        }
        if (fd < 0 || pid[0] <= 0) {
            throw new IOException("cannot start PTY");
        }
        ParcelFileDescriptor pty = ParcelFileDescriptor.adoptFd(fd);
        return new TerminalSession(pty, pid[0], safeRows, safeCols, listener);
    }

    public void write(byte[] bytes) {
        if (bytes == null || bytes.length == 0 || !mRunning) {
            return;
        }
        try {
            synchronized (mWriteLock) {
                mOutput.write(bytes);
                mOutput.flush();
            }
        } catch (IOException exception) {
            close();
        }
    }

    public void resize(int rows, int cols) {
        int safeRows = Math.max(4, rows);
        int safeCols = Math.max(20, cols);
        synchronized (mBufferLock) {
            if (!mRunning) {
                return;
            }
            PtyNative.resize(mPty.getFd(), safeRows, safeCols);
            mBuffer.resize(safeRows, safeCols);
        }
        notifyScreen();
    }

    public void close() {
        if (!mRunning) {
            return;
        }
        mRunning = false;
        PtyNative.signal(mPid, OsConstants.SIGHUP);
        try {
            mPty.close();
        } catch (IOException ignored) {
        }
        mReader.interrupt();
    }

    public boolean isRunning() {
        return mRunning;
    }

    public int getPid() {
        return mPid;
    }

    public ScreenBuffer getBuffer() {
        return mBuffer;
    }

    public Object getBufferLock() {
        return mBufferLock;
    }

    public void setListener(Listener listener) {
        mListener = listener;
    }

    private void readLoop() {
        byte[] buffer = new byte[4096];
        try {
            while (mRunning) {
                int count = mInput.read(buffer);
                if (count < 0) {
                    break;
                }
                if (count > 0) {
                    synchronized (mBufferLock) {
                        mParser.append(buffer, 0, count);
                    }
                    notifyScreen();
                }
            }
        } catch (IOException ignored) {
        } finally {
            int status = PtyNative.waitFor(mPid);
            finish(status);
        }
    }

    private void notifyScreen() {
        if (mScreenPosted || !mRunning) {
            return;
        }
        mScreenPosted = true;
        mMainHandler.post(new Runnable() {
            public void run() {
                mScreenPosted = false;
                Listener listener = mListener;
                if (listener != null) {
                    listener.onScreenChanged();
                }
            }
        });
    }

    private void finish(int status) {
        boolean notify;
        synchronized (this) {
            notify = mRunning;
            mRunning = false;
        }
        if (notify) {
            final int exitStatus = status;
            mMainHandler.post(new Runnable() {
                public void run() {
                    Listener listener = mListener;
                    if (listener != null) {
                        listener.onExit(exitStatus);
                    }
                }
            });
        }
    }
}
