package dev.bionicshell;

import java.util.ArrayList;

public final class ScreenBuffer {
    public static final int DEFAULT_FG = -1;
    public static final int DEFAULT_BG = -1;
    public static final int FLAG_BOLD = 1;
    public static final int FLAG_UNDERLINE = 2;
    public static final int FLAG_REVERSE = 4;
    public static final int FLAG_WIDE = 8;
    public static final int COLOR_RGB = 0x01000000;
    public static final int DEFAULT_SCROLLBACK_ROWS = 2000;

    private int mRows;
    private int mCols;
    private final int mScrollbackLimit;
    private final ArrayList<Row> mMain = new ArrayList<Row>();
    private final ArrayList<Row> mAlt = new ArrayList<Row>();
    private boolean mAltActive;
    private int mCursorRow;
    private int mCursorCol;
    private boolean mWrapPending;
    private boolean mAutowrap = true;
    private boolean mCursorVisible = true;
    private boolean mBracketedPaste;
    private boolean mApplicationCursorKeys;
    private int mScrollTop;
    private int mScrollBottom;
    private int mFg = DEFAULT_FG;
    private int mBg = DEFAULT_BG;
    private int mFlags;
    private int mSavedRow;
    private int mSavedCol;
    private int mSavedFg;
    private int mSavedBg;
    private int mSavedFlags;
    private String mTitle = "";

    public ScreenBuffer(int rows, int cols) {
        this(rows, cols, DEFAULT_SCROLLBACK_ROWS);
    }

    public ScreenBuffer(int rows, int cols, int scrollbackLimit) {
        mRows = Math.max(1, rows);
        mCols = Math.max(1, cols);
        mScrollbackLimit = Math.max(0, scrollbackLimit);
        mScrollTop = 0;
        mScrollBottom = mRows - 1;
        clearMain();
    }

    private void clearMain() {
        mMain.clear();
        for (int i = 0; i < mRows; i++) {
            mMain.add(new Row(mCols));
        }
        mCursorRow = 0;
        mCursorCol = 0;
        mWrapPending = false;
    }

    public int getRows() {
        return mRows;
    }

    public int getColumns() {
        return mCols;
    }

    public int getCursorRow() {
        return mCursorRow;
    }

    public int getCursorCol() {
        return mCursorCol;
    }

    public boolean isCursorVisible() {
        return mCursorVisible;
    }

    public boolean isAltScreen() {
        return mAltActive;
    }

    public boolean isBracketedPaste() {
        return mBracketedPaste;
    }

    public boolean isApplicationCursorKeys() {
        return mApplicationCursorKeys;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title == null ? "" : title;
    }

    public int getFg() {
        return mFg;
    }

    public int getBg() {
        return mBg;
    }

    public int getFlags() {
        return mFlags;
    }

    public void setStyle(int fg, int bg, int flags) {
        mFg = fg;
        mBg = bg;
        mFlags = flags;
    }

    public void resetStyle() {
        mFg = DEFAULT_FG;
        mBg = DEFAULT_BG;
        mFlags = 0;
    }

    public void setAutowrap(boolean autowrap) {
        mAutowrap = autowrap;
    }

    public void setCursorVisible(boolean visible) {
        mCursorVisible = visible;
    }

    public void setBracketedPaste(boolean enabled) {
        mBracketedPaste = enabled;
    }

    public void setApplicationCursorKeys(boolean enabled) {
        mApplicationCursorKeys = enabled;
    }

    public void setCursor(int row, int col) {
        mCursorRow = clamp(row, 0, mRows - 1);
        mCursorCol = clamp(col, 0, mCols - 1);
        mWrapPending = false;
    }

    public void putChar(int codePoint) {
        int width = widthOf(codePoint);
        if (width == 0) {
            return;
        }
        if (mWrapPending) {
            currentRow().wrapped = true;
            mCursorCol = 0;
            lineFeed();
            mWrapPending = false;
        }
        if (width == 2 && mCursorCol >= mCols - 1) {
            if (mAutowrap) {
                currentRow().wrapped = true;
                mCursorCol = 0;
                lineFeed();
            } else {
                mCursorCol = Math.max(0, mCols - 2);
            }
        }
        Row row = currentRow();
        row.cps[mCursorCol] = codePoint;
        row.fg[mCursorCol] = mFg;
        row.bg[mCursorCol] = mBg;
        row.flags[mCursorCol] = (byte) (mFlags & ~FLAG_WIDE);
        if (width == 2 && mCursorCol + 1 < mCols) {
            row.cps[mCursorCol] = codePoint;
            row.flags[mCursorCol] = (byte) (mFlags | FLAG_WIDE);
            row.cps[mCursorCol + 1] = 0;
            row.fg[mCursorCol + 1] = mFg;
            row.bg[mCursorCol + 1] = mBg;
            row.flags[mCursorCol + 1] = (byte) (mFlags | FLAG_WIDE);
        }
        mCursorCol += width;
        if (mCursorCol >= mCols) {
            if (mAutowrap) {
                mCursorCol = mCols - 1;
                mWrapPending = true;
            } else {
                mCursorCol = mCols - 1;
            }
        }
    }

    public void carriageReturn() {
        mCursorCol = 0;
        mWrapPending = false;
    }

    public void lineFeed() {
        mWrapPending = false;
        if (mCursorRow == mScrollBottom) {
            scrollUp(1);
        } else if (mCursorRow < mRows - 1) {
            mCursorRow++;
        }
    }

    public void backspace() {
        mWrapPending = false;
        if (mCursorCol > 0) {
            mCursorCol--;
        }
    }

    public void tab() {
        mWrapPending = false;
        int next = ((mCursorCol / 8) + 1) * 8;
        mCursorCol = Math.min(mCols - 1, next);
    }

    public void eraseInLine(int mode) {
        Row row = currentRow();
        if (mode == 0) {
            row.clearRange(mCursorCol, mCols);
        } else if (mode == 1) {
            row.clearRange(0, mCursorCol + 1);
        } else if (mode == 2) {
            row.clearRange(0, mCols);
        }
    }

    public void eraseInDisplay(int mode) {
        if (mode == 0) {
            eraseInLine(0);
            for (int r = mCursorRow + 1; r < mRows; r++) {
                lineAt(r).clearRange(0, mCols);
            }
        } else if (mode == 1) {
            eraseInLine(1);
            for (int r = 0; r < mCursorRow; r++) {
                lineAt(r).clearRange(0, mCols);
            }
        } else if (mode == 2) {
            for (int r = 0; r < mRows; r++) {
                lineAt(r).clearRange(0, mCols);
            }
        } else if (mode == 3) {
            if (!mAltActive && mMain.size() > mRows) {
                while (mMain.size() > mRows) {
                    mMain.remove(0);
                }
            }
        }
    }

    public void eraseChars(int count) {
        Row row = currentRow();
        int end = Math.min(mCols, mCursorCol + Math.max(1, count));
        row.clearRange(mCursorCol, end);
    }

    public void insertChars(int count) {
        int amount = Math.min(Math.max(1, count), mCols - mCursorCol);
        Row row = currentRow();
        for (int i = mCols - 1; i >= mCursorCol + amount; i--) {
            row.copyFrom(i - amount, i);
        }
        row.clearRange(mCursorCol, mCursorCol + amount);
        mWrapPending = false;
    }

    public void deleteChars(int count) {
        int amount = Math.min(Math.max(1, count), mCols - mCursorCol);
        Row row = currentRow();
        for (int i = mCursorCol; i < mCols - amount; i++) {
            row.copyFrom(i + amount, i);
        }
        row.clearRange(mCols - amount, mCols);
        mWrapPending = false;
    }

    public void insertLines(int count) {
        if (mCursorRow < mScrollTop || mCursorRow > mScrollBottom) {
            return;
        }
        int amount = Math.min(Math.max(1, count), mScrollBottom - mCursorRow + 1);
        for (int i = 0; i < amount; i++) {
            removeVisibleRow(mScrollBottom);
            insertVisibleRow(mCursorRow, new Row(mCols));
        }
        mWrapPending = false;
    }

    public void deleteLines(int count) {
        if (mCursorRow < mScrollTop || mCursorRow > mScrollBottom) {
            return;
        }
        int amount = Math.min(Math.max(1, count), mScrollBottom - mCursorRow + 1);
        for (int i = 0; i < amount; i++) {
            removeVisibleRow(mCursorRow);
            insertVisibleRow(mScrollBottom, new Row(mCols));
        }
        mWrapPending = false;
    }

    public void scrollUp(int count) {
        int amount = Math.max(1, count);
        for (int i = 0; i < amount; i++) {
            if (mAltActive) {
                if (mAlt.size() > 0) {
                    mAlt.remove(0);
                    mAlt.add(new Row(mCols));
                }
            } else if (mScrollTop == 0 && mScrollBottom == mRows - 1) {
                mMain.add(new Row(mCols));
                trimScrollback();
            } else {
                removeVisibleRow(mScrollTop);
                insertVisibleRow(mScrollBottom, new Row(mCols));
            }
        }
    }

    public void scrollDown(int count) {
        int amount = Math.max(1, count);
        for (int i = 0; i < amount; i++) {
            removeVisibleRow(mScrollBottom);
            insertVisibleRow(mScrollTop, new Row(mCols));
        }
    }

    public void setScrollRegion(int top, int bottom) {
        int t = clamp(top, 0, mRows - 1);
        int b = clamp(bottom, 0, mRows - 1);
        if (t < b) {
            mScrollTop = t;
            mScrollBottom = b;
        } else {
            mScrollTop = 0;
            mScrollBottom = mRows - 1;
        }
        mCursorRow = 0;
        mCursorCol = 0;
        mWrapPending = false;
    }

    public void saveCursor() {
        mSavedRow = mCursorRow;
        mSavedCol = mCursorCol;
        mSavedFg = mFg;
        mSavedBg = mBg;
        mSavedFlags = mFlags;
    }

    public void restoreCursor() {
        mCursorRow = clamp(mSavedRow, 0, mRows - 1);
        mCursorCol = clamp(mSavedCol, 0, mCols - 1);
        mFg = mSavedFg;
        mBg = mSavedBg;
        mFlags = mSavedFlags;
        mWrapPending = false;
    }

    public void enterAltScreen() {
        saveCursor();
        mAlt.clear();
        for (int i = 0; i < mRows; i++) {
            mAlt.add(new Row(mCols));
        }
        mAltActive = true;
        mCursorRow = 0;
        mCursorCol = 0;
        mScrollTop = 0;
        mScrollBottom = mRows - 1;
        mWrapPending = false;
    }

    public void leaveAltScreen() {
        mAltActive = false;
        mScrollTop = 0;
        mScrollBottom = mRows - 1;
        restoreCursor();
    }

    public void resize(int rows, int cols) {
        int newRows = Math.max(1, rows);
        int newCols = Math.max(1, cols);
        if (newCols != mCols) {
            if (mAltActive) {
                resizeAltReflow(newRows, newCols);
            } else {
                resizeMainReflow(newRows, newCols);
            }
        } else if (mAltActive) {
            mRows = newRows;
            mCols = newCols;
            while (mAlt.size() < mRows) {
                mAlt.add(new Row(mCols));
            }
            while (mAlt.size() > mRows) {
                mAlt.remove(mAlt.size() - 1);
            }
            mCursorRow = clamp(mCursorRow, 0, mRows - 1);
            mCursorCol = clamp(mCursorCol, 0, mCols - 1);
            mWrapPending = false;
        } else {
            int oldVisible = visibleStart();
            int cursorAbsolute = oldVisible + mCursorRow;
            if (newRows > mMain.size()) {
                int pad = newRows - mMain.size();
                for (int i = 0; i < pad; i++) {
                    mMain.add(0, new Row(newCols));
                }
                cursorAbsolute += pad;
            }
            mRows = newRows;
            mCols = newCols;
            trimScrollback();
            int visible = visibleStart();
            mCursorRow = clamp(cursorAbsolute - visible, 0, mRows - 1);
            mCursorCol = clamp(mCursorCol, 0, mCols - 1);
            mWrapPending = false;
        }
        mScrollTop = 0;
        mScrollBottom = mRows - 1;
    }

    private void resizeMainReflow(int newRows, int newCols) {
        int oldVisibleStart = visibleStart();
        int cursorAbs = oldVisibleStart + mCursorRow;
        CursorMap map = cursorMap(mMain, cursorAbs);
        ArrayList<LogicalLine> lines = logicalLines(mMain);
        ReflowResult result = rewrap(lines, newCols, map);

        int drop = 0;
        int maxRows = newRows + mScrollbackLimit;
        while (result.rows.size() > maxRows) {
            result.rows.remove(0);
            drop++;
        }
        while (result.rows.size() < newRows) {
            result.rows.add(new Row(newCols));
        }

        mRows = newRows;
        mCols = newCols;
        mMain.clear();
        mMain.addAll(result.rows);
        int visible = visibleStart();
        mCursorRow = clamp(result.cursorRow - drop - visible, 0, mRows - 1);
        mCursorCol = clamp(result.cursorCol, 0, mCols - 1);
        mWrapPending = result.wrapPending;
    }

    private void resizeAltReflow(int newRows, int newCols) {
        CursorMap map = cursorMap(mAlt, mCursorRow);
        ArrayList<LogicalLine> lines = logicalLines(mAlt);
        ReflowResult result = rewrap(lines, newCols, map);
        int drop = 0;
        while (result.rows.size() > newRows) {
            result.rows.remove(0);
            drop++;
        }
        while (result.rows.size() < newRows) {
            result.rows.add(new Row(newCols));
        }
        mRows = newRows;
        mCols = newCols;
        mAlt.clear();
        mAlt.addAll(result.rows);
        mCursorRow = clamp(result.cursorRow - drop, 0, mRows - 1);
        mCursorCol = clamp(result.cursorCol, 0, mCols - 1);
        mWrapPending = result.wrapPending;
    }

    private CursorMap cursorMap(ArrayList<Row> rows, int cursorAbs) {
        CursorMap map = new CursorMap();
        int line = 0;
        int offset = 0;
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int end = rowContentEnd(row);
            if (i == cursorAbs) {
                map.line = line;
                map.offset = offset + Math.min(mCursorCol, end);
                map.pending = mWrapPending;
                map.found = true;
                return map;
            }
            offset += end;
            if (!row.wrapped) {
                line++;
                offset = 0;
            }
        }
        map.line = Math.max(0, line - 1);
        map.offset = offset;
        map.pending = mWrapPending;
        return map;
    }

    private ArrayList<LogicalLine> logicalLines(ArrayList<Row> rows) {
        ArrayList<LogicalLine> result = new ArrayList<LogicalLine>();
        LogicalLine current = new LogicalLine();
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int end = rowContentEnd(row);
            for (int col = 0; col < end; col++) {
                current.add(row.cps[col], row.fg[col], row.bg[col], row.flags[col]);
            }
            if (!row.wrapped) {
                result.add(current);
                current = new LogicalLine();
            }
        }
        if (current.size > 0 || result.isEmpty()) {
            result.add(current);
        }
        return result;
    }

    private int rowContentEnd(Row row) {
        if (row.wrapped) {
            return mCols;
        }
        int end = mCols;
        while (end > 0 && row.isBlank(end - 1)) {
            end--;
        }
        return end;
    }

    private ReflowResult rewrap(ArrayList<LogicalLine> lines, int cols, CursorMap map) {
        ReflowResult result = new ReflowResult();
        boolean cursorFound = false;
        for (int li = 0; li < lines.size(); li++) {
            LogicalLine line = lines.get(li);
            if (line.size == 0) {
                int rowIndex = result.rows.size();
                result.rows.add(new Row(cols));
                if (!cursorFound && map.found && map.line == li) {
                    result.cursorRow = rowIndex;
                    result.cursorCol = 0;
                    cursorFound = true;
                }
                continue;
            }
            int pos = 0;
            while (pos < line.size) {
                int chunkStart = pos;
                Row row = new Row(cols);
                int col = 0;
                while (pos < line.size && col < cols) {
                    int width = widthOf(line.cps[pos]);
                    if (width == 0) {
                        pos++;
                        continue;
                    }
                    if (width == 2 && col == cols - 1) {
                        break;
                    }
                    row.cps[col] = line.cps[pos];
                    row.fg[col] = line.fg[pos];
                    row.bg[col] = line.bg[pos];
                    row.flags[col] = line.flags[pos];
                    if (width == 2 && col + 1 < cols) {
                        row.cps[col] = line.cps[pos];
                        row.flags[col] = (byte) (line.flags[pos] | FLAG_WIDE);
                        row.cps[col + 1] = 0;
                        row.fg[col + 1] = line.fg[pos];
                        row.bg[col + 1] = line.bg[pos];
                        row.flags[col + 1] = (byte) (line.flags[pos] | FLAG_WIDE);
                    }
                    pos++;
                    col += width;
                }
                boolean more = pos < line.size;
                row.wrapped = more;
                int rowIndex = result.rows.size();
                result.rows.add(row);
                if (!cursorFound && map.found && map.line == li) {
                    if (map.offset < pos || !more) {
                        int mapped = map.offset - chunkStart;
                        if (mapped < 0) {
                            mapped = 0;
                        }
                        if (mapped > cols - 1) {
                            mapped = cols - 1;
                        }
                        int flagIndex = chunkStart + mapped;
                        if (mapped > 0 && flagIndex < line.size
                                && (line.flags[flagIndex] & FLAG_WIDE) != 0) {
                            mapped--;
                        }
                        result.cursorRow = rowIndex;
                        result.cursorCol = mapped;
                        result.wrapPending = map.pending && !more;
                        cursorFound = true;
                    }
                }
            }
        }
        if (!cursorFound) {
            result.cursorRow = Math.max(0, result.rows.size() - 1);
            result.cursorCol = 0;
            result.wrapPending = false;
        }
        return result;
    }

    public void reset() {
        mAltActive = false;
        mAlt.clear();
        clearMain();
        mRows = Math.max(1, mRows);
        mScrollTop = 0;
        mScrollBottom = mRows - 1;
        mAutowrap = true;
        mCursorVisible = true;
        mBracketedPaste = false;
        mApplicationCursorKeys = false;
        mFg = DEFAULT_FG;
        mBg = DEFAULT_BG;
        mFlags = 0;
        mTitle = "";
    }

    public int getVisibleStart() {
        return mAltActive ? 0 : visibleStart();
    }

    public int getLineCount() {
        return mAltActive ? mAlt.size() : mMain.size();
    }

    public int getScrollbackCount() {
        return mAltActive ? 0 : Math.max(0, mMain.size() - mRows);
    }

    public int getCodePointAt(int line, int col) {
        Row row = rowAt(line);
        if (row == null || col < 0 || col >= mCols) {
            return 0;
        }
        return row.cps[col];
    }

    public int getFgAt(int line, int col) {
        Row row = rowAt(line);
        if (row == null || col < 0 || col >= mCols) {
            return DEFAULT_FG;
        }
        return row.fg[col];
    }

    public int getBgAt(int line, int col) {
        Row row = rowAt(line);
        if (row == null || col < 0 || col >= mCols) {
            return DEFAULT_BG;
        }
        return row.bg[col];
    }

    public int getFlagsAt(int line, int col) {
        Row row = rowAt(line);
        if (row == null || col < 0 || col >= mCols) {
            return 0;
        }
        return row.flags[col] & 0xff;
    }

    public boolean isWrapped(int line) {
        Row row = rowAt(line);
        return row != null && row.wrapped;
    }

    public String getLineTextAbsolute(int line) {
        Row row = rowAt(line);
        if (row == null) {
            return "";
        }
        return trimTrailing(row.text(0, mCols));
    }

    public String getVisibleLineText(int visibleRow) {
        int absolute = getVisibleStart() + clamp(visibleRow, 0, mRows - 1);
        return getLineTextAbsolute(absolute);
    }

    public String copyAll() {
        int count = getLineCount();
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < count; i++) {
            result.append(getLineTextAbsolute(i));
            if (i + 1 < count && !isWrapped(i)) {
                result.append('\n');
            }
        }
        return trimTrailing(result.toString());
    }

    public String getSelectedText(int startLine, int startCol, int endLine, int endCol) {
        int firstLine = startLine;
        int firstCol = startCol;
        int lastLine = endLine;
        int lastCol = endCol;
        if (firstLine > lastLine || (firstLine == lastLine && firstCol > lastCol)) {
            int tempLine = firstLine;
            int tempCol = firstCol;
            firstLine = lastLine;
            firstCol = lastCol;
            lastLine = tempLine;
            lastCol = tempCol;
        }
        int count = getLineCount();
        firstLine = clamp(firstLine, 0, count - 1);
        lastLine = clamp(lastLine, 0, count - 1);
        firstCol = clamp(firstCol, 0, mCols);
        lastCol = clamp(lastCol, 0, mCols);
        StringBuilder result = new StringBuilder();
        for (int i = firstLine; i <= lastLine; i++) {
            int from = i == firstLine ? firstCol : 0;
            int to = i == lastLine ? lastCol : mCols;
            Row row = rowAt(i);
            if (row != null) {
                result.append(trimTrailing(row.text(from, to)));
            }
            if (i < lastLine && !isWrapped(i)) {
                result.append('\n');
            }
        }
        return result.toString();
    }

    private int visibleStart() {
        return Math.max(0, mMain.size() - mRows);
    }

    private Row currentRow() {
        if (mAltActive) {
            if (mCursorRow >= mAlt.size()) {
                mCursorRow = mAlt.size() - 1;
            }
            return mAlt.get(mCursorRow);
        }
        return lineAt(mCursorRow);
    }

    private Row lineAt(int visibleRow) {
        if (mAltActive) {
            return mAlt.get(clamp(visibleRow, 0, mAlt.size() - 1));
        }
        int absolute = visibleStart() + clamp(visibleRow, 0, mRows - 1);
        return mMain.get(absolute);
    }

    private Row rowAt(int absoluteLine) {
        if (mAltActive) {
            if (absoluteLine < 0 || absoluteLine >= mAlt.size()) {
                return null;
            }
            return mAlt.get(absoluteLine);
        }
        if (absoluteLine < 0 || absoluteLine >= mMain.size()) {
            return null;
        }
        return mMain.get(absoluteLine);
    }

    private void removeVisibleRow(int visibleRow) {
        if (mAltActive) {
            mAlt.remove(clamp(visibleRow, 0, mAlt.size() - 1));
        } else {
            mMain.remove(visibleStart() + clamp(visibleRow, 0, mRows - 1));
        }
    }

    private void insertVisibleRow(int visibleRow, Row row) {
        if (mAltActive) {
            mAlt.add(clamp(visibleRow, 0, mAlt.size()), row);
        } else {
            mMain.add(visibleStart() + clamp(visibleRow, 0, mRows - 1), row);
        }
    }

    private void trimScrollback() {
        if (!mAltActive) {
            while (mMain.size() > mRows + mScrollbackLimit) {
                mMain.remove(0);
            }
        }
    }

    private static int clamp(int value, int min, int max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }

    private static String trimTrailing(String value) {
        int end = value.length();
        while (end > 0 && (value.charAt(end - 1) == '\n' || value.charAt(end - 1) == ' ')) {
            end--;
        }
        return value.substring(0, end);
    }

    private static int widthOf(int codePoint) {
        if (codePoint == 0x200b || (codePoint >= 0x0300 && codePoint <= 0x036f)) {
            return 0;
        }
        if ((codePoint >= 0x1100 && codePoint <= 0x115f)
                || (codePoint >= 0x2e80 && codePoint <= 0xa4cf)
                || (codePoint >= 0xac00 && codePoint <= 0xd7a3)
                || (codePoint >= 0xf900 && codePoint <= 0xfaff)
                || (codePoint >= 0xfe10 && codePoint <= 0xfe19)
                || (codePoint >= 0xff00 && codePoint <= 0xff60)
                || (codePoint >= 0xffe0 && codePoint <= 0xffe6)) {
            return 2;
        }
        return 1;
    }

    private static final class CursorMap {
        int line;
        int offset;
        boolean pending;
        boolean found;
    }

    private static final class ReflowResult {
        final ArrayList<Row> rows = new ArrayList<Row>();
        int cursorRow;
        int cursorCol;
        boolean wrapPending;
    }

    private static final class LogicalLine {
        int[] cps = new int[16];
        int[] fg = new int[16];
        int[] bg = new int[16];
        byte[] flags = new byte[16];
        int size;

        void add(int codePoint, int foreground, int background, byte flag) {
            if (size == cps.length) {
                int capacity = cps.length * 2;
                int[] newCps = new int[capacity];
                int[] newFg = new int[capacity];
                int[] newBg = new int[capacity];
                byte[] newFlags = new byte[capacity];
                System.arraycopy(cps, 0, newCps, 0, size);
                System.arraycopy(fg, 0, newFg, 0, size);
                System.arraycopy(bg, 0, newBg, 0, size);
                System.arraycopy(flags, 0, newFlags, 0, size);
                cps = newCps;
                fg = newFg;
                bg = newBg;
                flags = newFlags;
            }
            cps[size] = codePoint;
            fg[size] = foreground;
            bg[size] = background;
            flags[size] = flag;
            size++;
        }
    }

    private static final class Row {
        int[] cps;
        int[] fg;
        int[] bg;
        byte[] flags;
        boolean wrapped;

        Row(int cols) {
            cps = new int[cols];
            fg = new int[cols];
            bg = new int[cols];
            flags = new byte[cols];
            for (int i = 0; i < cols; i++) {
                fg[i] = DEFAULT_FG;
                bg[i] = DEFAULT_BG;
            }
        }

        boolean isBlank(int index) {
            return cps[index] == 0 && fg[index] == DEFAULT_FG
                    && bg[index] == DEFAULT_BG && flags[index] == 0;
        }

        void clearRange(int from, int to) {
            int start = Math.max(0, from);
            int end = Math.min(cps.length, to);
            for (int i = start; i < end; i++) {
                cps[i] = 0;
                fg[i] = DEFAULT_FG;
                bg[i] = DEFAULT_BG;
                flags[i] = 0;
            }
        }

        void copyFrom(int source, int target) {
            cps[target] = cps[source];
            fg[target] = fg[source];
            bg[target] = bg[source];
            flags[target] = flags[source];
        }

        void resize(int cols) {
            if (cols == cps.length) {
                return;
            }
            int[] newCps = new int[cols];
            int[] newFg = new int[cols];
            int[] newBg = new int[cols];
            byte[] newFlags = new byte[cols];
            int count = Math.min(cols, cps.length);
            System.arraycopy(cps, 0, newCps, 0, count);
            System.arraycopy(fg, 0, newFg, 0, count);
            System.arraycopy(bg, 0, newBg, 0, count);
            System.arraycopy(flags, 0, newFlags, 0, count);
            for (int i = count; i < cols; i++) {
                newFg[i] = DEFAULT_FG;
                newBg[i] = DEFAULT_BG;
            }
            cps = newCps;
            fg = newFg;
            bg = newBg;
            flags = newFlags;
        }

        String text(int from, int to) {
            int start = Math.max(0, from);
            int end = Math.min(cps.length, to);
            StringBuilder result = new StringBuilder();
            for (int i = start; i < end; i++) {
                if (cps[i] == 0) {
                    if ((flags[i] & FLAG_WIDE) == 0) {
                        result.append(' ');
                    }
                    continue;
                }
                result.appendCodePoint(cps[i]);
            }
            return result.toString();
        }
    }
}
