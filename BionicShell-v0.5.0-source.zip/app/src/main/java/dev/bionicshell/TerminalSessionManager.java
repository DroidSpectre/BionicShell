package dev.bionicshell;

import android.content.Context;

import java.io.IOException;

public final class TerminalSessionManager {
    private static final TerminalSessionManager INSTANCE = new TerminalSessionManager();
    private TerminalSession mSession;

    private TerminalSessionManager() {
    }

    public static TerminalSessionManager get() {
        return INSTANCE;
    }

    public synchronized TerminalSession getOrStart(Context context, int rows, int cols,
                                                    TerminalSession.Listener listener) throws IOException {
        if (mSession == null || !mSession.isRunning()) {
            mSession = TerminalSession.start(context, rows, cols, listener);
        } else {
            mSession.setListener(listener);
        }
        return mSession;
    }

    public synchronized void close() {
        if (mSession != null) {
            mSession.close();
            mSession = null;
        }
    }
}
