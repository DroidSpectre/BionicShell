package dev.bionicshell;

import java.nio.charset.Charset;

public final class AnsiParser {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int STATE_GROUND = 0;
    private static final int STATE_ESC = 1;
    private static final int STATE_ESC_INTERMEDIATE = 2;
    private static final int STATE_CSI = 3;
    private static final int STATE_OSC = 4;
    private static final int STATE_OSC_ESC = 5;
    private static final int STATE_DCS = 6;
    private static final int STATE_DCS_ESC = 7;
    private static final int MAX_OSC_LENGTH = 4096;

    private final ScreenBuffer mBuffer;
    private final byte[] mPending = new byte[4];
    private final int[] mArgs = new int[32];
    private final StringBuilder mOsc = new StringBuilder();
    private int mPendingCount;
    private int mExpected;
    private int mState;
    private int mArgCount;
    private int mCurrent;
    private boolean mHasCurrent;
    private boolean mPrivate;

    public AnsiParser(ScreenBuffer buffer) {
        if (buffer == null) {
            throw new IllegalArgumentException("buffer == null");
        }
        mBuffer = buffer;
        reset();
    }

    public ScreenBuffer getBuffer() {
        return mBuffer;
    }

    public void reset() {
        mPendingCount = 0;
        mExpected = 0;
        mState = STATE_GROUND;
        mArgCount = 0;
        mCurrent = 0;
        mHasCurrent = false;
        mPrivate = false;
        mOsc.setLength(0);
    }

    public void append(byte[] bytes) {
        if (bytes != null) {
            append(bytes, 0, bytes.length);
        }
    }

    public void append(byte[] bytes, int offset, int length) {
        if (bytes == null || offset < 0 || length <= 0 || offset > bytes.length - length) {
            return;
        }
        int end = offset + length;
        for (int i = offset; i < end; i++) {
            appendByte(bytes[i] & 0xff);
        }
    }

    private void appendByte(int value) {
        int b = value & 0xff;
        if (mPendingCount > 0) {
            if ((b & 0xc0) == 0x80) {
                mPending[mPendingCount++] = (byte) b;
                if (mPendingCount == mExpected) {
                    decodePending();
                }
                return;
            }
            mPendingCount = 0;
            mExpected = 0;
        }
        if (b < 0x80) {
            processCodePoint(b);
            return;
        }
        int expected = expectedBytes(b);
        if (expected == 0) {
            processCodePoint(0xfffd);
            return;
        }
        mPending[0] = (byte) b;
        mPendingCount = 1;
        mExpected = expected;
    }

    private void decodePending() {
        String text = new String(mPending, 0, mPendingCount, UTF8);
        mPendingCount = 0;
        mExpected = 0;
        if (text.length() > 0) {
            processCodePoint(text.codePointAt(0));
        }
    }

    private static int expectedBytes(int first) {
        if (first >= 0xc2 && first <= 0xdf) {
            return 2;
        }
        if (first >= 0xe0 && first <= 0xef) {
            return 3;
        }
        if (first >= 0xf0 && first <= 0xf4) {
            return 4;
        }
        return 0;
    }

    private void processCodePoint(int cp) {
        if (cp == 0x9b) {
            beginCsi();
            return;
        }
        if (cp == 0x9d) {
            beginOsc();
            return;
        }
        switch (mState) {
            case STATE_GROUND:
                processGround(cp);
                break;
            case STATE_ESC:
                processEscape(cp);
                break;
            case STATE_ESC_INTERMEDIATE:
                mState = STATE_GROUND;
                break;
            case STATE_CSI:
                processCsi(cp);
                break;
            case STATE_OSC:
                processOsc(cp);
                break;
            case STATE_OSC_ESC:
                if (cp == '\\') {
                    finishOsc();
                    mState = STATE_GROUND;
                } else {
                    appendOsc('\\');
                    appendOsc((char) cp);
                    mState = STATE_OSC;
                }
                break;
            case STATE_DCS:
                if (cp == 0x07) {
                    mState = STATE_GROUND;
                } else if (cp == 0x1b) {
                    mState = STATE_DCS_ESC;
                }
                break;
            case STATE_DCS_ESC:
                if (cp == '\\') {
                    mState = STATE_GROUND;
                } else {
                    mState = STATE_DCS;
                }
                break;
            default:
                mState = STATE_GROUND;
                break;
        }
    }

    private void processGround(int cp) {
        if (cp == 0x1b) {
            mState = STATE_ESC;
            return;
        }
        if (cp == 0x07) {
            return;
        }
        if (cp == 0x08) {
            mBuffer.backspace();
            return;
        }
        if (cp == 0x09) {
            mBuffer.tab();
            return;
        }
        if (cp == 0x0a || cp == 0x0b || cp == 0x0c) {
            mBuffer.lineFeed();
            return;
        }
        if (cp == 0x0d) {
            mBuffer.carriageReturn();
            return;
        }
        if (cp == 0x7f) {
            return;
        }
        if (cp >= 0x20) {
            mBuffer.putChar(cp);
        }
    }

    private void processEscape(int cp) {
        mState = STATE_GROUND;
        if (cp == '[') {
            beginCsi();
        } else if (cp == ']') {
            beginOsc();
        } else if (cp == 'P') {
            mState = STATE_DCS;
        } else if (cp == '7') {
            mBuffer.saveCursor();
        } else if (cp == '8') {
            mBuffer.restoreCursor();
        } else if (cp == 'c') {
            mBuffer.reset();
            reset();
        } else if (cp == 'D') {
            mBuffer.lineFeed();
        } else if (cp == 'E') {
            mBuffer.lineFeed();
            mBuffer.carriageReturn();
        } else if (cp == 'M') {
            mBuffer.scrollDown(1);
        } else if (cp >= 0x20 && cp <= 0x2f) {
            mState = STATE_ESC_INTERMEDIATE;
        }
    }

    private void beginCsi() {
        mState = STATE_CSI;
        mArgCount = 0;
        mCurrent = 0;
        mHasCurrent = false;
        mPrivate = false;
    }

    private void beginOsc() {
        mState = STATE_OSC;
        mOsc.setLength(0);
    }

    private void processCsi(int cp) {
        if (cp == '?') {
            mPrivate = true;
            return;
        }
        if (cp >= '0' && cp <= '9') {
            if (mCurrent < 1000000) {
                mCurrent = mCurrent * 10 + (cp - '0');
            }
            mHasCurrent = true;
            return;
        }
        if (cp == ';' || cp == ':') {
            pushArg();
            return;
        }
        if (cp >= 0x40 && cp <= 0x7e) {
            if (mHasCurrent) {
                pushArg();
            }
            handleCsi(cp);
            mState = STATE_GROUND;
        }
    }

    private void pushArg() {
        if (mArgCount < mArgs.length) {
            mArgs[mArgCount++] = mCurrent;
        }
        mCurrent = 0;
        mHasCurrent = false;
    }

    private int rawArg(int index) {
        if (index < 0 || index >= mArgCount) {
            return 0;
        }
        return mArgs[index];
    }

    private int arg(int index, int fallback) {
        if (index < 0 || index >= mArgCount) {
            return fallback;
        }
        int value = mArgs[index];
        return value == 0 ? fallback : value;
    }

    private void handleCsi(int command) {
        if (command == '@') {
            mBuffer.insertChars(arg(0, 1));
        } else if (command == 'A') {
            mBuffer.setCursor(mBuffer.getCursorRow() - arg(0, 1), mBuffer.getCursorCol());
        } else if (command == 'B') {
            mBuffer.setCursor(mBuffer.getCursorRow() + arg(0, 1), mBuffer.getCursorCol());
        } else if (command == 'C') {
            mBuffer.setCursor(mBuffer.getCursorRow(), mBuffer.getCursorCol() + arg(0, 1));
        } else if (command == 'D') {
            mBuffer.setCursor(mBuffer.getCursorRow(), mBuffer.getCursorCol() - arg(0, 1));
        } else if (command == 'E') {
            mBuffer.setCursor(mBuffer.getCursorRow() + arg(0, 1), 0);
        } else if (command == 'F') {
            mBuffer.setCursor(mBuffer.getCursorRow() - arg(0, 1), 0);
        } else if (command == 'G') {
            mBuffer.setCursor(mBuffer.getCursorRow(), arg(0, 1) - 1);
        } else if (command == 'H' || command == 'f') {
            mBuffer.setCursor(arg(0, 1) - 1, arg(1, 1) - 1);
        } else if (command == 'J') {
            mBuffer.eraseInDisplay(rawArg(0));
        } else if (command == 'K') {
            mBuffer.eraseInLine(rawArg(0));
        } else if (command == 'L') {
            mBuffer.insertLines(arg(0, 1));
        } else if (command == 'M') {
            mBuffer.deleteLines(arg(0, 1));
        } else if (command == 'P') {
            mBuffer.deleteChars(arg(0, 1));
        } else if (command == 'S') {
            mBuffer.scrollUp(arg(0, 1));
        } else if (command == 'T') {
            mBuffer.scrollDown(arg(0, 1));
        } else if (command == 'X') {
            mBuffer.eraseChars(arg(0, 1));
        } else if (command == 'd') {
            mBuffer.setCursor(arg(0, 1) - 1, mBuffer.getCursorCol());
        } else if (command == 'm') {
            handleSgr();
        } else if (command == 'h') {
            setModes(true);
        } else if (command == 'l') {
            setModes(false);
        } else if (command == 'r') {
            mBuffer.setScrollRegion(arg(0, 1) - 1, arg(1, mBuffer.getRows()) - 1);
        } else if (command == 's') {
            mBuffer.saveCursor();
        } else if (command == 'u') {
            mBuffer.restoreCursor();
        }
    }

    private void handleSgr() {
        if (mArgCount == 0) {
            mBuffer.resetStyle();
            return;
        }
        int fg = mBuffer.getFg();
        int bg = mBuffer.getBg();
        int flags = mBuffer.getFlags();
        int i = 0;
        while (i < mArgCount) {
            int code = mArgs[i];
            if (code == 0) {
                fg = ScreenBuffer.DEFAULT_FG;
                bg = ScreenBuffer.DEFAULT_BG;
                flags = 0;
            } else if (code == 1) {
                flags |= ScreenBuffer.FLAG_BOLD;
            } else if (code == 3) {
                flags |= ScreenBuffer.FLAG_UNDERLINE;
            } else if (code == 7) {
                flags |= ScreenBuffer.FLAG_REVERSE;
            } else if (code == 22) {
                flags &= ~ScreenBuffer.FLAG_BOLD;
            } else if (code == 24) {
                flags &= ~ScreenBuffer.FLAG_UNDERLINE;
            } else if (code == 27) {
                flags &= ~ScreenBuffer.FLAG_REVERSE;
            } else if (code >= 30 && code <= 37) {
                fg = code - 30;
            } else if (code == 39) {
                fg = ScreenBuffer.DEFAULT_FG;
            } else if (code >= 40 && code <= 47) {
                bg = code - 40;
            } else if (code == 49) {
                bg = ScreenBuffer.DEFAULT_BG;
            } else if (code >= 90 && code <= 97) {
                fg = 8 + (code - 90);
            } else if (code >= 100 && code <= 107) {
                bg = 8 + (code - 100);
            } else if (code == 38 && i + 1 < mArgCount) {
                if (mArgs[i + 1] == 5 && i + 2 < mArgCount) {
                    fg = mArgs[i + 2] & 0xff;
                    i += 2;
                } else if (mArgs[i + 1] == 2 && i + 4 < mArgCount) {
                    fg = ScreenBuffer.COLOR_RGB
                            | ((mArgs[i + 2] & 0xff) << 16)
                            | ((mArgs[i + 3] & 0xff) << 8)
                            | (mArgs[i + 4] & 0xff);
                    i += 4;
                }
            } else if (code == 48 && i + 1 < mArgCount) {
                if (mArgs[i + 1] == 5 && i + 2 < mArgCount) {
                    bg = mArgs[i + 2] & 0xff;
                    i += 2;
                } else if (mArgs[i + 1] == 2 && i + 4 < mArgCount) {
                    bg = ScreenBuffer.COLOR_RGB
                            | ((mArgs[i + 2] & 0xff) << 16)
                            | ((mArgs[i + 3] & 0xff) << 8)
                            | (mArgs[i + 4] & 0xff);
                    i += 4;
                }
            }
            i++;
        }
        mBuffer.setStyle(fg, bg, flags);
    }

    private void setModes(boolean enabled) {
        for (int i = 0; i < mArgCount; i++) {
            int mode = mArgs[i];
            if (mPrivate && mode == 25) {
                mBuffer.setCursorVisible(enabled);
            } else if (mPrivate && mode == 1049) {
                if (enabled) {
                    mBuffer.enterAltScreen();
                } else {
                    mBuffer.leaveAltScreen();
                }
            } else if (mPrivate && mode == 2004) {
                mBuffer.setBracketedPaste(enabled);
            } else if (mPrivate && mode == 1) {
                mBuffer.setApplicationCursorKeys(enabled);
            } else if (mPrivate && mode == 7) {
                mBuffer.setAutowrap(enabled);
            }
        }
    }

    private void processOsc(int cp) {
        if (cp == 0x07) {
            finishOsc();
            mState = STATE_GROUND;
        } else if (cp == 0x1b) {
            mState = STATE_OSC_ESC;
        } else {
            appendOsc((char) cp);
        }
    }

    private void appendOsc(char value) {
        if (mOsc.length() < MAX_OSC_LENGTH) {
            mOsc.append(value);
        }
    }

    private void finishOsc() {
        String value = mOsc.toString();
        if (value.startsWith("0;") || value.startsWith("2;")) {
            mBuffer.setTitle(value.substring(2));
        }
        mOsc.setLength(0);
    }
}
