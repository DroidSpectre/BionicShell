package dev.bionicshell;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public final class AppLog {
    public static final int MAX_CHARS = 200000;
    private static final int MAX_FILE_BYTES = 512 * 1024;
    private static final String FILE_NAME = "bionicshell.log";
    private static final StringBuilder BUFFER = new StringBuilder();
    private static final Object LOCK = new Object();
    private static File sFile;

    private AppLog() {
    }

    public static void init(Context context) {
        if (context == null) {
            return;
        }
        synchronized (LOCK) {
            if (sFile != null) {
                return;
            }
            File directory = RuntimePaths.logs(context);
            if (!directory.isDirectory() && !directory.mkdirs()) {
                return;
            }
            sFile = new File(directory, FILE_NAME);
            loadTail(new File(directory, FILE_NAME + ".1"));
            loadTail(sFile);
        }
    }

    public static void append(String text) {
        if (text == null || text.length() == 0) {
            return;
        }
        synchronized (LOCK) {
            BUFFER.append(text);
            trimBuffer();
            writeToFile(text);
        }
    }

    public static void appendLine(String text) {
        append((text == null ? "" : text) + "\n");
    }

    public static String read() {
        synchronized (LOCK) {
            return BUFFER.toString();
        }
    }

    public static void clear() {
        synchronized (LOCK) {
            BUFFER.setLength(0);
            if (sFile != null) {
                sFile.delete();
                new File(sFile.getParentFile(), sFile.getName() + ".1").delete();
            }
        }
    }

    private static void trimBuffer() {
        if (BUFFER.length() > MAX_CHARS) {
            BUFFER.delete(0, BUFFER.length() - MAX_CHARS);
        }
    }

    private static void loadTail(File file) {
        if (file == null || !file.isFile()) {
            return;
        }
        try {
            String text = readFile(file);
            if (text.length() > MAX_CHARS) {
                text = text.substring(text.length() - MAX_CHARS);
            }
            BUFFER.append(text);
            trimBuffer();
        } catch (IOException ignored) {
        }
    }

    private static String readFile(File file) throws IOException {
        FileInputStream input = new FileInputStream(file);
        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return new String(output.toByteArray(), "UTF-8");
        } finally {
            input.close();
        }
    }

    private static void writeToFile(String text) {
        if (sFile == null) {
            return;
        }
        try {
            byte[] bytes = text.getBytes("UTF-8");
            if (sFile.length() + bytes.length > MAX_FILE_BYTES) {
                rotateFile();
            }
            FileOutputStream output = new FileOutputStream(sFile, true);
            try {
                output.write(bytes);
            } finally {
                output.close();
            }
        } catch (IOException ignored) {
        }
    }

    private static void rotateFile() {
        File backup = new File(sFile.getParentFile(), sFile.getName() + ".1");
        backup.delete();
        sFile.renameTo(backup);
    }
}
