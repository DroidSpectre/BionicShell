package dev.bionicshell;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class LogActivity extends Activity {
    private TextView mText;

    protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppLog.init(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button refresh = new Button(this);
        refresh.setText("Refresh");
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                refresh();
            }
        });
        Button copy = new Button(this);
        copy.setText("Copy");
        copy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(
                        CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(ClipData.newPlainText(
                            "BionicShell log", AppLog.read()));
                    Toast.makeText(LogActivity.this, "Log copied",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        Button clear = new Button(this);
        clear.setText("Clear");
        clear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AppLog.clear();
                refresh();
            }
        });
        buttons.addView(refresh);
        buttons.addView(copy);
        buttons.addView(clear);
        ScrollView scroll = new ScrollView(this);
        mText = new TextView(this);
        mText.setTypeface(Typeface.MONOSPACE);
        mText.setTextSize(12.0f);
        mText.setTextIsSelectable(true);
        scroll.addView(mText);
        root.addView(buttons);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));
        setContentView(root);
        refresh();
    }

    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        mText.setText(AppLog.read());
    }
}
