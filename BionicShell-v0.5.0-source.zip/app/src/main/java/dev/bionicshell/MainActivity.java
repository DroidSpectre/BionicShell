package dev.bionicshell;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public final class MainActivity extends Activity {
    private static final int REQUEST_SAVE = 1001;
    private static final int REQUEST_IMPORT = 1002;
    private static final int REQUEST_NOTIFICATIONS = 1003;

    private TerminalView mTerminal;
    private TerminalSession mSession;
    private TextView mStatus;
    private String mPendingSaveText = "";
    private String mSelectedModelPath = "";
    private Button mServerButton;
    private LinearLayout mDrawer;
    private View mScrim;
    private TextView mDrawerStatus;
    private boolean mDrawerOpen;
    private int mDrawerWidth;

    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        startSession();
    }

    protected void onResume() {
        super.onResume();
        if (mTerminal != null) {
            mTerminal.requestFocus();
        }
        updateServerButton();
        updateDrawerStatus();
    }

    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (mTerminal != null) {
            mTerminal.refreshAfterLayout();
        }
    }

    public void onBackPressed() {
        if (mDrawerOpen) {
            closeDrawer();
            return;
        }
        super.onBackPressed();
    }

    protected void onDestroy() {
        if (isFinishing()) {
            TerminalSessionManager.get().close();
        }
        super.onDestroy();
    }

    private void buildUi() {
        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(TerminalRenderer.DEFAULT_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(TerminalRenderer.DEFAULT_BG);

        HorizontalScrollView toolbarScroll = new HorizontalScrollView(this);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        addButton(toolbar, "Menu", new View.OnClickListener() {
            public void onClick(View view) {
                openDrawer();
            }
        });
        addButton(toolbar, "Keyboard", new View.OnClickListener() {
            public void onClick(View view) {
                mTerminal.performClick();
            }
        });
        toolbarScroll.addView(toolbar);
        content.addView(toolbarScroll);

        mStatus = new TextView(this);
        mStatus.setTextColor(0xffd0d0d0);
        mStatus.setTextSize(12.0f);
        mStatus.setVisibility(View.GONE);
        content.addView(mStatus);

        mTerminal = new TerminalView(this);
        mTerminal.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));
        content.addView(mTerminal);

        HorizontalScrollView keyScroll = new HorizontalScrollView(this);
        LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        addKey(keys, "Esc", KeyEvent.KEYCODE_ESCAPE, 0);
        addKey(keys, "Tab", KeyEvent.KEYCODE_TAB, 0);
        addKey(keys, "Ctrl+C", KeyEvent.KEYCODE_C, KeyEvent.META_CTRL_ON);
        addKey(keys, "Ctrl+D", KeyEvent.KEYCODE_D, KeyEvent.META_CTRL_ON);
        addKey(keys, "Ctrl+Z", KeyEvent.KEYCODE_Z, KeyEvent.META_CTRL_ON);
        addKey(keys, "Ctrl+L", KeyEvent.KEYCODE_L, KeyEvent.META_CTRL_ON);
        addKey(keys, "Up", KeyEvent.KEYCODE_DPAD_UP, 0);
        addKey(keys, "Down", KeyEvent.KEYCODE_DPAD_DOWN, 0);
        addKey(keys, "Left", KeyEvent.KEYCODE_DPAD_LEFT, 0);
        addKey(keys, "Right", KeyEvent.KEYCODE_DPAD_RIGHT, 0);
        addKey(keys, "Home", KeyEvent.KEYCODE_MOVE_HOME, 0);
        addKey(keys, "End", KeyEvent.KEYCODE_MOVE_END, 0);
        addText(keys, "|");
        addText(keys, "-");
        addText(keys, "/");
        addText(keys, "~");
        keyScroll.addView(keys);
        content.addView(keyScroll);

        root.addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        mScrim = new View(this);
        mScrim.setBackgroundColor(0x99000000);
        mScrim.setClickable(true);
        mScrim.setVisibility(View.GONE);
        mScrim.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
            }
        });
        root.addView(mScrim, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        mDrawerWidth = Math.min(dp(300), screenWidth * 4 / 5);
        mDrawer = buildDrawer();
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(
                mDrawerWidth, FrameLayout.LayoutParams.MATCH_PARENT);
        drawerParams.gravity = Gravity.START;
        root.addView(mDrawer, drawerParams);
        mDrawer.setVisibility(View.GONE);
        mDrawer.setTranslationX(-mDrawerWidth);

        setContentView(root);
        root.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    public void onGlobalLayout() {
                        if (mTerminal != null) {
                            mTerminal.refreshAfterLayout();
                        }
                        root.invalidate();
                    }
                });
    }

    private LinearLayout buildDrawer() {
        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(0xff181818);
        drawer.setClickable(true);
        int pad = dp(16);
        drawer.setPadding(pad, dp(20), pad, pad);

        TextView title = new TextView(this);
        title.setText("BionicShell");
        title.setTextColor(0xffffffff);
        title.setTextSize(20.0f);
        drawer.addView(title);

        mDrawerStatus = new TextView(this);
        mDrawerStatus.setTextColor(0xffc0c0c0);
        mDrawerStatus.setTextSize(12.0f);
        mDrawerStatus.setPadding(0, dp(8), 0, dp(14));
        drawer.addView(mDrawerStatus);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(buttons);
        drawer.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));

        addDrawerButton(buttons, "Terminal", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
            }
        });
        addDrawerButton(buttons, "Models", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                showModels();
            }
        });
        mServerButton = addDrawerButton(buttons, "Start server", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                toggleServer();
            }
        });
        addDrawerButton(buttons, "API key", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                showApiKeyDialog();
            }
        });
        addDrawerButton(buttons, "Logs", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, LogActivity.class));
            }
        });
        addDrawerButton(buttons, "Settings", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        addDrawerButton(buttons, "Copy", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                mTerminal.copySelection();
            }
        });
        addDrawerButton(buttons, "Copy All", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                mTerminal.copyAll();
            }
        });
        addDrawerButton(buttons, "Paste", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                mTerminal.pasteClipboard();
            }
        });
        addDrawerButton(buttons, "Share", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                shareTranscript();
            }
        });
        addDrawerButton(buttons, "Save", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                saveTranscript();
            }
        });
        addDrawerButton(buttons, "Restart shell", new View.OnClickListener() {
            public void onClick(View view) {
                closeDrawer();
                restartSession();
            }
        });
        return drawer;
    }

    private Button addDrawerButton(LinearLayout column, String label,
                                   View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(14.0f);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        int pad = dp(12);
        button.setPadding(pad, 0, pad, 0);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(4);
        button.setLayoutParams(params);
        button.setOnClickListener(listener);
        column.addView(button);
        return button;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void openDrawer() {
        if (mDrawerOpen) {
            return;
        }
        mDrawerOpen = true;
        updateDrawerStatus();
        updateServerButton();
        InputMethodManager input = (InputMethodManager) getSystemService(
                INPUT_METHOD_SERVICE);
        if (input != null) {
            input.hideSoftInputFromWindow(mTerminal.getWindowToken(), 0);
        }
        mScrim.animate().cancel();
        mDrawer.animate().cancel();
        mScrim.setVisibility(View.VISIBLE);
        mScrim.setAlpha(0.0f);
        mScrim.animate().alpha(1.0f).setDuration(180).start();
        mDrawer.setVisibility(View.VISIBLE);
        mDrawer.setTranslationX(-mDrawerWidth);
        mDrawer.animate().translationX(0.0f).setDuration(180).start();
    }

    private void closeDrawer() {
        if (!mDrawerOpen) {
            return;
        }
        mDrawerOpen = false;
        mScrim.animate().cancel();
        mDrawer.animate().cancel();
        mDrawer.animate().translationX(-mDrawerWidth).setDuration(160)
                .withEndAction(new Runnable() {
                    public void run() {
                        if (!mDrawerOpen) {
                            mDrawer.setVisibility(View.GONE);
                        }
                    }
                }).start();
        mScrim.animate().alpha(0.0f).setDuration(160)
                .withEndAction(new Runnable() {
                    public void run() {
                        if (!mDrawerOpen) {
                            mScrim.setVisibility(View.GONE);
                        }
                    }
                }).start();
        mTerminal.requestFocus();
    }

    private void updateDrawerStatus() {
        if (mDrawerStatus == null) {
            return;
        }
        String shell = mSession != null && mSession.isRunning() ? "running" : "stopped";
        String model = "none";
        if (mSelectedModelPath.length() > 0) {
            File file = new File(mSelectedModelPath);
            model = file.getName() + (file.isFile() ? "" : " (missing)");
        }
        String server = "stopped";
        if (LlamaRuntime.isRunning()) {
            server = "running at " + LlamaRuntime.getBaseUrl();
        }
        mDrawerStatus.setText("Shell: " + shell + "\nModel: " + model + "\nServer: " + server);
    }

    private void startSession() {
        TerminalSession.Listener listener = new TerminalSession.Listener() {
            public void onScreenChanged() {
                mTerminal.invalidate();
            }

            public void onExit(int status) {
                if (!isFinishing()) {
                    showStatus("Shell exited with status " + status);
                }
                updateDrawerStatus();
            }
        };
        try {
            mSession = TerminalSessionManager.get().getOrStart(this, 24, 80, listener);
            mTerminal.setSession(mSession);
            mTerminal.requestFocus();
            mStatus.setVisibility(View.GONE);
            updateDrawerStatus();
        } catch (IOException exception) {
            AppLog.appendLine("shell start failed: " + exception.getMessage());
            showStatus("Cannot start shell: " + exception.getMessage());
            Toast.makeText(this, "Cannot start shell", Toast.LENGTH_LONG).show();
        }
    }

    private void restartSession() {
        TerminalSessionManager.get().close();
        mSession = null;
        mTerminal.setSession(null);
        startSession();
    }

    private void showStatus(String text) {
        mStatus.setText(text);
        mStatus.setVisibility(View.VISIBLE);
    }

    private Button addButton(LinearLayout row, String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(12.0f);
        button.setOnClickListener(listener);
        row.addView(button);
        return button;
    }

    private void addKey(LinearLayout row, String label, final int keyCode, final int metaState) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(12.0f);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mTerminal.sendKey(keyCode, metaState);
                mTerminal.requestFocus();
            }
        });
        row.addView(button);
    }

    private void addText(LinearLayout row, final String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(12.0f);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mTerminal.sendText(text);
                mTerminal.requestFocus();
            }
        });
        row.addView(button);
    }

    private String transcript() {
        if (mSession == null) {
            return "";
        }
        synchronized (mSession.getBufferLock()) {
            return mSession.getBuffer().copyAll();
        }
    }

    private void shareTranscript() {
        String text = transcript();
        if (text.length() == 0) {
            Toast.makeText(this, "Nothing to share", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(intent, "Share transcript"));
    }

    private void saveTranscript() {
        String text = transcript();
        if (text.length() == 0) {
            Toast.makeText(this, "Nothing to save", Toast.LENGTH_SHORT).show();
            return;
        }
        mPendingSaveText = text;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "bionicshell.txt");
        startActivityForResult(intent, REQUEST_SAVE);
    }

    private void showModels() {
        final List<ModelRepository.ModelInfo> models = ModelRepository.list(this);
        if (models.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Models")
                    .setMessage("No .gguf models found in " + ModelRepository.modelsDir(this).getAbsolutePath())
                    .setPositiveButton("Import", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            startImport();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        String[] names = new String[models.size()];
        for (int i = 0; i < models.size(); i++) {
            ModelRepository.ModelInfo info = models.get(i);
            names[i] = info.getName() + " (" + Formatter.formatFileSize(this, info.getSize()) + ")";
        }
        new AlertDialog.Builder(this)
                .setTitle("Select model")
                .setItems(names, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        mSelectedModelPath = models.get(which).getFile().getAbsolutePath();
                        updateDrawerStatus();
                        Toast.makeText(MainActivity.this, "Selected " + models.get(which).getName(),
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton("Import", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        startImport();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_IMPORT);
    }

    private void importModel(final Uri uri) {
        final String name = displayName(uri);
        Toast.makeText(this, "Importing " + name, Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            public void run() {
                try {
                    final ModelRepository.ModelInfo info =
                            ModelRepository.importFromUri(MainActivity.this, uri, name);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            mSelectedModelPath = info.getFile().getAbsolutePath();
                            updateDrawerStatus();
                            Toast.makeText(MainActivity.this, "Imported " + info.getName(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (final Exception exception) {
                    AppLog.appendLine("model import failed: " + exception.getMessage());
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(MainActivity.this, "Import failed: " + exception.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }, "bionicshell-model-import").start();
    }

    private String displayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.length() > 0) {
                        return name;
                    }
                }
            }
        } catch (RuntimeException ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        String fallback = uri.getLastPathSegment();
        return fallback == null ? "model.gguf" : fallback;
    }

    private void toggleServer() {
        if (LlamaRuntime.isRunning()) {
            stopServer();
            return;
        }
        if (mSelectedModelPath.length() == 0) {
            new AlertDialog.Builder(this)
                    .setTitle("Server")
                    .setMessage("Select a model first.")
                    .setPositiveButton("Choose model", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            showModels();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        File model = new File(mSelectedModelPath);
        if (!model.isFile()) {
            mSelectedModelPath = "";
            Toast.makeText(this, "Model file is missing", Toast.LENGTH_LONG).show();
            return;
        }
        final LlamaController.Config config = new LlamaController.Config(
                model, 8080,
                (int) ServerSettings.getContext(this),
                ServerSettings.getThreads(this),
                0,
                ServerSettings.getApiKey(this),
                ServerSettings.getTemperature(this),
                ServerSettings.getReasoning(this));
        new AlertDialog.Builder(this)
                .setTitle("Start llama-server")
                .setMessage("Model: " + model.getName() + "\nAddress: localhost:8080\nThreads: " + config.threads
                        + "\nContext: " + config.contextSize + "\nTemp: " + config.temperature
                        + "\nReasoning: " + config.reasoning)
                .setPositiveButton("Start", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        startServer(config);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startServer(final LlamaController.Config config) {
        requestNotificationPermission();
        try {
            if (!LlamaRuntime.start(this, config)) {
                AppLog.appendLine("server exited immediately");
                Toast.makeText(this, "Server exited; check Logs", Toast.LENGTH_LONG).show();
                return;
            }
            Intent service = new Intent(this, LlamaService.class);
            service.setAction(LlamaService.ACTION_START);
            startForegroundService(service);
        } catch (IOException exception) {
            AppLog.appendLine("server start failed: " + exception.getMessage());
            Toast.makeText(this, "Server failed: " + exception.getMessage(), Toast.LENGTH_LONG).show();
            return;
        } catch (RuntimeException exception) {
            LlamaRuntime.stop();
            AppLog.appendLine("server service failed: " + exception.getMessage());
            Toast.makeText(this, "Server service failed: " + exception.getMessage(),
                    Toast.LENGTH_LONG).show();
            return;
        }
        updateServerButton();
        updateDrawerStatus();
        final String key = config.apiKey;
        new AlertDialog.Builder(this)
                .setTitle("Server running")
                .setMessage("OpenAI-compatible endpoint:\n" + LlamaRuntime.getBaseUrl()
                        + "\n\nAuthorization: Bearer " + key
                        + "\n\nThe server keeps running in the background. Use Stop server "
                        + "in the menu or the notification to stop it.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Copy key", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        copyText("BionicShell API key", key);
                    }
                })
                .show();
    }

    private void stopServer() {
        LlamaRuntime.stop();
        stopService(new Intent(this, LlamaService.class));
        updateServerButton();
        updateDrawerStatus();
    }

    private void updateServerButton() {
        if (mServerButton != null) {
            mServerButton.setText(LlamaRuntime.isRunning() ? "Stop server" : "Start server");
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS },
                    REQUEST_NOTIFICATIONS);
        }
    }

    private void showApiKeyDialog() {
        final String key = ServerSettings.getApiKey(this);
        new AlertDialog.Builder(this)
                .setTitle("Server API key")
                .setMessage(key)
                .setPositiveButton("Copy", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        copyText("BionicShell API key", key);
                    }
                })
                .setNeutralButton("Change", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        showApiKeyEditor();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showApiKeyEditor() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        input.setText(ServerSettings.getApiKey(this));
        input.setSelection(input.getText().length());
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Set API key")
                .setMessage("Use 8-200 printable characters without spaces. "
                        + "Restart the server after changing the key.")
                .setView(input)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View view) {
                        String value = input.getText().toString().trim();
                        if (!ServerSettings.isValidApiKey(value)) {
                            Toast.makeText(MainActivity.this,
                                    "Key must be 8-200 printable characters without spaces",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        ServerSettings.setApiKey(MainActivity.this, value);
                        AppLog.appendLine("server: API key changed");
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this,
                                LlamaRuntime.isRunning()
                                        ? "Key saved; restart the server to use it"
                                        : "API key saved",
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void copyText(String label, String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(
                CLIPBOARD_SERVICE);
        if (clipboard == null) {
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text));
        Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT && resultCode == RESULT_OK && data != null) {
            Uri importUri = data.getData();
            if (importUri != null) {
                importModel(importUri);
            }
            return;
        }
        if (requestCode != REQUEST_SAVE || resultCode != RESULT_OK || data == null) {
            return;
        }
        Uri uri = data.getData();
        if (uri == null) {
            return;
        }
        OutputStream output = null;
        try {
            output = getContentResolver().openOutputStream(uri);
            if (output != null) {
                output.write(mPendingSaveText.getBytes("UTF-8"));
                Toast.makeText(this, "Transcript saved", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException exception) {
            Toast.makeText(this, "Save failed: " + exception.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException ignored) {
                }
            }
        }
    }
}
