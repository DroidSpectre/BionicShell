package dev.bionicshell;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import dev.bionicshell.app.R;

public final class SettingsActivity extends Activity {

    private EditText mContext;
    private SeekBar mThreads;
    private TextView mThreadsLabel;
    private SeekBar mTemp;
    private TextView mTempLabel;
    private CheckBox mReasoning;

    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_settings);

        mContext = (EditText) findViewById(R.id.etContext);
        mThreads = (SeekBar) findViewById(R.id.sbThreads);
        mThreadsLabel = (TextView) findViewById(R.id.tvThreads);
        mTemp = (SeekBar) findViewById(R.id.sbTemp);
        mTempLabel = (TextView) findViewById(R.id.tvTemp);
        mReasoning = (CheckBox) findViewById(R.id.cbReasoning);

        mContext.setText(String.valueOf(ServerSettings.getContext(this)));
        mThreads.setProgress(ServerSettings.getThreads(this) - 1);
        mTemp.setProgress((int) Math.round(ServerSettings.getTemperature(this) / ServerSettings.STEP_TEMP));
        mReasoning.setChecked(ServerSettings.getReasoning(this));

        updateThreadLabel();
        updateTempLabel();

        mThreads.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateThreadLabel();
            }

            public void onStartTrackingTouch(SeekBar bar) {
            }

            public void onStopTrackingTouch(SeekBar bar) {
            }
        });

        mTemp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateTempLabel();
            }

            public void onStartTrackingTouch(SeekBar bar) {
            }

            public void onStopTrackingTouch(SeekBar bar) {
            }
        });

        Button save = (Button) findViewById(R.id.btnSave);
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                save();
            }
        });

        Button cancel = (Button) findViewById(R.id.btnCancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void updateThreadLabel() {
        mThreadsLabel.setText(String.valueOf(mThreads.getProgress() + 1));
    }

    private void updateTempLabel() {
        double value = mTemp.getProgress() * ServerSettings.STEP_TEMP;
        mTempLabel.setText(String.format(java.util.Locale.US, "%.1f", new Object[]{value}));
    }

    private void save() {
        long context;
        try {
            context = Long.parseLong(mContext.getText().toString().trim());
        } catch (NumberFormatException exception) {
            Toast.makeText(this, "Context must be a number", Toast.LENGTH_LONG).show();
            return;
        }
        if (context < 64 || context > 131072) {
            Toast.makeText(this, "Context must be between 64 and 131072", Toast.LENGTH_LONG).show();
            return;
        }
        if (context % ServerSettings.STEP_CONTEXT != 0) {
            Toast.makeText(this, "Context must be a multiple of 64", Toast.LENGTH_LONG).show();
            return;
        }
        int threads = mThreads.getProgress() + 1;
        double temp = mTemp.getProgress() * ServerSettings.STEP_TEMP;
        boolean reasoning = mReasoning.isChecked();

        ServerSettings.setContext(this, context);
        ServerSettings.setThreads(this, threads);
        ServerSettings.setTemperature(this, temp);
        ServerSettings.setReasoning(this, reasoning);

        AppLog.appendLine("server: settings context=" + context + " threads=" + threads
                + " temp=" + temp + " reasoning=" + reasoning);

        Toast.makeText(this,
                LlamaRuntime.isRunning()
                        ? "Settings saved; restart the server to apply"
                        : "Settings saved",
                Toast.LENGTH_LONG).show();
        finish();
    }
}
