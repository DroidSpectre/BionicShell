package dev.bionicshell;

import android.view.KeyEvent;

import java.io.UnsupportedEncodingException;

public final class KeyHandler {
    private static final byte[] EMPTY = new byte[0];

    private KeyHandler() {
    }

    public static byte[] encodeKey(int keyCode, int metaState, boolean applicationCursor) {
        boolean ctrl = (metaState & KeyEvent.META_CTRL_MASK) != 0;
        boolean alt = (metaState & KeyEvent.META_ALT_MASK) != 0;
        if (ctrl) {
            int control = ctrlByte(keyCode);
            if (control >= 0) {
                return withAlt(new byte[] { (byte) control }, alt);
            }
        }
        if (keyCode == KeyEvent.KEYCODE_ENTER) {
            return withAlt(new byte[] { '\r' }, alt);
        }
        if (keyCode == KeyEvent.KEYCODE_DEL) {
            return withAlt(new byte[] { 0x7f }, alt);
        }
        if (keyCode == KeyEvent.KEYCODE_FORWARD_DEL) {
            return withAlt(bytes("\u001b[3~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_TAB) {
            return withAlt(new byte[] { '\t' }, alt);
        }
        if (keyCode == KeyEvent.KEYCODE_ESCAPE) {
            return new byte[] { 0x1b };
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            return withAlt(bytes(applicationCursor ? "\u001bOA" : "\u001b[A"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            return withAlt(bytes(applicationCursor ? "\u001bOB" : "\u001b[B"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            return withAlt(bytes(applicationCursor ? "\u001bOC" : "\u001b[C"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
            return withAlt(bytes(applicationCursor ? "\u001bOD" : "\u001b[D"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_MOVE_HOME) {
            return withAlt(bytes(applicationCursor ? "\u001bOH" : "\u001b[H"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_MOVE_END) {
            return withAlt(bytes(applicationCursor ? "\u001bOF" : "\u001b[F"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_INSERT) {
            return withAlt(bytes("\u001b[2~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_PAGE_UP) {
            return withAlt(bytes("\u001b[5~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_PAGE_DOWN) {
            return withAlt(bytes("\u001b[6~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F1) {
            return withAlt(bytes("\u001bOP"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F2) {
            return withAlt(bytes("\u001bOQ"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F3) {
            return withAlt(bytes("\u001bOR"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F4) {
            return withAlt(bytes("\u001bOS"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F5) {
            return withAlt(bytes("\u001b[15~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F6) {
            return withAlt(bytes("\u001b[17~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F7) {
            return withAlt(bytes("\u001b[18~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F8) {
            return withAlt(bytes("\u001b[19~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F9) {
            return withAlt(bytes("\u001b[20~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F10) {
            return withAlt(bytes("\u001b[21~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F11) {
            return withAlt(bytes("\u001b[23~"), alt);
        }
        if (keyCode == KeyEvent.KEYCODE_F12) {
            return withAlt(bytes("\u001b[24~"), alt);
        }
        return EMPTY;
    }

    public static int ctrlByte(int keyCode) {
        if (keyCode >= KeyEvent.KEYCODE_A && keyCode <= KeyEvent.KEYCODE_Z) {
            return keyCode - KeyEvent.KEYCODE_A + 1;
        }
        if (keyCode == KeyEvent.KEYCODE_LEFT_BRACKET) {
            return 27;
        }
        if (keyCode == KeyEvent.KEYCODE_BACKSLASH) {
            return 28;
        }
        if (keyCode == KeyEvent.KEYCODE_RIGHT_BRACKET) {
            return 29;
        }
        if (keyCode == KeyEvent.KEYCODE_MINUS) {
            return 31;
        }
        if (keyCode == KeyEvent.KEYCODE_SPACE) {
            return 0;
        }
        return -1;
    }

    public static byte[] encodeText(String text) {
        if (text == null) {
            return EMPTY;
        }
        String normalized = text.replace("\r\n", "\r").replace('\n', '\r');
        try {
            return normalized.getBytes("UTF-8");
        } catch (UnsupportedEncodingException exception) {
            return EMPTY;
        }
    }

    public static byte[] paste(String text, boolean bracketed) {
        if (text == null) {
            return EMPTY;
        }
        String normalized = text.replace("\r\n", "\r").replace('\n', '\r');
        if (!bracketed) {
            return encodeText(normalized);
        }
        return concat(bytes("\u001b[200~"), encodeText(normalized), bytes("\u001b[201~"));
    }

    private static byte[] withAlt(byte[] value, boolean alt) {
        if (!alt || value.length == 0) {
            return value;
        }
        byte[] result = new byte[value.length + 1];
        result[0] = 0x1b;
        System.arraycopy(value, 0, result, 1, value.length);
        return result;
    }

    private static byte[] bytes(String value) {
        try {
            return value.getBytes("UTF-8");
        } catch (UnsupportedEncodingException exception) {
            return EMPTY;
        }
    }

    private static byte[] concat(byte[] first, byte[] second, byte[] third) {
        byte[] result = new byte[first.length + second.length + third.length];
        System.arraycopy(first, 0, result, 0, first.length);
        System.arraycopy(second, 0, result, first.length, second.length);
        System.arraycopy(third, 0, result, first.length + second.length, third.length);
        return result;
    }
}
