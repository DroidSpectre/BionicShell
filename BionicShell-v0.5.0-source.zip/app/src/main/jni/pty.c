#include <jni.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

static char **to_string_array(JNIEnv *env, jobjectArray array) {
    if (array == NULL) {
        return NULL;
    }
    jsize length = (*env)->GetArrayLength(env, array);
    char **result = (char **) calloc((size_t) length + 1, sizeof(char *));
    if (result == NULL) {
        return NULL;
    }
    for (jsize i = 0; i < length; i++) {
        jstring item = (jstring) (*env)->GetObjectArrayElement(env, array, i);
        if (item != NULL) {
            const char *value = (*env)->GetStringUTFChars(env, item, NULL);
            if (value != NULL) {
                result[i] = strdup(value);
                (*env)->ReleaseStringUTFChars(env, item, value);
            }
            (*env)->DeleteLocalRef(env, item);
        }
    }
    return result;
}

static void free_string_array(char **array) {
    if (array == NULL) {
        return;
    }
    for (int i = 0; array[i] != NULL; i++) {
        free(array[i]);
    }
    free(array);
}

JNIEXPORT jint JNICALL
Java_dev_bionicshell_PtyNative_open(JNIEnv *env, jclass clazz, jobjectArray argvArray,
                                    jobjectArray envpArray, jstring cwdString, jint rows,
                                    jint cols, jintArray pidOut) {
    (void) clazz;
    char **argv = to_string_array(env, argvArray);
    char **envp = to_string_array(env, envpArray);
    const char *cwd = NULL;
    char *slaveName = NULL;
    int master = -1;
    if (argv == NULL || envp == NULL || cwdString == NULL) {
        goto cleanup;
    }
    cwd = (*env)->GetStringUTFChars(env, cwdString, NULL);
    if (cwd == NULL) {
        goto cleanup;
    }

    master = open("/dev/ptmx", O_RDWR | O_NOCTTY);
    if (master < 0) {
        goto cleanup;
    }
    if (grantpt(master) != 0 || unlockpt(master) != 0) {
        close(master);
        master = -1;
        goto cleanup;
    }
    slaveName = ptsname(master);
    if (slaveName == NULL) {
        close(master);
        master = -1;
        goto cleanup;
    }
    slaveName = strdup(slaveName);
    if (slaveName == NULL) {
        close(master);
        master = -1;
        goto cleanup;
    }

    struct termios settings;
    if (tcgetattr(master, &settings) == 0) {
        settings.c_iflag &= ~(IXON | IXOFF);
#ifdef IUTF8
        settings.c_iflag |= IUTF8;
#endif
        tcsetattr(master, TCSANOW, &settings);
    }

    struct winsize size;
    memset(&size, 0, sizeof(size));
    size.ws_row = (unsigned short) rows;
    size.ws_col = (unsigned short) cols;
    ioctl(master, TIOCSWINSZ, &size);

    pid_t pid = fork();
    if (pid == 0) {
        close(master);
        setsid();
        int slave = open(slaveName, O_RDWR);
        if (slave < 0) {
            _exit(127);
        }
        ioctl(slave, TIOCSCTTY, 0);
        dup2(slave, STDIN_FILENO);
        dup2(slave, STDOUT_FILENO);
        dup2(slave, STDERR_FILENO);
        if (slave > STDERR_FILENO) {
            close(slave);
        }
        if (chdir(cwd) != 0) {
            _exit(127);
        }
        execve(argv[0], argv, envp);
        _exit(127);
    }
    if (pid < 0) {
        close(master);
        master = -1;
        goto cleanup;
    }

    if (pidOut != NULL) {
        jint value = (jint) pid;
        (*env)->SetIntArrayRegion(env, pidOut, 0, 1, &value);
    }

cleanup:
    if (cwd != NULL) {
        (*env)->ReleaseStringUTFChars(env, cwdString, cwd);
    }
    free(slaveName);
    free_string_array(argv);
    free_string_array(envp);
    return master;
}

JNIEXPORT void JNICALL
Java_dev_bionicshell_PtyNative_resize(JNIEnv *env, jclass clazz, jint fd, jint rows, jint cols) {
    (void) env;
    (void) clazz;
    struct winsize size;
    memset(&size, 0, sizeof(size));
    size.ws_row = (unsigned short) rows;
    size.ws_col = (unsigned short) cols;
    ioctl(fd, TIOCSWINSZ, &size);
}

JNIEXPORT void JNICALL
Java_dev_bionicshell_PtyNative_close(JNIEnv *env, jclass clazz, jint fd) {
    (void) env;
    (void) clazz;
    close(fd);
}

JNIEXPORT void JNICALL
Java_dev_bionicshell_PtyNative_signal(JNIEnv *env, jclass clazz, jint pid, jint signalNumber) {
    (void) env;
    (void) clazz;
    kill((pid_t) pid, signalNumber);
}

JNIEXPORT jint JNICALL
Java_dev_bionicshell_PtyNative_waitFor(JNIEnv *env, jclass clazz, jint pid) {
    (void) env;
    (void) clazz;
    int status = 0;
    pid_t result;
    do {
        result = waitpid((pid_t) pid, &status, 0);
    } while (result < 0 && errno == EINTR);
    if (result < 0) {
        return -1;
    }
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return -1;
}
