#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: liblauncher.so <tool> [args...]\n");
        return 127;
    }
    char self[PATH_MAX];
    ssize_t length = readlink("/proc/self/exe", self, sizeof(self) - 1);
    if (length <= 0 || (size_t) length >= sizeof(self) - 1) {
        fprintf(stderr, "launcher: cannot resolve self: %s\n", strerror(errno));
        return 127;
    }
    self[length] = '\0';
    char *slash = strrchr(self, '/');
    if (slash == NULL) {
        return 127;
    }
    *slash = '\0';

    char target[PATH_MAX];
    int written;
    if (strchr(argv[1], '/') != NULL) {
        written = snprintf(target, sizeof(target), "%s", argv[1]);
    } else {
        written = snprintf(target, sizeof(target), "%s/lib%s.so", self, argv[1]);
    }
    if (written < 0 || (size_t) written >= sizeof(target)) {
        fprintf(stderr, "launcher: path too long\n");
        return 127;
    }

    char **args = (char **) calloc((size_t) argc, sizeof(char *));
    if (args == NULL) {
        return 127;
    }
    args[0] = argv[1];
    for (int i = 1; i < argc - 1; i++) {
        args[i] = argv[i + 1];
    }
    args[argc - 1] = NULL;
    execv(target, args);
    fprintf(stderr, "launcher: cannot exec %s: %s\n", target, strerror(errno));
    free(args);
    return 127;
}
