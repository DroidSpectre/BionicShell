package dev.bionicshell;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class TerminalSelectionTest {
    @Test
    public void normalizesReversedSelection() {
        TerminalSelection selection = new TerminalSelection();
        selection.set(2, 4, 1, 3);
        assertTrue(selection.contains(1, 3));
        assertTrue(selection.contains(1, 9));
        assertTrue(selection.contains(2, 3));
        assertFalse(selection.contains(2, 4));
        assertFalse(selection.contains(2, 5));
    }

    @Test
    public void emptySelectionContainsNothing() {
        TerminalSelection selection = new TerminalSelection();
        assertFalse(selection.isActive());
        selection.set(1, 1, 1, 1);
        assertTrue(selection.isEmpty());
        assertFalse(selection.contains(1, 1));
    }

    @Test
    public void clearResetsSelection() {
        TerminalSelection selection = new TerminalSelection();
        selection.set(1, 1, 3, 4);
        selection.clear();
        assertFalse(selection.isActive());
        assertFalse(selection.contains(1, 1));
    }
}
