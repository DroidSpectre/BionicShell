package dev.bionicshell;

import org.junit.Test;

import java.io.UnsupportedEncodingException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class AnsiParserTest {
    private ScreenBuffer buffer;
    private AnsiParser parser;

    private void setUp() {
        buffer = new ScreenBuffer(4, 12);
        parser = new AnsiParser(buffer);
    }

    private void feed(String text) throws UnsupportedEncodingException {
        parser.append(text.getBytes("UTF-8"));
    }

    @Test
    public void parsesSgrColorsAndBold() throws Exception {
        setUp();
        feed("\033[31;1mX");
        assertEquals(1, buffer.getFgAt(0, 0));
        assertEquals(ScreenBuffer.FLAG_BOLD, buffer.getFlagsAt(0, 0));
        feed("\033[0mY");
        assertEquals(ScreenBuffer.DEFAULT_FG, buffer.getFgAt(0, 1));
        assertEquals(0, buffer.getFlagsAt(0, 1));
    }

    @Test
    public void parses256AndTrueColor() throws Exception {
        setUp();
        feed("\033[38;5;196mA");
        assertEquals(196, buffer.getFgAt(0, 0));
        feed("\033[38;2;1;2;3mB");
        assertEquals(ScreenBuffer.COLOR_RGB | (1 << 16) | (2 << 8) | 3, buffer.getFgAt(0, 1));
    }

    @Test
    public void parsesBackgroundAndReverseVideo() throws Exception {
        setUp();
        feed("\033[41;7mX");
        assertEquals(1, buffer.getBgAt(0, 0));
        assertEquals(ScreenBuffer.FLAG_REVERSE, buffer.getFlagsAt(0, 0));
        feed("\033[27;49mY");
        assertEquals(0, buffer.getFlagsAt(0, 1));
        assertEquals(ScreenBuffer.DEFAULT_BG, buffer.getBgAt(0, 1));
    }

    @Test
    public void parsesCursorPositionAndEraseLine() throws Exception {
        setUp();
        feed("abcdef");
        feed("\033[1;3H");
        assertEquals(0, buffer.getCursorRow());
        assertEquals(2, buffer.getCursorCol());
        feed("\033[K");
        assertEquals("ab", buffer.getLineTextAbsolute(0));
        feed("Z");
        assertEquals("abZ", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void parsesAlternateScreenAndModes() throws Exception {
        setUp();
        feed("main");
        feed("\033[?1049h");
        assertTrue(buffer.isAltScreen());
        feed("\033[?2004h\033[?25l");
        assertTrue(buffer.isBracketedPaste());
        assertFalse(buffer.isCursorVisible());
        feed("alt");
        feed("\033[?1049l");
        assertFalse(buffer.isAltScreen());
        assertEquals("main", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void parsesOscTitle() throws Exception {
        setUp();
        feed("\033]0;BionicShell\007");
        assertEquals("BionicShell", buffer.getTitle());
        feed("ok");
        assertEquals("ok", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void parsesOscTerminatedBySt() throws Exception {
        setUp();
        feed("\033]2;title\033\\ok");
        assertEquals("title", buffer.getTitle());
        assertEquals("ok", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void handlesUtf8SplitAcrossAppends() throws Exception {
        setUp();
        byte[] euro = "\u20ac".getBytes("UTF-8");
        parser.append(new byte[] { euro[0] });
        parser.append(new byte[] { euro[1] });
        parser.append(new byte[] { euro[2] });
        assertEquals("\u20ac", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void handlesEscapeSplitAcrossAppends() throws Exception {
        setUp();
        parser.append(new byte[] { 0x1b });
        parser.append(new byte[] { '[' });
        parser.append("31mX".getBytes("UTF-8"));
        assertEquals(1, buffer.getFgAt(0, 0));
        assertEquals("X", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void handlesUnknownCsiWithoutDroppingFollowingText() throws Exception {
        setUp();
        feed("\033[999zX");
        assertEquals("X", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void ignoresDcsPayload() throws Exception {
        setUp();
        feed("\033P1$r\033\\ok");
        assertEquals("ok", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void parsesScrollRegionAndReverseIndex() throws Exception {
        setUp();
        feed("top\r\nmid\r\nbot");
        feed("\033[2;3r");
        feed("\033[3;1H\n");
        assertEquals("top", buffer.getVisibleLineText(0));
        assertEquals("bot", buffer.getVisibleLineText(1));
        assertEquals("", buffer.getVisibleLineText(2));
    }

    @Test
    public void handlesBackspaceTabAndEraseDisplay() throws Exception {
        setUp();
        feed("abc\bX");
        assertEquals("abX", buffer.getLineTextAbsolute(0));
        feed("\tY");
        assertEquals("abX     Y", buffer.getLineTextAbsolute(0));
        feed("\033[2J");
        assertEquals("", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void resetsBufferOnFullReset() throws Exception {
        setUp();
        feed("\033[31mhello\033c");
        assertEquals("", buffer.getLineTextAbsolute(0));
        assertEquals(ScreenBuffer.DEFAULT_FG, buffer.getFg());
        assertEquals(0, buffer.getCursorRow());
        assertEquals(0, buffer.getCursorCol());
    }
}
