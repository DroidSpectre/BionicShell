package dev.bionicshell;

import android.view.KeyEvent;

import org.junit.Test;

import java.io.UnsupportedEncodingException;

import static org.junit.Assert.assertArrayEquals;

public final class KeyHandlerTest {
    private static void assertAscii(String expected, byte[] actual) {
        assertArrayEquals(expected.getBytes(), actual);
    }

    @Test
    public void ctrlLettersProduceControlBytes() {
        assertAscii("\u0003", KeyHandler.encodeKey(KeyEvent.KEYCODE_C, KeyEvent.META_CTRL_ON, false));
        assertAscii("\u0000", KeyHandler.encodeKey(KeyEvent.KEYCODE_SPACE, KeyEvent.META_CTRL_ON, false));
        assertAscii("\u001b", KeyHandler.encodeKey(KeyEvent.KEYCODE_LEFT_BRACKET, KeyEvent.META_CTRL_ON, false));
    }

    @Test
    public void ctrlPunctuationProducesControlBytes() {
        assertAscii("\u001c", KeyHandler.encodeKey(KeyEvent.KEYCODE_BACKSLASH, KeyEvent.META_CTRL_ON, false));
        assertAscii("\u001d", KeyHandler.encodeKey(KeyEvent.KEYCODE_RIGHT_BRACKET, KeyEvent.META_CTRL_ON, false));
        assertAscii("\u001f", KeyHandler.encodeKey(KeyEvent.KEYCODE_MINUS, KeyEvent.META_CTRL_ON, false));
    }

    @Test
    public void enterAndBackspaceUseTerminalBytes() {
        assertAscii("\r", KeyHandler.encodeKey(KeyEvent.KEYCODE_ENTER, 0, false));
        assertAscii("\u007f", KeyHandler.encodeKey(KeyEvent.KEYCODE_DEL, 0, false));
        assertAscii("\t", KeyHandler.encodeKey(KeyEvent.KEYCODE_TAB, 0, false));
    }

    @Test
    public void arrowsUseApplicationModeWhenRequested() {
        assertAscii("\u001b[A", KeyHandler.encodeKey(KeyEvent.KEYCODE_DPAD_UP, 0, false));
        assertAscii("\u001bOA", KeyHandler.encodeKey(KeyEvent.KEYCODE_DPAD_UP, 0, true));
        assertAscii("\u001bOD", KeyHandler.encodeKey(KeyEvent.KEYCODE_DPAD_LEFT, 0, true));
    }

    @Test
    public void navigationAndFunctionKeysUseCsi() {
        assertAscii("\u001b[3~", KeyHandler.encodeKey(KeyEvent.KEYCODE_FORWARD_DEL, 0, false));
        assertAscii("\u001b[5~", KeyHandler.encodeKey(KeyEvent.KEYCODE_PAGE_UP, 0, false));
        assertAscii("\u001b[24~", KeyHandler.encodeKey(KeyEvent.KEYCODE_F12, 0, false));
        assertAscii("\u001b[15~", KeyHandler.encodeKey(KeyEvent.KEYCODE_F5, 0, false));
    }

    @Test
    public void altPrefixesTheEscapeSequence() {
        assertAscii("\u001b\u001b[A", KeyHandler.encodeKey(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.META_ALT_ON, false));
        assertAscii("\u001b\u0003", KeyHandler.encodeKey(KeyEvent.KEYCODE_C, KeyEvent.META_CTRL_ON | KeyEvent.META_ALT_ON, false));
    }

    @Test
    public void encodesTextAsUtf8AndNormalizesNewlines() throws UnsupportedEncodingException {
        assertArrayEquals("a\rb\u00e9".getBytes("UTF-8"), KeyHandler.encodeText("a\nb\u00e9"));
        assertArrayEquals("a\rb".getBytes("UTF-8"), KeyHandler.encodeText("a\r\nb"));
    }

    @Test
    public void pasteWrapsBracketedPaste() throws UnsupportedEncodingException {
        assertArrayEquals("\u001b[200~abc\u001b[201~".getBytes("UTF-8"),
                KeyHandler.paste("abc", true));
        assertArrayEquals("abc".getBytes("UTF-8"), KeyHandler.paste("abc", false));
        assertArrayEquals("\u001b[200~a\rb\u001b[201~".getBytes("UTF-8"),
                KeyHandler.paste("a\nb", true));
    }

    @Test
    public void unsupportedKeysAreEmpty() {
        assertArrayEquals(new byte[0], KeyHandler.encodeKey(KeyEvent.KEYCODE_CAMERA, 0, false));
        assertArrayEquals(new byte[0], KeyHandler.encodeText(null));
        assertArrayEquals(new byte[0], KeyHandler.paste(null, true));
    }
}
