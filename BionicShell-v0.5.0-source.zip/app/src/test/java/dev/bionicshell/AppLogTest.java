package dev.bionicshell;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public final class AppLogTest {
    @Test
    public void appendsLinesAndClears() {
        AppLog.clear();
        AppLog.append("one");
        AppLog.appendLine("two");
        assertEquals("onetwo\n", AppLog.read());
        AppLog.clear();
        assertEquals("", AppLog.read());
    }

    @Test
    public void truncatesOldContent() {
        AppLog.clear();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < AppLog.MAX_CHARS + 100; i++) {
            text.append('x');
        }
        AppLog.append(text.toString());
        assertTrue(AppLog.read().length() <= AppLog.MAX_CHARS);
        assertTrue(AppLog.read().endsWith("x"));
    }
}
