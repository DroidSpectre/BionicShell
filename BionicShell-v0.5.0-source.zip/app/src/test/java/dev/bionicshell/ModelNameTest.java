package dev.bionicshell;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public final class ModelNameTest {
    @Test
    public void stripsPathAndUnsafeCharacters() {
        assertEquals("x_y.gguf", ModelRepository.safeName("../../x y.gguf"));
        assertEquals("model.gguf", ModelRepository.safeName(""));
        assertEquals("MO.GGUF", ModelRepository.safeName("/sdcard/MO.GGUF"));
    }

    @Test
    public void appendsGgufExtension() {
        assertEquals("model.gguf", ModelRepository.safeName("model"));
        assertEquals("model.gguf", ModelRepository.safeName("model.gguf"));
    }
}
