package dev.bionicshell;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.test.InstrumentationTestCase;

public final class ScreenRenderTest extends InstrumentationTestCase {
    public void testRendererDrawsBackgroundAndText() {
        Bitmap bitmap = Bitmap.createBitmap(240, 160, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        ScreenBuffer buffer = new ScreenBuffer(4, 20);
        buffer.putChar('H');
        buffer.putChar('i');
        TerminalRenderer renderer = new TerminalRenderer(
                getInstrumentation().getTargetContext());
        renderer.render(canvas, buffer, 0, null, false);
        assertEquals(TerminalRenderer.DEFAULT_BG, bitmap.getPixel(239, 159));
    }
}
