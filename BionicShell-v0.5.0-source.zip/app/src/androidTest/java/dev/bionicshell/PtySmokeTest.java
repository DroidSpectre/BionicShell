package dev.bionicshell;

import android.test.InstrumentationTestCase;

import java.io.FileInputStream;

public final class PtySmokeTest extends InstrumentationTestCase {
    public void testShellPrintsToPty() throws Exception {
        String[] envp = new String[] {
                "HOME=" + getInstrumentation().getTargetContext().getFilesDir().getAbsolutePath(),
                "PATH=/system/bin",
                "TERM=xterm-256color"
        };
        int[] pid = new int[1];
        int fd = PtyNative.open(
                new String[] { "/system/bin/sh", "-c", "printf 'pty-ok'" },
                envp,
                getInstrumentation().getTargetContext().getFilesDir().getAbsolutePath(),
                24,
                80,
                pid);
        assertTrue(fd >= 0);
        FileInputStream input = new FileInputStream("/proc/self/fd/" + fd);
        byte[] buffer = new byte[64];
        int count = input.read(buffer);
        input.close();
        PtyNative.close(fd);
        PtyNative.waitFor(pid[0]);
        assertTrue(count > 0);
        assertTrue(new String(buffer, 0, count, "UTF-8").contains("pty-ok"));
        assertTrue(pid[0] > 0);
    }
}
