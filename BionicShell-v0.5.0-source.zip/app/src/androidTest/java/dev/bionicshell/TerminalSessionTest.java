package dev.bionicshell;

import android.content.Context;
import android.test.InstrumentationTestCase;

import java.io.UnsupportedEncodingException;

public final class TerminalSessionTest extends InstrumentationTestCase {
    public void testShellSessionAcceptsInputAndReturnsOutput() throws Exception {
        Context context = getInstrumentation().getTargetContext();
        TerminalSession.Listener listener = new TerminalSession.Listener() {
            public void onScreenChanged() {
            }

            public void onExit(int status) {
            }
        };
        TerminalSession session = TerminalSession.start(context, 24, 80, listener);
        try {
            session.write(bytes("printf 'session-ok\\n'\r"));
            long deadline = System.currentTimeMillis() + 5000;
            String text = "";
            while (System.currentTimeMillis() < deadline) {
                synchronized (session.getBufferLock()) {
                    text = session.getBuffer().copyAll();
                }
                if (text.contains("session-ok")) {
                    break;
                }
                Thread.sleep(50);
            }
            assertTrue("output was: " + text, text.contains("session-ok"));
            assertTrue(session.getPid() > 0);
            assertTrue(session.isRunning());
        } finally {
            session.close();
        }
    }

    private static byte[] bytes(String value) throws UnsupportedEncodingException {
        return value.getBytes("UTF-8");
    }
}
