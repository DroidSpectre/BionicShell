# BionicShell Design

- Date: 2026-10-19
- Status: Approved for implementation; screen-grid terminal revision
- Working name: BionicShell
- Package: `dev.bionicshell.app`
- Target device: Samsung SM-G781V Galaxy S20 FE 5G, Android 13 / SDK 33, arm64
- Minimum Android: SDK 26
- Target SDK: 36
- ABI: `arm64-v8a` only

## 1. Context

The existing AnyClaw/Aetherix environment runs a Debian userland through PRoot. PRoot intercepts syscalls with ptrace, which is the wrong foundation for full-speed llama.cpp and adds substantial complexity. Android 13 on this device has no usable unprivileged user namespaces, no AVF support, and W^X prevents executing files from app data.

This project is a clean-room successor focused on a native bionic runtime:

- A Java 6-syntax Android app provides a terminal and runtime control surface.
- The shell is Android's own bionic `/system/bin/sh`.
- llama.cpp runs as native Android arm64 code from `nativeLibraryDir`.
- No PRoot, root, Alpine, musl userland, chroot, or syscall interception is used in the MVP.

The app is intended for offline use first. Agent CLI support is Phase 2 and will use a local llama.cpp OpenAI-compatible endpoint.

## 2. Decisions

- Runtime policy: bionic host plus external program runtimes.
- Implementation approach: thin native host; no bundled bionic userland.
- MVP scope: terminal, bionic shell, llama.cpp CLI/server, model selection.
- UI: native Android console, not WebView.
- Terminal behavior: character-grid terminal with a minimal VT100/xterm subset: UTF-8, CR/LF/BS/TAB, SGR, cursor movement, erase, autowrap, scrollback, alternate screen, and bracketed paste. Mouse, sixel, hyperlinks, and complete curses compatibility are out of scope.
- llama.cpp source: official Android arm64 release build, pinned and stripped. No on-device compiler and no bundled NDK toolchain in the APK.
- App code is original and Java 6 in language style. No Aetherix-Alpine or AnyClaw source files are reused.
- Agent CLIs (Codex, OpenCode, Grok) are not part of the MVP. They are treated as external programs in Phase 2.

## 3. Goals

- Launch a responsive native terminal on the S20 FE without PRoot overhead.
- Run `/system/bin/sh` under a real PTY with working stdin, stdout, stderr, resize, and signals.
- Run llama.cpp at native CPU speed and generate tokens from a user-supplied GGUF model.
- Provide reliable selectable output, copy, paste, share, log save, and stable keyboard focus.
- Keep the APK small by shipping only the stripped llama.cpp files that are actually used.
- Keep the app free of analytics, ads, unauthenticated control bridges, SSH, and background network exposure.
- Keep all new Java source free of lambdas, diamond operators, and newer language constructs.

## 4. Non-Goals

- Full Debian, apt, systemd, or a POSIX userland.
- PRoot, proot-distro, chroot, root, Magisk, or Shizuku.
- Alpine or a musl userland.
- Full VT100/xterm emulation, mouse reporting, sixel images, hyperlinks, or guaranteed curses/vim/tmux compatibility. A minimal screen-grid subset is included.
- 32-bit ABIs.
- Agent CLI execution in the MVP.
- Cloud model downloads or telemetry.
- Play Store distribution.

## 5. Architecture

```text
MainActivity
  TerminalView (custom view: screen output, cursor, selection, IME input)
  Toolbar actions (copy/paste/share/save/logs/models/server)
        |
        v
TerminalSessionManager
        |
        v
TerminalSession
  reader thread: PTY master -> incremental UTF-8 -> AnsiParser -> ScreenBuffer
  UI thread: ScreenBuffer changed -> TerminalView invalidation
  writer: TerminalView -> KeyHandler -> PTY master
        |
        v
libpty.so (JNI)
  posix_openpt / grantpt / unlockpt / ptsname
  fork / setsid / TIOCSCTTY / dup2 / execve
        |
        v
/system/bin/sh  (bionic mksh)
        |
        +--> liblauncher.so llama-cli  -> nativeLibraryDir/libllama-cli.so
        +--> liblauncher.so llama-server -> nativeLibraryDir/libllama-server.so
```

The app process is the supervisor. Child processes inherit the app UID and SELinux domain. No component exposes a control socket.

## 6. Components

### 6.1 `MainActivity`

- Single-activity terminal UI.
- Owns `TerminalSession`, `ModelRepository`, and `LlamaController`.
- Handles toolbar actions and dialogs for models and server control.
- Hosts one custom `TerminalView`; there is no separate output `TextView` or input `EditText`.
- Requests focus for `TerminalView` on startup; output updates never move focus.
- Uses `android.app.Activity` and platform widgets; no AndroidX, WebView, Compose, or Kotlin.

### 6.2 `TerminalSessionManager`

- Process-wide singleton that owns the active `TerminalSession`.
- Survives activity recreation and configuration changes.
- Reattaches the activity's `TerminalView` to the existing `ScreenBuffer` and PTY.
- Closes the session when the user explicitly exits or the process dies.

### 6.3 `TerminalSession`

- Opens a PTY with the requested rows and columns.
- Executes `/system/bin/sh` as a login/interactive shell with a controlled environment.
- Owns the `AnsiParser`, `ScreenBuffer`, reader thread, and writer queue.
- Reader reads 4-16 KiB chunks, decodes incrementally, and appends to the screen buffer; UI invalidation is coalesced and occurs on the main thread.
- `resize(rows, cols)` updates the PTY with `TIOCSWINSZ` and resizes the screen buffer without losing the cursor or scrollback.
- Ctrl-C sends byte `0x03` to the PTY so the kernel delivers `SIGINT` to the foreground process group; the toolbar Ctrl-C uses the same path.
- Reports process exit and closes file descriptors exactly once.

### 6.4 `PtyNative`

Small JNI library built with the NDK.

- `open(argv, env, cwd, rows, cols)` returns the master file descriptor and child PID.
- `resize(fd, rows, cols)` uses `TIOCSWINSZ`.
- `close(fd)` closes the master.
- The child calls `setsid`, `ioctl(TIOCSCTTY)`, duplicates the slave to stdin/stdout/stderr, and `execve`s the target.
- Environment includes `HOME`, `PATH=/system/bin`, `TMPDIR`, `TERM=xterm-256color`, and `LD_LIBRARY_PATH`.

### 6.5 `NativeLauncher`

Small C executable packaged as `liblauncher.so`.

- Sets `argv[0]` to the requested program name.
- Sets or overrides environment variables.
- Changes to the requested working directory.
- Executes the target from `nativeLibraryDir`.
- Supports future file-descriptor injection for the glibc/agent-CLI phase.

The launcher is required because Java cannot set `argv[0]` independently of the executable path, and some llama.cpp launchers may inspect their program name.

### 6.6 `AnsiParser`

Stateful byte/code-point parser for a minimal VT100/xterm screen terminal. It updates `ScreenBuffer`; it does not produce an append-only string.

- Incremental UTF-8 decoding, including sequences split across reads.
- Printable text, bell, backspace, horizontal tab, line feed, and carriage return.
- SGR: reset, bold, dim, underline, reverse, 16-color, 256-color, and 24-bit foreground/background.
- CSI: cursor up/down/left/right, cursor position, erase in display/line, insert/delete characters, insert/delete lines, scroll up/down, save/restore cursor, and scrolling region.
- DECSET/DECRST: autowrap, cursor visibility, alternate screen (`?1049`), bracketed paste (`?2004`), and application cursor keys (`?1`).
- ESC: save/restore cursor, index, reverse index, next line, and terminal reset.
- OSC: window title (`0`/`2`); other OSC strings are consumed and ignored.
- Unknown, unsupported, and malformed sequences are consumed without printing their bytes.
- No mouse reporting, sixel, hyperlinks, or clipboard OSC handling in the MVP.

### 6.7 `ScreenBuffer`

- Fixed rows and columns for the visible screen, plus up to 2,000 scrollback rows.
- Cells store a code point, a style word, and a wide-character continuation flag.
- Tracks cursor row/column, saved cursor, current style, scroll region, autowrap, and wrapped-line flags.
- Maintains separate main and alternate screen buffers for `?1049`.
- Implements the screen operations requested by `AnsiParser`; CR overwrites the current row, LF scrolls only at the bottom margin, and backspace moves within the row.
- `resize(rows, cols)` preserves content and cursor where possible, reflows wrapped rows, and clamps the cursor.
- `getSelectedText(startRow, startCol, endRow, endCol)` trims trailing blanks, joins wrapped rows correctly, and emits plain UTF-8 text without ANSI codes.
- `copyAll()` returns the scrollback plus visible screen with trailing blank rows removed.
- Trims the oldest scrollback rows on overflow.

### 6.8 `TerminalView`

- Custom `View` that renders the `ScreenBuffer` with `Canvas`; no `TextView`, `EditText`, or WebView.
- Delegates drawing to `TerminalRenderer`, which batches styled runs instead of issuing one `drawText` call per cell.
- Monospace font, configurable text size, and a visible block/underline cursor.
- Owns keyboard focus and implements `onCheckIsTextEditor()` and `onCreateInputConnection()` using `BaseInputConnection`.
- Converts IME text and hardware key events through `KeyHandler`; Enter sends `\r`, not `\n`.
- Starts text selection on long-press, supports drag selection, and exposes Copy, Copy All, and Paste through the context menu and toolbar.
- Vertical drag and fling scroll through scrollback; auto-scrolls only when already at the bottom.
- On size change, computes columns and rows from font metrics, debounces 100-150 ms, ignores zero/hidden sizes, and calls `TerminalSession.resize()`.
- Requests focus when attached, but output updates never request focus or close the IME.
- Uses `adjustResize` so the grid shrinks above the keyboard instead of being panned off-screen.

### 6.9 `KeyHandler`

- Maps Android key events and IME code points to PTY bytes.
- Handles Enter (`\r`), Backspace (`0x7f` or `0x08` as configured), Tab, Escape, arrows, Home/End, Page Up/Down, Insert/Delete, and function keys.
- Handles Ctrl combinations as control bytes and Alt as an ESC prefix.
- Uses normal or application cursor-key sequences according to `?1`.
- Encodes UTF-8 text without local echo; the PTY/shell owns echo.
- Supports bracketed paste when `?2004` is enabled.

### 6.10 `AppLog`

- In-app ring buffer for lifecycle, process, server, and error events.
- Separate `LogActivity` with selectable text and the same copy/share/save actions.
- `llama-server` stdout/stderr goes here by default so server logs do not mix with terminal output.
- Does not read logcat and does not upload anything.

### 6.11 `ModelRepository`

- Lists `.gguf` files in `getExternalFilesDir("models")`.
- Imports a model through `ACTION_OPEN_DOCUMENT` and copies it into the model directory with progress.
- Rejects path traversal and non-`.gguf` names.
- Displays name and size; supports delete.
- No model is bundled in the APK.

### 6.12 `LlamaController`

- Starts and stops `llama-cli` or `llama-server` through `NativeLauncher`.
- Builds arguments from the selected model, thread count, context size, and port.
- Default server endpoint: `127.0.0.1:9931`.
- Generates a per-install API key with `SecureRandom` and stores it in `SharedPreferences`.
- Passes `--api-key` when supported by the pinned llama.cpp build; the server still binds loopback only.
- Routes `llama-cli` stdout/stderr to the terminal and `llama-server` stdout/stderr to `AppLog`.
- Tracks process state and prevents duplicate server instances.

## 7. Runtime Layout

App-private files:

```text
files/
  home/
    .profile
    .mkshrc
  tmp/
  models/
  exports/
cache/
  ...
```

External app-specific files:

```text
getExternalFilesDir("models")/    # user-visible via USB/file manager
getExternalFilesDir("exports")/   # saved terminal/app logs
```

Executables and native libraries:

```text
nativeLibraryDir/
  libpty.so
  liblauncher.so
  libllama-cli.so
  libllama-server.so
  libllama-cli-impl.so
  libllama-server-impl.so
  libllama-common.so
  libllama.so
  libmtmd.so
  libggml.so
  libggml-base.so
  libggml-cpu-android_*.so
```

Shell profile:

- Exports `HOME`, `PATH`, `TMPDIR`, `LD_LIBRARY_PATH`, and `TERM`.
- Defines `llama-cli` and `llama-server` aliases that call `liblauncher.so`.
- The app starts `sh -l`; if the profile is not loaded by the device shell, it starts `sh -c '. "$HOME/.profile"; exec sh -i'`.
- Startup verifies that aliases resolve; failure is written to `AppLog`.

## 8. llama.cpp Payload

### 8.1 Pinned source

Use the official Android arm64 asset from the `b11669` nightly release:

```text
https://github.com/ggml-org/llama.cpp/releases/download/b11669/llama-b11669-bin-android-arm64.tar.gz
SHA-256: 640f870f795b3b2939ed40d1a31ce529ecc4865abfc5d0f5153168bc4b82e5c8
```

The Snapdragon-specific asset is an optional test candidate:

```text
https://github.com/ggml-org/llama.cpp/releases/download/b11669/llama-b11669-bin-android-arm64-snapdragon.tar.gz
SHA-256: a649d73ca54fc761903a40428d17004ae9911ad4e36bb9a83d22117d7a614539
```

The generic build is the default because the S20 FE uses a Snapdragon 865 and the generic build carries runtime CPU variants. The Snapdragon build is tested only if the generic build fails.

### 8.2 Minimal set

The payload includes:

- `llama-cli` renamed to `libllama-cli.so`.
- `llama-server` renamed to `libllama-server.so`.
- `libllama-cli-impl.so`.
- `libllama-server-impl.so` (required by the official CLI launcher).
- `libllama-common.so`.
- `libllama.so`.
- `libmtmd.so`.
- `libggml.so`.
- `libggml-base.so`.
- All `libggml-cpu-android_*.so` variants from the asset.
- `LICENSE`.

`libllama-completion-impl.so` and unrelated tools are excluded.

### 8.3 Stripping

Every ELF file is stripped with:

```text
strip --strip-unneeded <file>
```

The unstripped minimal set is about 231 MB. After stripping, the tested minimal set is about 22.7 MB with two armv8.2 CPU variants; including all CPU variants is about 27 MB. Stripping must preserve `DT_SONAME` and dynamic symbols. `readelf -d` is checked after stripping.

### 8.4 Packaging

- Place files in `app/src/main/jniLibs/arm64-v8a/`.
- Set `android:extractNativeLibs="true"` and Gradle `useLegacyPackaging = true`.
- `System.loadLibrary("pty")` loads `libpty.so`.
- `liblauncher.so` and the llama.cpp launchers are executed by absolute path.
- `LD_LIBRARY_PATH` is set to `nativeLibraryDir`.
- `libggml` backend discovery is verified on device. If it does not find the CPU variants, the payload is rebuilt from llama.cpp source with a statically linked CPU backend and pinned as the replacement payload.

## 9. Terminal and UI

### 9.1 Output

- One custom `TerminalView` renders the screen grid with a monospace font and configurable text size.
- The renderer draws text runs with foreground/background colors, bold, underline, reverse video, and a block/underline cursor.
- Partial lines, carriage-return overwrites, tabs, wrapped lines, and cursor-addressed output appear in place.
- The visible screen and scrollback are selectable; the toolbar operates on the selection when present, otherwise on the entire buffer.
- Auto-scrolls only when the user is already at the bottom; selection or manual scroll suspends auto-scroll.
- No `TextView`, `SpannableStringBuilder`, or ANSI-stripped line buffer is used for terminal output.

### 9.2 Input

- `TerminalView` is the only keyboard focus owner; there is no separate input field.
- `adjustResize` window mode and `IME_FLAG_NO_EXTRACT_UI`.
- IME text is committed directly to the PTY through `KeyHandler`; composition text is not echoed locally.
- Enter sends `\r`; Backspace sends `0x7f`; Ctrl-C sends `0x03`; Ctrl-D sends `0x04`; Tab sends `0x09`.
- Hardware arrows, Home/End, Page Up/Down, Insert/Delete, and function keys are forwarded with terminal escape sequences.
- The extra-keys row provides Esc, Tab, Ctrl, Alt, arrows, Ctrl-C, and a paste action.
- `TYPE_NULL` is the primary IME mode. If the S20 FE Samsung keyboard refuses to show, fall back to `TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | TYPE_TEXT_FLAG_NO_SUGGESTIONS`, as tested by Aetherix.
- Input keeps focus after sending; selecting output or scrolling does not close the keyboard.

### 9.3 Copy, paste, share, save

- Copy: selected grid text; trailing blanks are trimmed and wrapped rows are joined correctly.
- Copy All: scrollback plus visible screen.
- Paste: clipboard text is sent directly to the PTY, never into a local input widget; bracketed paste is used when enabled.
- Share: `ACTION_SEND` with `text/plain`.
- Save: writes a UTF-8 text log to `getExternalFilesDir("exports")/terminal-YYYYMMDD-HHMMSS.txt`.
- File share: a minimal app `ContentProvider` serves the saved file with `FLAG_GRANT_READ_URI_PERMISSION`; no AndroidX FileProvider.
- The same actions are available on the app log screen.

### 9.4 Keyboard and logs

- No WebView and no separate `EditText`, so focus does not bounce between output and input.
- The app log is separate from terminal output; the user can copy/share either without mixing streams.
- `llama-server` logs go to the app log; `llama-cli` and shell output go to the terminal.
- Soft keyboard show/hide is controlled by `TerminalView`; output updates never steal focus.

## 10. Data Flow

1. App starts, creates runtime directories, writes the shell profile, and starts `TerminalSession`.
2. `PtyNative` opens a PTY, forks, and execs `/system/bin/sh`.
3. Shell output is read from the PTY master, decoded as UTF-8, parsed by `AnsiParser`, applied to `ScreenBuffer`, and rendered by `TerminalView`.
4. Key events and pasted text are encoded by `KeyHandler` and written to the PTY master; the shell owns echo.
5. `llama-cli` or `llama-server` is launched from `nativeLibraryDir` through `liblauncher.so`.
6. `llama-cli` output goes to the terminal; `llama-server` stdout/stderr goes to `AppLog`; the server listens on `127.0.0.1:9931`.
7. Model files are listed from app-specific external storage and passed as absolute paths.

## 11. Process Lifecycle

- `TerminalSessionManager` retains the shell across configuration changes; the activity reattaches to the existing session.
- The shell is terminated when the user closes the session or the app process dies.
- The server is stopped explicitly by the user; the MVP does not add a foreground service.
- If the app is backgrounded, Android may kill the server. This is documented for the MVP.
- Phase 2 adds a foreground service for persistent offline agent use.
- No orphan child processes: the app tracks PIDs and kills its process group on shutdown.

## 12. Security

- No PRoot, root, Shizuku, DeviceBridge, BeanShell, or SSH.
- No exported services, receivers, or providers. The main launcher activity is the only exported component; the log content provider is non-exported with URI grants.
- No unauthenticated control socket.
- Server binds `127.0.0.1` only, with a per-install API key.
- No analytics, ads, crash reporting, or telemetry.
- `allowBackup="false"`.
- No broad storage permissions; model files use app-specific external storage.
- Network security config permits cleartext only for `127.0.0.1` and `localhost`; all other cleartext traffic is denied.
- The log content provider is non-exported with `grantUriPermissions="true"`; the app grants temporary read access to the specific URI it shares.

## 13. Build and Toolchain

- No Gradle, no AGP, and no Gradle daemon.
- CodeAssist-style native pipeline: `aapt2 -> ECJ -> D8 -> zipalign -> apksigner`.
- Portable Temurin JRE 17 runs ECJ, D8, and apksigner. The host's Debian OpenJDK requires GLIBC_2.38 and does not run.
- `scripts/build.py` drives compilation, unit tests, APK packaging, signing, per-version archiving, and Downloads export.
- Android NDK r27c (`27.2.12479018`) for `libpty.so` and `liblauncher.so` when native compilation is added.
- `compileSdk 36`, `minSdk 26`, `targetSdk 36`.
- Java source compatibility is set to 1.8 because JDK 17 no longer supports `-source 1.6`; a custom checker enforces Java 6 language syntax.
- The host's `cp`, `sed`, `grep`, and `mkdir` are broken by a libselinux/glibc mismatch. Build scripts use Python for file operations; arm64 `aapt2` and `zipalign` from the Android SDK run directly.
- The llama.cpp fetch script uses Python `urllib`, verifies the SHA-256, extracts with `tarfile`, strips every ELF, and copies with `shutil`.
- Each version is committed with a `releases/v<version>/` source zip and APK, and exported to `/sdcard/Download/BionicShell/v<version>/` without build artifacts.

## 14. Java 6 Policy

Banned in all new Java source:

- Lambda expressions and method references.
- Diamond operator `<>`.
- Try-with-resources.
- Multi-catch.
- Strings in `switch`.
- Binary literals and underscores in numeric literals.
- `var`.
- Default or static interface methods.
- Java 7+ APIs that have no Android equivalent on the chosen minimum.

Use anonymous inner classes, explicit generic arguments, and Java 6 control flow. A `checkJava6` Gradle task runs `scripts/check_java6.py` before compilation and fails the build on violations.

## 15. Testing

### 15.1 Unit tests

- `AnsiParserTest`: UTF-8, CR overwrite, BS, TAB, SGR colors, cursor movement, erase, insert/delete, scrolling region, alternate screen, bracketed paste, and unknown-sequence consumption.
- `ScreenBufferTest`: grid dimensions, autowrap, scrollback trim, wrapped-line selection, copy-all trimming, alt-screen switch, and resize/cursor clamping.
- `KeyHandlerTest`: Enter as `\r`, Backspace, Tab, arrows, application cursor mode, Ctrl combinations, Alt prefix, and UTF-8 input.
- `ModelNameTest`: path traversal rejection and extension checks.

### 15.2 Instrumentation tests

- `PtySmokeTest`: open a PTY, run `/system/bin/sh -c 'printf hello'`, assert output.
- `ScreenRenderTest`: feed `printf 'one\rtwo\n'`, long wrapped lines, and cursor movement; assert the rendered grid, not a line log.
- `CopyPasteTest`: select grid text, copy it, paste it into a second PTY, and assert exact bytes; Copy All excludes ANSI codes.
- `LauncherSmokeTest`: run `liblauncher.so llama-cli --version`, assert exit 0.
- `PayloadTest`: verify all expected native files exist and are executable.
- `ServerSmokeTest` (device test, requires a user-supplied tiny GGUF): start `llama-server`, GET `/v1/models`, assert HTTP 200, stop.

### 15.3 Device checks

- Shell prompt appears; `echo`, `pwd`, `ls /system/bin` work.
- `printf 'one\rtwo\n'` shows only `two` on that row.
- Long lines wrap at the terminal column count, not at arbitrary pixel width.
- Cursor movement and clear-line output render in place; scrollback scrolls.
- `llama-cli` loads a GGUF and generates tokens, including streaming partial lines.
- `llama-server` responds on `127.0.0.1:9931`; its logs stay in `AppLog`.
- Selection, Copy, Copy All, paste, share, save, and log export work.
- Keyboard focus remains stable while selecting output, scrolling, and switching apps.
- App log and terminal output can be shared separately.
- No child process remains after stopping a session or server.
- Java 6 checker passes.
- APK contains only the intended arm64 native files.

## 16. Success Criteria

- APK builds and installs on the S20 FE.
- Terminal starts without PRoot or root.
- Shell commands execute with correct stdin/stdout/stderr.
- The screen grid handles CR overwrites, backspace, wrapping, cursor movement, scrollback, and alternate-screen output without duplicated lines.
- llama.cpp runs from `nativeLibraryDir` at native CPU speed; tokens/s is recorded and is at least the PRoot baseline for the same model.
- Local server responds to `/v1/models` and `/v1/chat/completions`.
- Selection/copy/paste/share/save and keyboard focus meet the stated behavior.
- APK is under 35 MB.
- No Aetherix-Alpine or AnyClaw code is present.
- All MVP Java source passes the Java 6 checker.

## 17. Phases

### Phase 1: MVP

- Clean-room project skeleton.
- PTY, screen-grid terminal, bionic shell.
- llama.cpp CLI/server payload, model repository, local server control.
- Selection/copy/paste/share/logs.
- Device tests and performance baseline.

### Phase 2: Offline agent CLI

- Packaged glibc loader and runtime for glibc-linked CLIs.
- Codex, OpenCode, and Grok runtime integration pointed at `http://127.0.0.1:9931/v1`.
- Foreground service for persistent local server.
- DNS/file-descriptor injection and certificate handling for external CLIs.
- Per-CLI wrappers and offline model presets.

### Phase 3: Tooling and polish

- Optional on-device llama.cpp rebuild path.
- Bionic tool pack (curl, tar, git, etc.) if needed.
- Benchmarks, model presets, and export/import of settings.

## 18. Risks and Mitigations

- **Official llama.cpp backend discovery fails:** package all CPU variants and test; if needed, set an explicit backend path or load the matching variant.
- **Renamed launchers misbehave:** use `liblauncher.so` to set `argv[0]`; test `--version` before UI integration.
- **Host toolchain is broken:** bootstrap Temurin, NDK, and a static shell toolset; keep build scripts Python-first.
- **Screen-grid parser scope creep:** implement only the documented subset; consume unknown sequences; do not add mouse, sixel, or hyperlinks in the MVP.
- **Terminal resize/IME races:** use a real PTY `TIOCSWINSZ`, debounce 100-150 ms, preserve cursor, and test the Samsung keyboard; do not copy Aetherix's SPACE+DEL warmup or `term_size`/`libfaketty` workarounds.
- **Custom view selection/IME complexity:** keep one `TerminalView`, a row/column selection model, and `BaseInputConnection`; test copy/paste and composition on the target device.
- **Rendering cost on large output:** coalesce invalidations, draw style runs, cap scrollback at 2,000 rows, and avoid per-cell UI work on the reader thread.
- **Server dies in background:** document the MVP limitation; add a foreground service in Phase 2.
- **Pinned nightly disappears:** mirror the verified asset in the project release or CI cache; the SHA-256 is recorded.
- **APK size grows:** exclude unused tools, strip all ELF files, and keep all CPU variants as the only optional payload expansion.

## 19. Assumptions

- The device remains on Android 13 and arm64.
- The user supplies GGUF models; no model is bundled.
- Sideloading is acceptable.
- The app name and package can be changed before release; this spec uses BionicShell and `dev.bionicshell.app`.
- The official llama.cpp Android build remains MIT-licensed and redistributable with its LICENSE file.

## 20. Clean-Room and Licensing

- No Aetherix-Alpine, Aetherix Studio, or AnyClaw source files are copied or adapted.
- No Termux or Aetherix terminal-emulator/view source is copied. Their PTY and screen-grid behavior was studied only as prior art.
- Only behavioral facts from the prior analysis are used.
- All Java and C app code is new.
- llama.cpp is an external MIT-licensed program; its LICENSE is included in the APK notices.
- Android NDK, the build pipeline, and the Android platform are build/runtime tools, not app source.
- The MVP contains no glibc, PRoot, or musl userland.

## 21. Project Layout

```text
/root/bionicshell/
  scripts/
    build.py
    env.sh
    check_java6.py
  app/
    version.properties
    src/main/AndroidManifest.xml
    src/main/java/dev/bionicshell/
      MainActivity.java
      LogActivity.java
      TerminalSessionManager.java
      TerminalSession.java
      TerminalView.java
      TerminalRenderer.java
      KeyHandler.java
      ScreenBuffer.java
      AnsiParser.java
      AppLog.java
      ModelRepository.java
      LlamaController.java
      NativeLauncher.java
      LogContentProvider.java
      ...
    src/main/jni/
      CMakeLists.txt
      pty.c
      launcher.c
    src/main/jniLibs/arm64-v8a/   # generated by fetch script
    src/main/res/
    src/test/java/dev/bionicshell/
    src/androidTest/java/dev/bionicshell/
  scripts/
    fetch_llama.py
    check_java6.py
    build.sh
  docs/superpowers/specs/2026-10-19-bionicshell-design.md
```

## 22. Verified Facts Used by This Design

- Android 13 on the S20 FE has no usable unprivileged user namespaces and no AVF support.
- App-data execution is blocked even when `File.canExecute()` returns true; `nativeLibraryDir` is the executable location.
- The official llama.cpp Android arm64 binaries use `/system/bin/linker64` and bionic libraries.
- The official `llama-cli` launcher links `libllama-server-impl.so`, so that library is required even for CLI-only use.
- The official binaries are unstripped; `strip --strip-unneeded` reduced `libllama-common.so` from 86,653,384 bytes to 5,900,136 bytes in testing.
- The minimal stripped payload with two armv8.2 CPU variants is about 22.7 MB uncompressed.
- Termux uses a PTY plus the character-grid `TerminalEmulator`/`TerminalBuffer`/`TerminalView`; it does not use a line-oriented display buffer.
- Aetherix-Alpine uses Termux-derived terminal classes and feeds raw PTY bytes to `TerminalEmulator.append()`. Its `onOutput(String)` line callback is empty; only `onOutputBytes()` is used for display.
- Aetherix needed resize/readline workarounds (SPACE+DEL warmup, prompt-terminator heuristics, `term_size`/`libfaketty`, input blocking, resize debounce) because its PTY/fake-TTY path had races. These are evidence against prompt/line heuristics, not a design to copy.
- Codex is a static aarch64 binary; OpenCode has a glibc build requiring only GLIBC_2.17. These facts are reserved for Phase 2 and are not part of the MVP.
