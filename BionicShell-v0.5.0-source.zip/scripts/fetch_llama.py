#!/usr/bin/env python3
import argparse
import hashlib
import os
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request
from pathlib import Path

APP = Path(__file__).resolve().parent.parent / "app"
JNI_LIBS = APP / "src" / "main" / "jniLibs" / "arm64-v8a"
ASSET_LICENSE = APP / "src" / "main" / "assets" / "llama.cpp" / "LICENSE"

ASSETS = {
    "generic": {
        "url": "https://github.com/ggml-org/llama.cpp/releases/download/b11669/"
               "llama-b11669-bin-android-arm64.tar.gz",
        "size": 75478449,
        "sha256": "640f870f795b3b2939ed40d1a31ce529ecc4865abfc5d0f5153168bc4b82e5c8",
        "archive": "llama-b11669-bin-android-arm64.tar.gz",
    },
    "snapdragon": {
        "url": "https://github.com/ggml-org/llama.cpp/releases/download/b11669/"
               "llama-b11669-bin-android-arm64-snapdragon.tar.gz",
        "size": 59529707,
        "sha256": "a649d73ca54fc761903a40428d17004ae9911ad4e36bb9a83d22117d7a614539",
        "archive": "llama-b11669-bin-android-arm64-snapdragon.tar.gz",
    },
}

REQUIRED = {
    "llama-cli",
    "llama-server",
    "libllama-cli-impl.so",
    "libllama-server-impl.so",
    "libllama-common.so",
    "libllama.so",
    "libmtmd.so",
    "libggml.so",
    "libggml-base.so",
    "LICENSE",
}

PAYLOAD_PREFIXES = ("libllama", "libggml", "libmtmd")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def payload_target_name(name):
    base = name.rsplit("/", 1)[-1]
    if base == "llama-cli":
        return "libllama-cli.so"
    if base == "llama-server":
        return "libllama-server.so"
    return base


def is_selected(base, variant):
    if base in REQUIRED:
        return True
    if variant == "generic":
        return base.startswith("libggml-cpu-android_") and base.endswith(".so")
    if variant == "snapdragon":
        return base == "libggml-cpu.so"
    return False


def select_payload_names(names, variant="generic"):
    selected = set()
    for name in names:
        base = name.rsplit("/", 1)[-1]
        if is_selected(base, variant):
            selected.add(base)
    return selected


def download(url, destination):
    destination = Path(destination)
    request = urllib.request.Request(url, headers={"User-Agent": "BionicShell-build"})
    with urllib.request.urlopen(request, timeout=600) as response:
        with open(destination, "wb") as handle:
            shutil.copyfileobj(response, handle)
    return destination


def verify_archive(path, asset):
    size = os.path.getsize(path)
    if size != asset["size"]:
        raise SystemExit("size mismatch: expected %d, got %d" % (asset["size"], size))
    digest = sha256_file(path)
    if digest != asset["sha256"]:
        raise SystemExit("sha256 mismatch: expected %s, got %s" % (asset["sha256"], digest))


def extract_payload(archive, staging, variant):
    staging = Path(staging)
    staging.mkdir(parents=True, exist_ok=True)
    selected = set()
    with tarfile.open(archive, "r:gz") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            base = member.name.rsplit("/", 1)[-1]
            if not is_selected(base, variant):
                continue
            with tar.extractfile(member) as source:
                target = staging / base
                with open(target, "wb") as output:
                    shutil.copyfileobj(source, output)
            selected.add(base)
    missing = REQUIRED - selected
    if missing:
        raise SystemExit("missing payload files: %s" % ", ".join(sorted(missing)))
    return selected


def find_strip():
    for name in ("aarch64-linux-gnu-strip", "llvm-strip", "strip"):
        path = shutil.which(name)
        if path:
            return path
    raise SystemExit("no working strip tool found")


def strip_payload(staging):
    strip = find_strip()
    for path in sorted(Path(staging).glob("*")):
        if path.name == "LICENSE":
            continue
        subprocess.run([strip, "--strip-unneeded", str(path)], check=True)


def install_payload(staging, app_dir):
    destination = Path(app_dir) / "src" / "main" / "jniLibs" / "arm64-v8a"
    destination.mkdir(parents=True, exist_ok=True)
    for path in destination.iterdir():
        if path.is_file() and path.name.startswith(PAYLOAD_PREFIXES):
            path.unlink()

    payload_bytes = 0
    for path in sorted(Path(staging).glob("*")):
        if path.name == "LICENSE":
            continue
        target = destination / payload_target_name(path.name)
        shutil.copy2(path, target)
        os.chmod(str(target), 0o755)
        payload_bytes += target.stat().st_size

    license_dir = Path(app_dir) / "src" / "main" / "assets" / "llama.cpp"
    license_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(staging) / "LICENSE", license_dir / "LICENSE")
    print("installed payload: %d bytes, %d libraries" %
          (payload_bytes, len([p for p in destination.iterdir() if p.is_file()])))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=sorted(ASSETS), default="generic")
    parser.add_argument("--source", default=None, help="existing archive to verify and use")
    parser.add_argument("--app", default=str(APP))
    args = parser.parse_args()

    asset = ASSETS[args.variant]
    archive = Path(args.source) if args.source else Path(tempfile.gettempdir()) / asset["archive"]
    if not archive.exists():
        print("downloading %s" % asset["url"])
        download(asset["url"], archive)
    verify_archive(archive, asset)

    staging = Path(tempfile.mkdtemp(prefix="llama-payload-"))
    try:
        extract_payload(archive, staging, args.variant)
        strip_payload(staging)
        install_payload(staging, args.app)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


if __name__ == "__main__":
    main()
