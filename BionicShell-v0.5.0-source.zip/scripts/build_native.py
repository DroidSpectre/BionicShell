#!/usr/bin/env python3
import argparse
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JNI = ROOT / "app" / "src" / "main" / "jni"
OUT = ROOT / "app" / "src" / "main" / "jniLibs" / "arm64-v8a"
API = "26"
TARGET = "aarch64-linux-android"


def log(message):
    print("[native] " + message, flush=True)


def find_ndk():
    candidates = []
    for key in ("ANDROID_NDK_HOME", "ANDROID_NDK_ROOT", "NDK_HOME"):
        value = os.environ.get(key)
        if value:
            candidates.append(Path(value))
    sdk = Path(os.environ.get("ANDROID_HOME", "/opt/android-sdk"))
    ndk_dir = sdk / "ndk"
    if ndk_dir.is_dir():
        candidates.extend(sorted(ndk_dir.iterdir(), reverse=True))
    for candidate in candidates:
        sysroot = candidate / "toolchains" / "llvm" / "prebuilt" / "linux-x86_64" / "sysroot"
        libdir = sysroot / "usr" / "lib" / TARGET / API
        clang = candidate / "toolchains" / "llvm" / "prebuilt" / "linux-x86_64" / "bin" / (
            TARGET + API + "-clang")
        if libdir.is_dir():
            return candidate, sysroot, libdir, clang
    raise SystemExit("no Android NDK r27+ sysroot found (set ANDROID_NDK_HOME)")


def can_run(path):
    if not path.is_file():
        return False
    try:
        return subprocess.run([str(path), "--version"], stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL).returncode == 0
    except OSError:
        return False


def find_gcc():
    for name in ("aarch64-linux-gnu-gcc", "aarch64-linux-gnu-gcc-12"):
        path = shutil.which(name)
        if path:
            return Path(path)
    return None


def run(command):
    log(" ".join(str(part) for part in command))
    subprocess.run([str(part) for part in command], check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--clean", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()

    ndk, sysroot, libdir, clang = find_ndk()
    log("NDK: %s" % ndk)
    host = platform.machine()
    log("host: %s" % host)

    use_clang = can_run(clang)
    gcc = find_gcc()
    if use_clang:
        compiler = clang
        crtbegin_so = crtend_so = crtbegin_dynamic = crtend_android = None
        log("compiler: NDK clang (%s)" % clang)
    elif host == "aarch64" and gcc is not None:
        compiler = gcc
        crtbegin_so = libdir / "crtbegin_so.o"
        crtend_so = libdir / "crtend_so.o"
        crtbegin_dynamic = libdir / "crtbegin_dynamic.o"
        crtend_android = libdir / "crtend_android.o"
        for path in (crtbegin_so, crtend_so, crtbegin_dynamic, crtend_android):
            if not path.is_file():
                raise SystemExit("missing bionic startup object: %s" % path)
        log("compiler: host GCC (%s) + bionic sysroot" % gcc)
    else:
        raise SystemExit(
            "NDK clang cannot run on host %s and no aarch64-linux-gnu-gcc fallback found" % host)

    if args.check:
        run([compiler, "--version"])
        log("sysroot: %s" % sysroot)
        return

    if args.clean and OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True, exist_ok=True)

    common = [
        compiler,
        "-O2",
        "-Wall",
        "-Wextra",
        "-Werror=implicit-function-declaration",
        "-fstack-protector-strong",
        "-I", sysroot / "usr" / "include",
        "-I", sysroot / "usr" / "include" / TARGET,
        "-Wl,-z,relro",
        "-Wl,-z,now",
        "-Wl,-z,max-page-size=16384",
    ]

    if use_clang:
        common += ["--target=" + TARGET + API, "-D_FORTIFY_SOURCE=2"]
    else:
        common += [
            "-Wno-attributes",
            "-U_FORTIFY_SOURCE",
            "-D_FORTIFY_SOURCE=0",
            "-D_Nonnull=",
            "-D_Nullable=",
            "-D_Null_unspecified=",
            "-D__BIONIC_VERSIONER=1",
            "-DBIONIC_IOCTL_NO_SIGNEDNESS_OVERLOAD=1",
            "-nostdlib",
        ]

    pty = OUT / "libpty.so"
    pty_command = common + [
        "-fPIC",
        "-shared",
        "-Wl,-soname,libpty.so",
        "-Wl,--no-undefined",
        "-o", pty,
        JNI / "pty.c",
    ]
    if not use_clang:
        pty_command += [crtbegin_so, crtend_so, "-L", libdir, "-lc"]
    run(pty_command)

    launcher = OUT / "liblauncher.so"
    launcher_command = common + [
        "-fPIE",
        "-pie",
        "-Wl,--no-undefined",
        "-o", launcher,
        JNI / "launcher.c",
    ]
    if not use_clang:
        launcher_command += [
            "-Wl,--dynamic-linker=/system/bin/linker64",
            crtbegin_dynamic,
            crtend_android,
            "-L", libdir,
            "-lc",
        ]
    run(launcher_command)

    strip = shutil.which("aarch64-linux-gnu-strip")
    if strip is None and use_clang:
        strip = str(ndk / "toolchains" / "llvm" / "prebuilt" / "linux-x86_64" / "bin" / "llvm-strip")
        if not Path(strip).is_file():
            strip = None
    if strip is not None:
        run([strip, "--strip-unneeded", pty, launcher])

    for path in (pty, launcher):
        os.chmod(str(path), 0o755)
        log("%s (%d bytes)" % (path, path.stat().st_size))


if __name__ == "__main__":
    main()
