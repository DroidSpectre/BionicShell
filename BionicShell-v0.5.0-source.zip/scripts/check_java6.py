#!/usr/bin/env python3
import re
import sys
from pathlib import Path

BANNED = [
    (re.compile(r"->"), "lambda or method reference"),
    (re.compile(r"::"), "method reference"),
    (re.compile(r"<>"), "diamond operator"),
    (re.compile(r"\btry\s*\("), "try-with-resources"),
    (re.compile(r"catch\s*\([^)]*\|"), "multi-catch"),
    (re.compile(r"\bvar\b"), "var"),
    (re.compile(r"0[bB][01]"), "binary literal"),
    (re.compile(r"\b\d+_\d"), "numeric underscore"),
]


def strip_comments_and_strings(text):
    out = []
    i = 0
    state = "code"
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if ch == "/" and nxt == "/":
                state = "line"
                out.append(" ")
                i += 2
                continue
            if ch == "/" and nxt == "*":
                state = "block"
                out.append(" ")
                i += 2
                continue
            if ch == '"':
                state = "string"
                out.append(" ")
            elif ch == "'":
                state = "char"
                out.append(" ")
            else:
                out.append(ch)
        elif state == "line":
            if ch == "\n":
                state = "code"
                out.append("\n")
            else:
                out.append(" ")
        elif state == "block":
            if ch == "*" and nxt == "/":
                state = "code"
                out.append("  ")
                i += 2
                continue
            out.append("\n" if ch == "\n" else " ")
        elif state in ("string", "char"):
            if ch == "\\":
                out.append("  ")
                i += 2
                continue
            if (state == "string" and ch == '"') or (state == "char" and ch == "'"):
                state = "code"
            out.append(" ")
        i += 1
    return "".join(out)


def check_text(text, name="<text>"):
    clean = strip_comments_and_strings(text)
    errors = []
    for pattern, label in BANNED:
        for match in pattern.finditer(clean):
            line = clean.count("\n", 0, match.start()) + 1
            errors.append("%s:%d: %s" % (name, line, label))
    if re.search(r"switch\s*\([^)]*\)\s*\{[^}]*case\s*\"", clean, re.S):
        errors.append("%s: string switch" % name)
    return errors


def main(paths):
    errors = []
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            files = sorted(path.rglob("*.java"))
        else:
            files = [path]
        for path_item in files:
            errors.extend(check_text(path_item.read_text(encoding="utf-8"), str(path_item)))
    for error in errors:
        print(error, file=sys.stderr)
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
