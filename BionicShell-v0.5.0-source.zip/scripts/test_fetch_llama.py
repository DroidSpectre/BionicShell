#!/usr/bin/env python3
import hashlib
import os
import tempfile
import unittest

from fetch_llama import payload_target_name, select_payload_names, sha256_file


class FetchLlamaTest(unittest.TestCase):
    def test_maps_executables_to_library_names(self):
        self.assertEqual("libllama-cli.so", payload_target_name("llama-cli"))
        self.assertEqual("libllama-server.so", payload_target_name("llama-server"))
        self.assertEqual("libllama.so", payload_target_name("libllama.so"))

    def test_selects_required_and_cpu_libraries(self):
        names = [
            "build/bin/llama-cli",
            "build/bin/llama-server",
            "build/bin/libllama.so",
            "build/bin/libggml-cpu-android_armv8.2_1.so",
            "build/bin/libggml-cpu-android_armv9.2_2.so",
            "build/bin/libllama-completion-impl.so",
            "build/bin/libggml-rpc.so",
            "build/bin/LICENSE",
        ]
        selected = select_payload_names(names)
        self.assertIn("llama-cli", selected)
        self.assertIn("libllama.so", selected)
        self.assertIn("libggml-cpu-android_armv8.2_1.so", selected)
        self.assertIn("libggml-cpu-android_armv9.2_2.so", selected)
        self.assertNotIn("libllama-completion-impl.so", selected)
        self.assertNotIn("libggml-rpc.so", selected)

    def test_snapdragon_selects_generic_cpu_library(self):
        selected = select_payload_names(
            ["bin/llama-cli", "lib/libggml-cpu.so", "lib/libggml-opencl.so"],
            "snapdragon")
        self.assertIn("libggml-cpu.so", selected)
        self.assertNotIn("libggml-opencl.so", selected)

    def test_sha256_file(self):
        with tempfile.NamedTemporaryFile(delete=False) as handle:
            handle.write(b"bionic")
            path = handle.name
        try:
            self.assertEqual(hashlib.sha256(b"bionic").hexdigest(), sha256_file(path))
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
