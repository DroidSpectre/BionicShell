export JAVA_HOME=/opt/jdk-17.0.20.1+1-jre
export ANDROID_HOME=/opt/android-sdk
export BIONIC_BUILD_TOOLCHAIN=/opt/bionic-build
export BIONIC_DOWNLOADS=/sdcard/Download/BionicShell
export PATH="$JAVA_HOME/bin:/opt/bionic-tools/bin:$PATH"
