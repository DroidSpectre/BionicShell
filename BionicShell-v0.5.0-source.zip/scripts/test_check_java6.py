#!/usr/bin/env python3
import unittest
from check_java6 import check_text


class CheckJava6Test(unittest.TestCase):
    def test_accepts_java6(self):
        source = "class A { void f() { java.util.List<String> x = new java.util.ArrayList<String>(); } }"
        self.assertEqual([], check_text(source))

    def test_rejects_lambda(self):
        self.assertTrue(check_text("class A { Runnable r = () -> {}; }"))

    def test_rejects_diamond(self):
        self.assertTrue(check_text("class A { java.util.List<String> x = new java.util.ArrayList<>(); }"))

    def test_ignores_comments_and_strings(self):
        self.assertEqual([], check_text('class A { String s = "-> <>"; /* -> */ }'))


if __name__ == "__main__":
    unittest.main()
