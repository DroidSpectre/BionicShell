package dev.bionicshell;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.Locale;

public final class CrashLog {
    private static final int MAX_FILE_BYTES = 256 * 1024;
    private static final String FILE_NAME = "crash.log";
    private static File sFile;
    private static boolean sInstalled;

    private CrashLog() {
    }

    public static void install(Context context) {
        if (context == null) {
            return;
        }
        synchronized (CrashLog.class) {
            if (sInstalled) {
                return;
            }
            File directory = RuntimePaths.logs(context);
            if (!directory.isDirectory() && !directory.mkdirs()) {
                return;
            }
            sFile = new File(directory, FILE_NAME);
            sInstalled = true;
        }
        final Thread.UncaughtExceptionHandler previous =
                Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread thread, Throwable error) {
                record(thread, error);
                if (previous != null) {
                    previous.uncaughtException(thread, error);
                }
            }
        });
    }

    private static void record(Thread thread, Throwable error) {
        StringWriter buffer = new StringWriter();
        PrintWriter writer = new PrintWriter(buffer);
        writer.println("crash at " + timestamp());
        writer.println("thread=" + thread.getName());
        error.printStackTrace(writer);
        writer.flush();
        String text = buffer.toString();
        String[] lines = text.split("\n");
        for (int i = 0; i < lines.length; i++) {
            AppLog.appendLine(AppLog.SYSTEM, lines[i]);
        }
        synchronized (CrashLog.class) {
            if (sFile == null) {
                return;
            }
            try {
                byte[] bytes = text.getBytes("UTF-8");
                if (sFile.length() + bytes.length > MAX_FILE_BYTES) {
                    File backup = new File(sFile.getParentFile(), sFile.getName() + ".1");
                    backup.delete();
                    sFile.renameTo(backup);
                }
                FileOutputStream output = new FileOutputStream(sFile, true);
                try {
                    output.write(bytes);
                } finally {
                    output.close();
                }
            } catch (IOException ignored) {
            }
        }
    }

    private static String timestamp() {
        Calendar now = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02dT%02d:%02d:%02d.%03d",
                Integer.valueOf(now.get(Calendar.YEAR)),
                Integer.valueOf(now.get(Calendar.MONTH) + 1),
                Integer.valueOf(now.get(Calendar.DAY_OF_MONTH)),
                Integer.valueOf(now.get(Calendar.HOUR_OF_DAY)),
                Integer.valueOf(now.get(Calendar.MINUTE)),
                Integer.valueOf(now.get(Calendar.SECOND)),
                Integer.valueOf(now.get(Calendar.MILLISECOND)));
    }
}
