package dev.bionicshell;

import java.util.ArrayList;
import java.util.List;

public final class LlamaArgs {
    private LlamaArgs() {
    }

    public static List<String> build(String launcherPath, String modelPath, int port,
                                     int contextSize, int threads, int gpuLayers,
                                     String apiKey, double temperature, boolean reasoning) {
        List<String> command = new ArrayList<String>();
        command.add(launcherPath);
        command.add("llama-server");
        command.add("-m");
        command.add(modelPath);
        command.add("-c");
        command.add(String.valueOf(contextSize));
        command.add("-t");
        command.add(String.valueOf(threads));
        command.add("-ngl");
        command.add(String.valueOf(gpuLayers));
        command.add("--host");
        command.add("127.0.0.1");
        command.add("--port");
        command.add(String.valueOf(port));
        command.add("--api-key");
        command.add(apiKey);
        command.add("--temp");
        command.add(String.valueOf(temperature));
        command.add("--reasoning");
        command.add(reasoning ? "on" : "off");
        return command;
    }
}
