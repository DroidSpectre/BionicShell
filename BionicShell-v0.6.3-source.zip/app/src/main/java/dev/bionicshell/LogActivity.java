package dev.bionicshell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class LogActivity extends Activity {
    public static final String EXTRA_CHANNEL = "channel";

    private TextView mText;
    private ScrollView mScroll;
    private Button[] mTabs;
    private int mChannel;

    protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppLog.init(this);
        mChannel = getIntent().getIntExtra(EXTRA_CHANNEL, AppLog.SYSTEM);
        if (mChannel < 0 || mChannel >= AppLog.CHANNEL_COUNT) {
            mChannel = AppLog.SYSTEM;
        }
        buildUi();
    }

    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(TerminalRenderer.DEFAULT_BG);
        int pad = dp(12);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Logs");
        title.setTextColor(0xffffffff);
        title.setTextSize(20.0f);
        root.addView(title);

        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        mTabs = new Button[AppLog.CHANNEL_COUNT];
        for (int i = 0; i < AppLog.CHANNEL_COUNT; i++) {
            final int channel = i;
            Button tab = new Button(this);
            tab.setText(AppLog.name(i));
            tab.setAllCaps(false);
            tab.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    selectChannel(channel);
                }
            });
            tabs.addView(tab);
            mTabs[i] = tab;
        }
        tabScroll.addView(tabs);
        root.addView(tabScroll);

        HorizontalScrollView actionScroll = new HorizontalScrollView(this);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("Refresh", new View.OnClickListener() {
            public void onClick(View view) {
                refresh();
            }
        }));
        actions.addView(button("Copy", new View.OnClickListener() {
            public void onClick(View view) {
                copyCurrent();
            }
        }));
        actions.addView(button("Clear", new View.OnClickListener() {
            public void onClick(View view) {
                confirmClear();
            }
        }));
        actions.addView(button("Share report", new View.OnClickListener() {
            public void onClick(View view) {
                shareReport();
            }
        }));
        actionScroll.addView(actions);
        root.addView(actionScroll);

        mScroll = new ScrollView(this);
        mText = new TextView(this);
        mText.setTypeface(Typeface.MONOSPACE);
        mText.setTextSize(12.0f);
        mText.setTextColor(0xffd0d0d0);
        mText.setTextIsSelectable(true);
        mText.setPadding(0, dp(8), 0, dp(8));
        mScroll.addView(mText);
        root.addView(mScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));

        setContentView(root);
        WindowInsetsHelper.apply(this, root, false);
        updateTabs();
    }

    private Button button(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        return button;
    }

    private void selectChannel(int channel) {
        mChannel = channel;
        updateTabs();
        refresh();
    }

    private void updateTabs() {
        for (int i = 0; i < mTabs.length; i++) {
            boolean selected = i == mChannel;
            mTabs[i].setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            mTabs[i].setTextColor(selected ? 0xffffffff : 0xffa0a0a0);
        }
    }

    private void refresh() {
        String text = AppLog.read(mChannel);
        mText.setText(text.length() == 0 ? "(no entries)" : text);
        mScroll.post(new Runnable() {
            public void run() {
                mScroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private void copyCurrent() {
        String text = AppLog.read(mChannel);
        if (text.length() == 0) {
            Toast.makeText(this, "No " + AppLog.name(mChannel) + " log entries",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(
                CLIPBOARD_SERVICE);
        if (clipboard == null) {
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText(
                "BionicShell " + AppLog.name(mChannel) + " log", text));
        Toast.makeText(this, AppLog.name(mChannel) + " log copied",
                Toast.LENGTH_SHORT).show();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Clear " + AppLog.name(mChannel) + " log?")
                .setPositiveButton("Clear", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        AppLog.clear(mChannel);
                        refresh();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void shareReport() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "BionicShell diagnostics");
        intent.putExtra(Intent.EXTRA_TEXT, AppLog.report(this));
        startActivity(Intent.createChooser(intent, "Share diagnostics"));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
