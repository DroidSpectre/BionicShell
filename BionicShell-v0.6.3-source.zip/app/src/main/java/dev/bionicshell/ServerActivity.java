package dev.bionicshell;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.text.format.Formatter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.List;

public final class ServerActivity extends Activity {
    private static final int REQUEST_IMPORT = 2001;
    private static final int REQUEST_NOTIFICATIONS = 2002;

    private TextView mStatus;
    private TextView mModel;
    private Button mStartStop;

    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void buildUi() {
        ScrollView root = new ScrollView(this);
        root.setBackgroundColor(TerminalRenderer.DEFAULT_BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        content.setPadding(pad, pad, pad, pad);
        root.addView(content);

        TextView title = new TextView(this);
        title.setText("Server");
        title.setTextColor(0xffffffff);
        title.setTextSize(22.0f);
        content.addView(title);

        mStatus = new TextView(this);
        mStatus.setTextColor(0xffc0c0c0);
        mStatus.setTextSize(13.0f);
        mStatus.setPadding(0, dp(10), 0, dp(10));
        content.addView(mStatus);

        mStartStop = button("Start server");
        mStartStop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startOrStop();
            }
        });
        content.addView(mStartStop);

        section(content, "MODEL");
        mModel = new TextView(this);
        mModel.setTextColor(0xffffffff);
        mModel.setTextSize(14.0f);
        mModel.setPadding(0, 0, 0, dp(8));
        content.addView(mModel);
        Button choose = button("Choose or import model");
        choose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                chooseModel();
            }
        });
        content.addView(choose);

        section(content, "SERVER SETTINGS");
        Button settings = button("Server settings");
        settings.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(ServerActivity.this, SettingsActivity.class));
            }
        });
        content.addView(settings);

        section(content, "SECURITY");
        Button apiKey = button("API key");
        apiKey.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showApiKeyDialog();
            }
        });
        content.addView(apiKey);

        section(content, "DIAGNOSTICS");
        Button logs = button("Server log");
        logs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startActivity(new Intent(ServerActivity.this, LogActivity.class)
                        .putExtra(LogActivity.EXTRA_CHANNEL, AppLog.SERVER));
            }
        });
        content.addView(logs);

        TextView note = new TextView(this);
        note.setText("Model, settings, and API key changes apply after the server is restarted.");
        note.setTextColor(0xff909090);
        note.setTextSize(12.0f);
        note.setPadding(0, dp(16), 0, 0);
        content.addView(note);

        setContentView(root);
        WindowInsetsHelper.apply(this, root, false);
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(14.0f);
        button.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.START);
        int pad = dp(12);
        button.setPadding(pad, 0, pad, 0);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(6);
        button.setLayoutParams(params);
        return button;
    }

    private void section(LinearLayout content, String label) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(0xff909090);
        view.setTextSize(11.0f);
        view.setPadding(0, dp(18), 0, dp(6));
        content.addView(view);
    }

    private void refresh() {
        String path = ServerSettings.getModelPath(this);
        if (path.length() == 0) {
            mModel.setText("No model selected");
        } else {
            File file = new File(path);
            mModel.setText(file.getName() + (file.isFile() ? "" : " (missing)"));
        }

        boolean running = LlamaRuntime.isRunning();
        boolean reasoningOn = ServerSettings.getReasoning(this);
        long context = ServerSettings.getContext(this);
        int threads = ServerSettings.getThreads(this);
        String reasoning = reasoningOn ? "on" : "off";
        if (running) {
            String activePath = LlamaRuntime.getModelPath();
            if (activePath.length() == 0) {
                activePath = path;
            }
            boolean activeReasoning = LlamaRuntime.getReasoning();
            int activeContext = LlamaRuntime.getContextSize();
            int activeThreads = LlamaRuntime.getThreads();
            mStatus.setText("Running at " + LlamaRuntime.getBaseUrl()
                    + "\nRunning model: " + modelName(activePath)
                    + "\nReasoning: " + (activeReasoning ? "on" : "off")
                    + "   Context: " + activeContext
                    + "   Threads: " + activeThreads);
            if (!activePath.equals(path) || activeReasoning != reasoningOn
                    || activeContext != context || activeThreads != threads) {
                mStatus.append("\nSaved changes are waiting; restart to apply.");
            }
        } else {
            mStatus.setText("Stopped\nReasoning: " + reasoning
                    + "   Context: " + context
                    + "   Threads: " + threads);
        }
        mStartStop.setText(running ? "Stop server" : "Start server");
    }

    private String modelName(String path) {
        if (path.length() == 0) {
            return "none";
        }
        return new File(path).getName();
    }

    private void startOrStop() {
        if (LlamaRuntime.isRunning()) {
            stopServer();
            return;
        }
        String path = ServerSettings.getModelPath(this);
        if (path.length() == 0) {
            chooseModel();
            return;
        }
        File model = new File(path);
        if (!model.isFile()) {
            Toast.makeText(this, "Model file is missing", Toast.LENGTH_LONG).show();
            chooseModel();
            return;
        }

        LlamaController.Config config = new LlamaController.Config(
                model, 8080,
                (int) ServerSettings.getContext(this),
                ServerSettings.getThreads(this),
                0,
                ServerSettings.getApiKey(this),
                ServerSettings.getTemperature(this),
                ServerSettings.getReasoning(this));
        requestNotificationPermission();
        try {
            if (!LlamaRuntime.start(this, config)) {
                AppLog.appendLine(AppLog.SERVER, "exited immediately");
                Toast.makeText(this, "Server exited; check Logs", Toast.LENGTH_LONG).show();
                refresh();
                return;
            }
            Intent service = new Intent(this, LlamaService.class);
            service.setAction(LlamaService.ACTION_START);
            startForegroundService(service);
        } catch (IOException exception) {
            AppLog.appendLine(AppLog.SERVER, "start failed: " + exception.getMessage());
            Toast.makeText(this, "Server failed: " + exception.getMessage(), Toast.LENGTH_LONG).show();
            refresh();
            return;
        } catch (RuntimeException exception) {
            LlamaRuntime.stop();
            AppLog.appendLine(AppLog.SERVER, "service failed: " + exception.getMessage());
            Toast.makeText(this, "Server service failed: " + exception.getMessage(),
                    Toast.LENGTH_LONG).show();
            refresh();
            return;
        }
        refresh();
        Toast.makeText(this, "Server started", Toast.LENGTH_SHORT).show();
    }

    private void stopServer() {
        LlamaRuntime.stop();
        stopService(new Intent(this, LlamaService.class));
        refresh();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS },
                    REQUEST_NOTIFICATIONS);
        }
    }

    private void chooseModel() {
        final List<ModelRepository.ModelInfo> models = ModelRepository.list(this);
        if (models.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Models")
                    .setMessage("No .gguf models found in "
                            + ModelRepository.modelsDir(this).getAbsolutePath())
                    .setPositiveButton("Import", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            startImport();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        String[] names = new String[models.size()];
        for (int i = 0; i < models.size(); i++) {
            ModelRepository.ModelInfo info = models.get(i);
            names[i] = info.getName() + " (" + Formatter.formatFileSize(this, info.getSize()) + ")";
        }
        new AlertDialog.Builder(this)
                .setTitle("Select model")
                .setItems(names, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        selectModel(models.get(which).getFile());
                    }
                })
                .setNeutralButton("Import", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        startImport();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void selectModel(File file) {
        ServerSettings.setModelPath(this, file.getAbsolutePath());
        refresh();
        Toast.makeText(this,
                LlamaRuntime.isRunning()
                        ? "Selected " + file.getName() + "; restart the server to use it"
                        : "Selected " + file.getName(),
                Toast.LENGTH_LONG).show();
    }

    private void startImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_IMPORT);
    }

    private void importModel(final Uri uri) {
        final String name = displayName(uri);
        Toast.makeText(this, "Importing " + name, Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            public void run() {
                try {
                    final ModelRepository.ModelInfo info =
                            ModelRepository.importFromUri(ServerActivity.this, uri, name);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            selectModel(info.getFile());
                        }
                    });
                } catch (final Exception exception) {
                    AppLog.appendLine("model import failed: " + exception.getMessage());
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(ServerActivity.this,
                                    "Import failed: " + exception.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }, "bionicshell-model-import").start();
    }

    private String displayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri,
                    new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.length() > 0) {
                        return name;
                    }
                }
            }
        } catch (RuntimeException ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        String fallback = uri.getLastPathSegment();
        return fallback == null ? "model.gguf" : fallback;
    }

    private void showApiKeyDialog() {
        final String key = ServerSettings.getApiKey(this);
        new AlertDialog.Builder(this)
                .setTitle("Server API key")
                .setMessage(key)
                .setPositiveButton("Copy", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        copyText("BionicShell API key", key);
                    }
                })
                .setNeutralButton("Change", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        showApiKeyEditor();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showApiKeyEditor() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        input.setText(ServerSettings.getApiKey(this));
        input.setSelection(input.getText().length());
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Set API key")
                .setMessage("Use 8-200 printable characters without spaces. "
                        + "Restart the server after changing the key.")
                .setView(input)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View view) {
                        String value = input.getText().toString().trim();
                        if (!ServerSettings.isValidApiKey(value)) {
                            Toast.makeText(ServerActivity.this,
                                    "Key must be 8-200 printable characters without spaces",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        ServerSettings.setApiKey(ServerActivity.this, value);
                        AppLog.appendLine(AppLog.SERVER, "API key changed");
                        dialog.dismiss();
                        Toast.makeText(ServerActivity.this,
                                LlamaRuntime.isRunning()
                                        ? "Key saved; restart the server to use it"
                                        : "API key saved",
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void copyText(String label, String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(
                CLIPBOARD_SERVICE);
        if (clipboard == null) {
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text));
        Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                importModel(uri);
            }
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
