package dev.bionicshell;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;

public final class LlamaService extends Service {
    public static final String ACTION_START = "dev.bionicshell.action.START_SERVER";
    public static final String ACTION_STOP = "dev.bionicshell.action.STOP_SERVER";

    private static final String CHANNEL_ID = "llama_server";
    private static final int NOTIFICATION_ID = 1;
    private static final long MONITOR_INTERVAL_MS = 5000L;

    private final Handler mHandler = new Handler();
    private final Runnable mMonitor = new Runnable() {
        public void run() {
            if (!LlamaRuntime.isRunning()) {
                AppLog.appendLine(AppLog.SERVER, "service: server process ended");
                stopForeground(true);
                stopSelf();
                return;
            }
            mHandler.postDelayed(this, MONITOR_INTERVAL_MS);
        }
    };

    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        AppLog.appendLine(AppLog.SERVER, "service: foreground service started");
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopServer();
            return START_NOT_STICKY;
        }
        if (!LlamaRuntime.isRunning()) {
            AppLog.appendLine(AppLog.SERVER, "service: no server running");
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        mHandler.removeCallbacks(mMonitor);
        mHandler.postDelayed(mMonitor, MONITOR_INTERVAL_MS);
        return START_NOT_STICKY;
    }

    public void onDestroy() {
        mHandler.removeCallbacks(mMonitor);
        AppLog.appendLine(AppLog.SERVER, "service: foreground service stopped");
        super.onDestroy();
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    private void stopServer() {
        LlamaRuntime.stop();
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(
                NOTIFICATION_SERVICE);
        if (manager == null) {
            return;
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "llama-server", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Keeps the local llama.cpp server running");
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openIntent = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, LlamaService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String address = LlamaRuntime.getBaseUrl();
        if (address.length() == 0) {
            address = "starting";
        }
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("llama-server running")
                .setContentText(address)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopIntent);
        return builder.build();
    }
}
