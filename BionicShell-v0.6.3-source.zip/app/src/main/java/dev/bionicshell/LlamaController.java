package dev.bionicshell;

import android.content.Context;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.SecureRandom;
import java.util.List;
import java.util.Map;

public final class LlamaController {
    public static final class Config {
        public final File model;
        public final int port;
        public final int contextSize;
        public final int threads;
        public final int gpuLayers;
        public final String apiKey;
        public final double temperature;
        public final boolean reasoning;

        public Config(File model, int port, int contextSize, int threads, int gpuLayers,
                      String apiKey, double temperature, boolean reasoning) {
            this.model = model;
            this.port = port;
            this.contextSize = contextSize;
            this.threads = threads;
            this.gpuLayers = gpuLayers;
            this.apiKey = apiKey;
            this.temperature = temperature;
            this.reasoning = reasoning;
        }
    }

    private volatile Process mProcess;
    private volatile Thread mLogThread;
    private volatile String mBaseUrl = "";
    private volatile String mApiKey = "";
    private volatile String mModelPath = "";
    private volatile int mContextSize;
    private volatile int mThreads;
    private volatile boolean mReasoning;

    public void start(Context context, Config config) throws IOException {
        if (isRunning()) {
            return;
        }
        if (config == null || config.model == null || !config.model.isFile()) {
            throw new IOException("model file is missing");
        }
        if (config.port < 1 || config.port > 65535) {
            throw new IOException("invalid server port");
        }
        String nativeDir = context.getApplicationInfo().nativeLibraryDir;
        File launcher = new File(nativeDir, "liblauncher.so");
        if (!launcher.isFile()) {
            throw new IOException("native launcher is missing");
        }
        mApiKey = ServerSettings.isValidApiKey(config.apiKey)
                ? config.apiKey : newApiKey();
        List<String> command = LlamaArgs.build(
                launcher.getAbsolutePath(), config.model.getAbsolutePath(), config.port,
                config.contextSize, config.threads, config.gpuLayers, mApiKey,
                config.temperature, config.reasoning);

        ProcessBuilder builder = new ProcessBuilder(command);
        builder.directory(RuntimePaths.home(context));
        builder.redirectErrorStream(true);
        Map<String, String> environment = builder.environment();
        environment.put("HOME", RuntimePaths.home(context).getAbsolutePath());
        environment.put("TMPDIR", RuntimePaths.tmp(context).getAbsolutePath());
        environment.put("LD_LIBRARY_PATH", nativeDir);
        environment.put("PATH", "/system/bin");

        Process process;
        try {
            process = builder.start();
        } catch (IOException exception) {
            mApiKey = "";
            throw exception;
        }
        mProcess = process;
        mBaseUrl = "http://localhost:" + config.port;
        mModelPath = config.model.getAbsolutePath();
        mContextSize = config.contextSize;
        mThreads = config.threads;
        mReasoning = config.reasoning;
        AppLog.appendLine(AppLog.SERVER, "started on " + mBaseUrl);
        mLogThread = new Thread(new ServerLogReader(process, mApiKey), "bionicshell-server-log");
        mLogThread.start();
    }

    public void stop() {
        Process process = mProcess;
        mProcess = null;
        mBaseUrl = "";
        mApiKey = "";
        mModelPath = "";
        if (process == null) {
            return;
        }
        process.destroy();
        try {
            Thread.sleep(200);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
        if (process.isAlive()) {
            process.destroyForcibly();
        }
        AppLog.appendLine(AppLog.SERVER, "stopped");
    }

    public boolean isRunning() {
        Process process = mProcess;
        return process != null && process.isAlive();
    }

    public String getBaseUrl() {
        return mBaseUrl;
    }

    public String getApiKey() {
        return mApiKey;
    }

    public String getModelPath() {
        return mModelPath;
    }

    public int getContextSize() {
        return mContextSize;
    }

    public int getThreads() {
        return mThreads;
    }

    public boolean getReasoning() {
        return mReasoning;
    }

    private static final class ServerLogReader implements Runnable {
        private final Process mServer;
        private final String mApiKey;

        ServerLogReader(Process server, String apiKey) {
            mServer = server;
            mApiKey = apiKey;
        }

        public void run() {
            readServerLog(mServer, mApiKey);
        }
    }

    private static void readServerLog(Process process, String apiKey) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                AppLog.appendLine(AppLog.SERVER, AppLog.redact(line, apiKey));
            }
        } catch (IOException exception) {
            AppLog.appendLine(AppLog.SERVER, "log read error: " + exception.getMessage());
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ignored) {
                }
            }
            AppLog.appendLine(AppLog.SERVER, "output ended");
        }
    }

    private static String newApiKey() {
        byte[] bytes = new byte[24];
        new SecureRandom().nextBytes(bytes);
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }
}
