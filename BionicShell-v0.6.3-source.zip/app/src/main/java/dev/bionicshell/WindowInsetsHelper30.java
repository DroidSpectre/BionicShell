package dev.bionicshell;

import android.app.Activity;
import android.graphics.Insets;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;

final class WindowInsetsHelper30 {
    private WindowInsetsHelper30() {
    }

    static void apply(Activity activity, View view, final boolean includeIme) {
        Window window = activity.getWindow();
        window.setDecorFitsSystemWindows(false);

        final int baseLeft = view.getPaddingLeft();
        final int baseTop = view.getPaddingTop();
        final int baseRight = view.getPaddingRight();
        final int baseBottom = view.getPaddingBottom();

        view.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            public WindowInsets onApplyWindowInsets(View target, WindowInsets insets) {
                Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                int bottom = bars.bottom;
                if (includeIme) {
                    int ime = insets.getInsets(WindowInsets.Type.ime()).bottom;
                    if (ime > bottom) {
                        bottom = ime;
                    }
                }
                target.setPadding(baseLeft + bars.left, baseTop + bars.top,
                        baseRight + bars.right, baseBottom + bottom);
                return insets;
            }
        });
        view.requestApplyInsets();
    }
}
