package dev.bionicshell;

import android.app.Activity;
import android.os.Build;
import android.view.View;

/**
 * Keeps app content out from under the status/navigation bars on Android 15+
 * (targetSdk 35+ enforces edge-to-edge). API 30+ is handled explicitly; older
 * releases keep the platform's default fitSystemWindows behavior.
 */
public final class WindowInsetsHelper {
    private WindowInsetsHelper() {
    }

    public static void apply(Activity activity, View view, boolean includeIme) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsHelper30.apply(activity, view, includeIme);
        }
    }
}
