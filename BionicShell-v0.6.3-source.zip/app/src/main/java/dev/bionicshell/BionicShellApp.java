package dev.bionicshell;

import android.app.Application;

public final class BionicShellApp extends Application {
    public void onCreate() {
        super.onCreate();
        AppLog.init(this);
        AppLog.appendLine("app start");
        CrashLog.install(this);
    }
}
