package dev.bionicshell;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.SecureRandom;

public final class ServerSettings {
    private static final String PREFS = "server_settings";
    private static final String KEY_API_KEY = "api_key";
    private static final int KEY_BYTES = 24;
    private static final int MIN_KEY_LENGTH = 8;

    private static final String KEY_MODEL_PATH = "model_path";

    private static final String KEY_CONTEXT = "context";
    private static final long DEFAULT_CONTEXT = 4096;
    private static final long MIN_CONTEXT = 64;
    private static final long MAX_CONTEXT = 131072;
    static final long STEP_CONTEXT = 64;

    private static final String KEY_THREADS = "threads";
    private static final int DEFAULT_THREADS = 4;
    private static final int MIN_THREADS = 1;
    private static final int MAX_THREADS = 64;

    private static final String KEY_TEMP = "temperature";
    private static final double DEFAULT_TEMP = 0.7;
    private static final double MIN_TEMP = 0.0;
    private static final double MAX_TEMP = 2.0;
    static final double STEP_TEMP = 0.1;

    private static final String KEY_REASONING = "reasoning";
    private static final boolean DEFAULT_REASONING = true;

    private ServerSettings() {
    }

    public static String getApiKey(Context context) {
        synchronized (ServerSettings.class) {
            SharedPreferences preferences = context.getSharedPreferences(
                    PREFS, Context.MODE_PRIVATE);
            String key = preferences.getString(KEY_API_KEY, "");
            if (!isValidApiKey(key)) {
                key = newApiKey();
                preferences.edit().putString(KEY_API_KEY, key).commit();
            }
            return key;
        }
    }

    public static void setApiKey(Context context, String key) {
        String value = key == null ? "" : key.trim();
        if (!isValidApiKey(value)) {
            throw new IllegalArgumentException(
                    "API key must be 8-200 printable characters without spaces");
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_API_KEY, value).commit();
    }

    public static String getModelPath(Context context) {
        synchronized (ServerSettings.class) {
            String path = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_MODEL_PATH, "");
            return path == null ? "" : path.trim();
        }
    }

    public static void setModelPath(Context context, String path) {
        String value = path == null ? "" : path.trim();
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_MODEL_PATH, value).commit();
    }

    public static long getContext(Context context) {
        synchronized (ServerSettings.class) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            long value = prefs.getLong(KEY_CONTEXT, DEFAULT_CONTEXT);
            if (value < MIN_CONTEXT) value = MIN_CONTEXT;
            if (value > MAX_CONTEXT) value = MAX_CONTEXT;
            return value;
        }
    }

    public static void setContext(Context context, long value) {
        if (value < MIN_CONTEXT) value = MIN_CONTEXT;
        if (value > MAX_CONTEXT) value = MAX_CONTEXT;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_CONTEXT, value).commit();
    }

    public static int getThreads(Context context) {
        synchronized (ServerSettings.class) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            int value = prefs.getInt(KEY_THREADS, DEFAULT_THREADS);
            if (value < MIN_THREADS) value = MIN_THREADS;
            if (value > MAX_THREADS) value = MAX_THREADS;
            return value;
        }
    }

    public static void setThreads(Context context, int value) {
        if (value < MIN_THREADS) value = MIN_THREADS;
        if (value > MAX_THREADS) value = MAX_THREADS;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putInt(KEY_THREADS, value).commit();
    }

    public static double getTemperature(Context context) {
        synchronized (ServerSettings.class) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            // store as long bits to avoid float precision issues
            long bits = prefs.getLong(KEY_TEMP, Double.doubleToLongBits(DEFAULT_TEMP));
            double value = Double.longBitsToDouble(bits);
            if (value < MIN_TEMP) value = MIN_TEMP;
            if (value > MAX_TEMP) value = MAX_TEMP;
            return value;
        }
    }

    public static void setTemperature(Context context, double value) {
        if (value < MIN_TEMP) value = MIN_TEMP;
        if (value > MAX_TEMP) value = MAX_TEMP;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_TEMP, Double.doubleToLongBits(value)).commit();
    }

    public static boolean getReasoning(Context context) {
        synchronized (ServerSettings.class) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            return prefs.getBoolean(KEY_REASONING, DEFAULT_REASONING);
        }
    }

    public static void setReasoning(Context context, boolean value) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_REASONING, value).commit();
    }

    public static boolean isValidApiKey(String key) {
        if (key == null || key.length() < MIN_KEY_LENGTH || key.length() > 200) {
            return false;
        }
        for (int i = 0; i < key.length(); i++) {
            char value = key.charAt(i);
            if (value < 33 || value > 126) {
                return false;
            }
        }
        return true;
    }

    public static String newApiKey() {
        byte[] bytes = new byte[KEY_BYTES];
        new SecureRandom().nextBytes(bytes);
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }
}
