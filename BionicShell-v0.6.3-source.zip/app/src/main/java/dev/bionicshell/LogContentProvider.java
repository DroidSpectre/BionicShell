package dev.bionicshell;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

public final class LogContentProvider extends ContentProvider {
    public static final String AUTHORITY = "dev.bionicshell.app.logs";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/log");

    public boolean onCreate() {
        AppLog.init(getContext());
        return true;
    }

    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        MatrixCursor cursor = new MatrixCursor(new String[] { "_id", "text" });
        cursor.addRow(new Object[] { Integer.valueOf(1), AppLog.readAll() });
        return cursor;
    }

    public String getType(Uri uri) {
        return "vnd.android.cursor.item/vnd.bionicshell.log";
    }

    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
