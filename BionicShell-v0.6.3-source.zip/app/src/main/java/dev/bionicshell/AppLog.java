package dev.bionicshell;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Locale;

public final class AppLog {
    public static final int SYSTEM = 0;
    public static final int TERMINAL = 1;
    public static final int SERVER = 2;
    public static final int CHANNEL_COUNT = 3;
    public static final int MAX_CHARS = 200000;

    private static final int MAX_FILE_BYTES = 256 * 1024;
    private static final String[] FILE_NAMES = {
            "system.log", "terminal.log", "server.log"
    };
    private static final String[] NAMES = {
            "System", "Terminal", "Server"
    };
    private static final String LEGACY_FILE_NAME = "bionicshell.log";
    private static final StringBuilder[] BUFFERS = new StringBuilder[CHANNEL_COUNT];
    private static final Object[] LOCKS = new Object[CHANNEL_COUNT];
    private static final File[] FILES = new File[CHANNEL_COUNT];
    private static boolean sInitialized;

    static {
        for (int i = 0; i < CHANNEL_COUNT; i++) {
            BUFFERS[i] = new StringBuilder();
            LOCKS[i] = new Object();
        }
    }

    private AppLog() {
    }

    public static void init(Context context) {
        if (context == null) {
            return;
        }
        synchronized (AppLog.class) {
            if (sInitialized) {
                return;
            }
            File directory = RuntimePaths.logs(context);
            if (!directory.isDirectory() && !directory.mkdirs()) {
                return;
            }
            File systemFile = new File(directory, FILE_NAMES[SYSTEM]);
            if (!systemFile.isFile()) {
                File legacy = new File(directory, LEGACY_FILE_NAME);
                loadTail(SYSTEM, backup(legacy));
                loadTail(SYSTEM, legacy);
            }
            for (int i = 0; i < CHANNEL_COUNT; i++) {
                File file = new File(directory, FILE_NAMES[i]);
                FILES[i] = file;
                loadTail(i, backup(file));
                loadTail(i, file);
            }
            sInitialized = true;
        }
    }

    public static String name(int channel) {
        return NAMES[safeChannel(channel)];
    }

    public static void append(String text) {
        append(SYSTEM, text);
    }

    public static void append(int channel, String text) {
        if (text == null || text.length() == 0) {
            return;
        }
        int index = safeChannel(channel);
        synchronized (LOCKS[index]) {
            BUFFERS[index].append(text);
            trimBuffer(index);
            writeToFile(index, text);
        }
    }

    public static void appendLine(String text) {
        appendLine(SYSTEM, text);
    }

    public static void appendLine(int channel, String text) {
        append(channel, "[" + timestamp() + "] " + (text == null ? "" : text) + "\n");
    }

    public static String read() {
        return read(SYSTEM);
    }

    public static String read(int channel) {
        int index = safeChannel(channel);
        synchronized (LOCKS[index]) {
            return BUFFERS[index].toString();
        }
    }

    public static String readAll() {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < CHANNEL_COUNT; i++) {
            text.append("=== ").append(NAMES[i]).append(" ===\n");
            text.append(read(i));
            if (text.length() > 0 && text.charAt(text.length() - 1) != '\n') {
                text.append('\n');
            }
        }
        return text.toString();
    }

    public static void clear() {
        clear(SYSTEM);
    }

    public static void clear(int channel) {
        int index = safeChannel(channel);
        synchronized (LOCKS[index]) {
            BUFFERS[index].setLength(0);
            File file = FILES[index];
            if (file != null) {
                file.delete();
                backup(file).delete();
                if (index == SYSTEM) {
                    File legacy = new File(file.getParentFile(), LEGACY_FILE_NAME);
                    legacy.delete();
                    backup(legacy).delete();
                }
            }
        }
    }

    public static void clearAll() {
        for (int i = 0; i < CHANNEL_COUNT; i++) {
            clear(i);
        }
    }

    public static String redact(String text, String secret) {
        String value = text == null ? "" : text;
        if (secret == null || secret.length() < 4) {
            return value;
        }
        return value.replace(secret, "[redacted]");
    }

    public static String report(Context context) {
        StringBuilder text = new StringBuilder();
        text.append("BionicShell diagnostics\n");
        text.append("time=").append(timestamp()).append('\n');
        String version = "unknown";
        long code = 0;
        if (context != null) {
            try {
                PackageInfo info = context.getPackageManager().getPackageInfo(
                        context.getPackageName(), 0);
                version = info.versionName;
                code = info.versionCode;
            } catch (Exception ignored) {
            }
        }
        text.append("version=").append(version).append(" (").append(code).append(")\n");
        text.append("device=").append(Build.MANUFACTURER).append(' ')
                .append(Build.MODEL).append('\n');
        text.append("android=").append(Build.VERSION.RELEASE)
                .append(" sdk=").append(Build.VERSION.SDK_INT).append('\n');
        String abi = Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown";
        text.append("abi=").append(abi).append('\n');
        boolean running = LlamaRuntime.isRunning();
        text.append("server=").append(running ? "running" : "stopped").append('\n');
        if (running) {
            text.append("server_url=").append(LlamaRuntime.getBaseUrl()).append('\n');
            text.append("model=").append(LlamaRuntime.getModelPath()).append('\n');
            text.append("reasoning=").append(LlamaRuntime.getReasoning() ? "on" : "off")
                    .append(" context=").append(LlamaRuntime.getContextSize())
                    .append(" threads=").append(LlamaRuntime.getThreads()).append('\n');
        } else if (context != null) {
            text.append("model=").append(ServerSettings.getModelPath(context)).append('\n');
            text.append("reasoning=").append(ServerSettings.getReasoning(context) ? "on" : "off")
                    .append(" context=").append(ServerSettings.getContext(context))
                    .append(" threads=").append(ServerSettings.getThreads(context)).append('\n');
        }
        for (int i = 0; i < CHANNEL_COUNT; i++) {
            text.append("\n=== ").append(NAMES[i]).append(" ===\n");
            text.append(read(i));
            if (text.length() > 0 && text.charAt(text.length() - 1) != '\n') {
                text.append('\n');
            }
        }
        return text.toString();
    }

    private static int safeChannel(int channel) {
        return channel < 0 || channel >= CHANNEL_COUNT ? SYSTEM : channel;
    }

    private static File backup(File file) {
        return new File(file.getParentFile(), file.getName() + ".1");
    }

    private static String timestamp() {
        Calendar now = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d %02d:%02d:%02d.%03d",
                Integer.valueOf(now.get(Calendar.YEAR)),
                Integer.valueOf(now.get(Calendar.MONTH) + 1),
                Integer.valueOf(now.get(Calendar.DAY_OF_MONTH)),
                Integer.valueOf(now.get(Calendar.HOUR_OF_DAY)),
                Integer.valueOf(now.get(Calendar.MINUTE)),
                Integer.valueOf(now.get(Calendar.SECOND)),
                Integer.valueOf(now.get(Calendar.MILLISECOND)));
    }

    private static void trimBuffer(int channel) {
        StringBuilder buffer = BUFFERS[channel];
        if (buffer.length() > MAX_CHARS) {
            buffer.delete(0, buffer.length() - MAX_CHARS);
        }
    }

    private static void loadTail(int channel, File file) {
        if (file == null || !file.isFile()) {
            return;
        }
        try {
            String text = readFile(file);
            if (text.length() > MAX_CHARS) {
                text = text.substring(text.length() - MAX_CHARS);
            }
            BUFFERS[channel].append(text);
            trimBuffer(channel);
        } catch (IOException ignored) {
        }
    }

    private static String readFile(File file) throws IOException {
        FileInputStream input = new FileInputStream(file);
        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            return new String(output.toByteArray(), "UTF-8");
        } finally {
            input.close();
        }
    }

    private static void writeToFile(int channel, String text) {
        File file = FILES[channel];
        if (file == null) {
            return;
        }
        try {
            byte[] bytes = text.getBytes("UTF-8");
            if (file.length() + bytes.length > MAX_FILE_BYTES) {
                rotateFile(channel);
            }
            FileOutputStream output = new FileOutputStream(file, true);
            try {
                output.write(bytes);
            } finally {
                output.close();
            }
        } catch (IOException ignored) {
        }
    }

    private static void rotateFile(int channel) {
        File file = FILES[channel];
        File backup = backup(file);
        backup.delete();
        file.renameTo(backup);
    }
}
