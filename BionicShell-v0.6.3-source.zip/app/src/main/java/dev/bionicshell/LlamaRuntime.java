package dev.bionicshell;

import android.content.Context;

import java.io.IOException;

public final class LlamaRuntime {
    private static final Object LOCK = new Object();
    private static LlamaController sController;

    private LlamaRuntime() {
    }

    public static boolean start(Context context, LlamaController.Config config)
            throws IOException {
        synchronized (LOCK) {
            if (sController != null && sController.isRunning()) {
                return true;
            }
            if (sController == null) {
                sController = new LlamaController();
            }
            sController.start(context, config);
            return sController.isRunning();
        }
    }

    public static void stop() {
        synchronized (LOCK) {
            if (sController != null) {
                sController.stop();
            }
        }
    }

    public static boolean isRunning() {
        synchronized (LOCK) {
            return sController != null && sController.isRunning();
        }
    }

    public static String getBaseUrl() {
        synchronized (LOCK) {
            return sController == null ? "" : sController.getBaseUrl();
        }
    }

    public static String getApiKey() {
        synchronized (LOCK) {
            return sController == null ? "" : sController.getApiKey();
        }
    }

    public static String getModelPath() {
        synchronized (LOCK) {
            return sController == null ? "" : sController.getModelPath();
        }
    }

    public static int getContextSize() {
        synchronized (LOCK) {
            return sController == null ? 0 : sController.getContextSize();
        }
    }

    public static int getThreads() {
        synchronized (LOCK) {
            return sController == null ? 0 : sController.getThreads();
        }
    }

    public static boolean getReasoning() {
        synchronized (LOCK) {
            return sController != null && sController.getReasoning();
        }
    }
}
