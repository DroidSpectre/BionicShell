package dev.bionicshell;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

public final class TerminalView extends View {
    private static final int MENU_COPY = 1;
    private static final int MENU_COPY_ALL = 2;
    private static final int MENU_PASTE = 3;

    private TerminalSession mSession;
    private ScreenBuffer mBuffer;
    private final TerminalRenderer mRenderer;
    private final TerminalSelection mSelection = new TerminalSelection();
    private final Runnable mResizeRunnable = new Runnable() {
        public void run() {
            resizeToView();
        }
    };
    private final Runnable mRedrawRunnable = new Runnable() {
        public void run() {
            postInvalidateOnAnimation();
        }
    };
    private final Runnable mLongPressRunnable = new Runnable() {
        public void run() {
            beginSelection();
        }
    };
    private InputMethodManager mInputMethodManager;
    private int mScrollOffset;
    private float mScrollRemainder;
    private float mDownX;
    private float mDownY;
    private float mLastY;
    private int mTouchSlop;
    private boolean mSelecting;

    public TerminalView(Context context) {
        this(context, null);
    }

    public TerminalView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mRenderer = new TerminalRenderer(context);
        mInputMethodManager = (InputMethodManager) context.getSystemService(
                Context.INPUT_METHOD_SERVICE);
        mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setBackgroundColor(TerminalRenderer.DEFAULT_BG);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setWillNotDraw(false);
    }

    public void setSession(TerminalSession session) {
        mSession = session;
        mBuffer = session == null ? null : session.getBuffer();
        mScrollOffset = 0;
        mScrollRemainder = 0;
        mSelection.clear();
        refreshAfterLayout();
    }

    public void refreshAfterLayout() {
        removeCallbacks(mResizeRunnable);
        removeCallbacks(mRedrawRunnable);
        post(mResizeRunnable);
        postInvalidateOnAnimation();
        postDelayed(mRedrawRunnable, 350);
        postDelayed(mRedrawRunnable, 800);
    }

    public TerminalSession getSession() {
        return mSession;
    }

    public void scrollToBottom() {
        mScrollOffset = 0;
        mScrollRemainder = 0;
        invalidate();
    }

    public boolean hasSelection() {
        return !mSelection.isEmpty();
    }

    public void copySelection() {
        if (mSession == null || mSelection.isEmpty()) {
            return;
        }
        String text;
        synchronized (mSession.getBufferLock()) {
            text = mBuffer.getSelectedText(
                    mSelection.getStartLine(), mSelection.getStartCol(),
                    mSelection.getEndLine(), mSelection.getEndCol());
        }
        copyToClipboard(text);
    }

    public void copyAll() {
        if (mSession == null) {
            return;
        }
        String text;
        synchronized (mSession.getBufferLock()) {
            text = mBuffer.copyAll();
        }
        copyToClipboard(text);
    }

    public void pasteClipboard() {
        if (mSession == null) {
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(
                Context.CLIPBOARD_SERVICE);
        if (clipboard == null || !clipboard.hasPrimaryClip()) {
            return;
        }
        ClipData clip = clipboard.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(getContext());
        boolean bracketed;
        synchronized (mSession.getBufferLock()) {
            bracketed = mBuffer.isBracketedPaste();
        }
        String value = text.toString();
        AppLog.appendLine(AppLog.TERMINAL, "paste chars=" + value.length());
        mSession.write(KeyHandler.paste(value, bracketed));
    }

    public void sendKey(int keyCode, int metaState) {
        if (mSession == null) {
            return;
        }
        boolean applicationCursor;
        synchronized (mSession.getBufferLock()) {
            applicationCursor = mBuffer.isApplicationCursorKeys();
        }
        mSession.write(KeyHandler.encodeKey(keyCode, metaState, applicationCursor));
    }

    public void sendText(String text) {
        if (mSession != null) {
            mSession.write(KeyHandler.encodeText(text));
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mSession == null) {
            return;
        }
        synchronized (mSession.getBufferLock()) {
            int topLine = Math.max(0, mBuffer.getVisibleStart() - mScrollOffset);
            mRenderer.render(canvas, mBuffer, topLine, mSelection, isFocused());
        }
    }

    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        refreshAfterLayout();
    }

    protected void onDetachedFromWindow() {
        removeCallbacks(mResizeRunnable);
        removeCallbacks(mRedrawRunnable);
        removeCallbacks(mLongPressRunnable);
        super.onDetachedFromWindow();
    }

    protected void onFocusChanged(boolean focused, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(focused, direction, previouslyFocusedRect);
        invalidate();
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (mSession == null) {
            return true;
        }
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            mDownX = event.getX();
            mDownY = event.getY();
            mLastY = mDownY;
            mScrollRemainder = 0;
            mSelecting = false;
            mSelection.clear();
            removeCallbacks(mLongPressRunnable);
            postDelayed(mLongPressRunnable, ViewConfiguration.getLongPressTimeout());
            invalidate();
            return true;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            float y = event.getY();
            if (mSelecting) {
                updateSelection(event.getX(), y);
                return true;
            }
            if (Math.abs(y - mDownY) > mTouchSlop) {
                removeCallbacks(mLongPressRunnable);
                float lines = (mLastY - y) / mRenderer.getLineHeight();
                mScrollRemainder += lines;
                int amount = (int) mScrollRemainder;
                mScrollRemainder -= amount;
                if (amount != 0) {
                    int max;
                    synchronized (mSession.getBufferLock()) {
                        max = mBuffer.getScrollbackCount();
                    }
                    mScrollOffset = Math.max(0, Math.min(max, mScrollOffset - amount));
                    invalidate();
                }
            }
            mLastY = y;
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            removeCallbacks(mLongPressRunnable);
            if (!mSelecting && Math.abs(event.getY() - mDownY) <= mTouchSlop) {
                performClick();
            }
            return true;
        }
        return true;
    }

    public boolean performClick() {
        super.performClick();
        requestFocus();
        if (mInputMethodManager != null) {
            mInputMethodManager.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT);
        }
        return true;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK
                || keyCode == KeyEvent.KEYCODE_VOLUME_UP
                || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            return super.onKeyDown(keyCode, event);
        }
        if (mSession != null) {
            sendKey(keyCode, event.getMetaState());
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public boolean onCheckIsTextEditor() {
        return true;
    }

    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
                | EditorInfo.IME_FLAG_NO_FULLSCREEN;
        return new BaseInputConnection(this, false) {
            public boolean commitText(CharSequence text, int newCursorPosition) {
                if (mSession != null) {
                    mSession.write(KeyHandler.encodeText(text.toString()));
                }
                return true;
            }

            public boolean deleteSurroundingText(int beforeLength, int afterLength) {
                if (mSession != null) {
                    for (int i = 0; i < beforeLength; i++) {
                        mSession.write(new byte[] { 0x7f });
                    }
                    for (int i = 0; i < afterLength; i++) {
                        mSession.write(new byte[] { 0x1b, '[', '3', '~' });
                    }
                }
                return true;
            }

            public boolean sendKeyEvent(KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    TerminalView.this.sendKey(event.getKeyCode(), event.getMetaState());
                }
                return true;
            }
        };
    }

    public void onCreateContextMenu(android.view.ContextMenu menu) {
        menu.add(Menu.NONE, MENU_COPY, Menu.NONE, "Copy terminal output");
        menu.add(Menu.NONE, MENU_COPY_ALL, Menu.NONE, "Copy all terminal output");
        menu.add(Menu.NONE, MENU_PASTE, Menu.NONE, "Paste into terminal");
    }

    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == MENU_COPY) {
            copySelection();
            return true;
        }
        if (item.getItemId() == MENU_COPY_ALL) {
            copyAll();
            return true;
        }
        if (item.getItemId() == MENU_PASTE) {
            pasteClipboard();
            return true;
        }
        return false;
    }

    private void resizeToView() {
        if (mSession == null || getWidth() <= 0 || getHeight() <= 0) {
            return;
        }
        int rows = Math.max(4, (int) (getHeight() / mRenderer.getLineHeight()));
        int cols = Math.max(20, (int) (getWidth() / mRenderer.getCharWidth()));
        synchronized (mSession.getBufferLock()) {
            if (rows == mBuffer.getRows() && cols == mBuffer.getColumns()) {
                invalidate();
                return;
            }
        }
        mSession.resize(rows, cols);
        mScrollOffset = 0;
        mScrollRemainder = 0;
        invalidate();
    }

    private void beginSelection() {
        if (mSession == null) {
            return;
        }
        int[] cell = cellAt(mDownX, mDownY);
        if (cell == null) {
            return;
        }
        mSelecting = true;
        mSelection.set(cell[0], cell[1], cell[0], cell[1]);
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        invalidate();
    }

    private void updateSelection(float x, float y) {
        int[] cell = cellAt(x, y);
        if (cell == null) {
            return;
        }
        mSelection.set(mSelection.getStartLine(), mSelection.getStartCol(), cell[0], cell[1]);
        invalidate();
    }

    private int[] cellAt(float x, float y) {
        if (mSession == null) {
            return null;
        }
        synchronized (mSession.getBufferLock()) {
            int topLine = Math.max(0, mBuffer.getVisibleStart() - mScrollOffset);
            int line = topLine + (int) (y / mRenderer.getLineHeight());
            int col = (int) (x / mRenderer.getCharWidth());
            line = Math.max(0, Math.min(mBuffer.getLineCount() - 1, line));
            col = Math.max(0, Math.min(mBuffer.getColumns() - 1, col));
            return new int[] { line, col };
        }
    }

    private void copyToClipboard(String text) {
        if (text == null || text.length() == 0) {
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(
                Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            AppLog.appendLine(AppLog.TERMINAL, "copy chars=" + text.length());
            clipboard.setPrimaryClip(ClipData.newPlainText("BionicShell terminal output", text));
            Toast.makeText(getContext(), "Terminal output copied", Toast.LENGTH_SHORT).show();
        }
    }
}
