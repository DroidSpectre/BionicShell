package dev.bionicshell;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class ScreenBufferTest {
    private static void write(ScreenBuffer buffer, String text) {
        int index = 0;
        while (index < text.length()) {
            int codePoint = text.codePointAt(index);
            if (codePoint == '\r') {
                buffer.carriageReturn();
            } else if (codePoint == '\n') {
                buffer.lineFeed();
            } else {
                buffer.putChar(codePoint);
            }
            index += Character.charCount(codePoint);
        }
    }

    @Test
    public void writesWrapsAndTracksCursor() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "abcdef");
        assertEquals("abcd", buffer.getLineTextAbsolute(0));
        assertEquals("ef", buffer.getLineTextAbsolute(1));
        assertEquals(1, buffer.getCursorRow());
        assertEquals(2, buffer.getCursorCol());
        assertTrue(buffer.isWrapped(0));
    }

    @Test
    public void handlesCarriageReturnAndLineFeed() {
        ScreenBuffer buffer = new ScreenBuffer(2, 8);
        write(buffer, "ab\r\ncd");
        assertEquals("ab", buffer.getLineTextAbsolute(0));
        assertEquals("cd", buffer.getLineTextAbsolute(1));
        assertEquals(1, buffer.getCursorRow());
        assertEquals(2, buffer.getCursorCol());
    }

    @Test
    public void scrollsAndKeepsHistory() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "a\r\nb\r\nc\r\nd");
        assertEquals("c", buffer.getVisibleLineText(0));
        assertEquals("d", buffer.getVisibleLineText(1));
        assertEquals(2, buffer.getScrollbackCount());
        assertEquals("a\nb\nc\nd", buffer.copyAll());
    }

    @Test
    public void copyPreservesSpacesAtWrappedBoundary() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "abc def");
        assertEquals("abc def", buffer.copyAll());
        assertEquals("abc def", buffer.getSelectedText(0, 0, 1, 3));
    }

    @Test
    public void alternateScreenRestoresMainScreen() {
        ScreenBuffer buffer = new ScreenBuffer(2, 8);
        write(buffer, "main");
        buffer.enterAltScreen();
        write(buffer, "alt");
        assertEquals("alt", buffer.getLineTextAbsolute(0));
        buffer.leaveAltScreen();
        assertEquals("main", buffer.getLineTextAbsolute(0));
        assertFalse(buffer.isAltScreen());
    }

    @Test
    public void selectionJoinsWrappedRowsWithoutNewline() {
        ScreenBuffer buffer = new ScreenBuffer(2, 3);
        write(buffer, "abcdef");
        assertEquals("abcdef", buffer.getSelectedText(0, 0, 1, 3));
    }

    @Test
    public void selectionUsesNewlinesForUnwrappedRows() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "ab\r\ncd");
        assertEquals("ab\ncd", buffer.getSelectedText(0, 0, 1, 2));
    }

    @Test
    public void eraseInLineClearsFromCursor() {
        ScreenBuffer buffer = new ScreenBuffer(1, 8);
        write(buffer, "abcdef");
        buffer.setCursor(0, 2);
        buffer.eraseInLine(0);
        assertEquals("ab", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void insertAndDeleteCharsShiftWithinRow() {
        ScreenBuffer buffer = new ScreenBuffer(1, 8);
        write(buffer, "abcdef");
        buffer.setCursor(0, 2);
        buffer.insertChars(2);
        assertEquals("ab  cdef", buffer.getLineTextAbsolute(0));
        buffer.deleteChars(3);
        assertEquals("abdef", buffer.getLineTextAbsolute(0));
    }

    @Test
    public void scrollRegionLeavesRowsOutsideRegionUntouched() {
        ScreenBuffer buffer = new ScreenBuffer(3, 8);
        write(buffer, "top\r\nmid\r\nbot");
        buffer.setScrollRegion(1, 2);
        buffer.setCursor(2, 0);
        buffer.lineFeed();
        assertEquals("top", buffer.getLineTextAbsolute(0));
        assertEquals("bot", buffer.getLineTextAbsolute(1));
        assertEquals("", buffer.getLineTextAbsolute(2));
    }

    @Test
    public void resizePreservesRecentLines() {
        ScreenBuffer buffer = new ScreenBuffer(3, 4);
        write(buffer, "one\r\ntwo\r\nthree\r\nfour");
        buffer.resize(2, 4);
        assertEquals("four", buffer.getVisibleLineText(1));
        assertTrue(buffer.getLineCount() >= 2);
    }

    @Test
    public void resizeRewrapsWrappedRowsToNarrowerWidth() {
        ScreenBuffer buffer = new ScreenBuffer(1, 8);
        write(buffer, "abcdefgh");
        buffer.resize(3, 4);
        assertEquals("abcd", buffer.getLineTextAbsolute(0));
        assertEquals("efgh", buffer.getLineTextAbsolute(1));
        assertEquals(1, buffer.getCursorRow());
        assertEquals(3, buffer.getCursorCol());
        assertTrue(buffer.isWrapped(0));
    }

    @Test
    public void resizeReflowsScrollbackToWiderWidth() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "abcdefghij");
        buffer.resize(2, 8);
        assertEquals("abcdefgh", buffer.getLineTextAbsolute(0));
        assertEquals("ij", buffer.getLineTextAbsolute(1));
        assertEquals(1, buffer.getCursorRow());
        assertEquals(2, buffer.getCursorCol());
        assertTrue(buffer.isWrapped(0));
    }

    @Test
    public void resizeKeepsHardLineBreaks() {
        ScreenBuffer buffer = new ScreenBuffer(4, 8);
        write(buffer, "abcdefgh\r\nij");
        buffer.resize(4, 4);
        assertEquals("abcd", buffer.getLineTextAbsolute(0));
        assertEquals("efgh", buffer.getLineTextAbsolute(1));
        assertEquals("ij", buffer.getLineTextAbsolute(2));
        assertTrue(buffer.isWrapped(0));
        assertFalse(buffer.isWrapped(1));
    }

    @Test
    public void resizePreservesCellStyles() {
        ScreenBuffer buffer = new ScreenBuffer(1, 4);
        buffer.setStyle(2, 3, ScreenBuffer.FLAG_BOLD);
        write(buffer, "abcdef");
        buffer.resize(2, 3);
        assertEquals(2, buffer.getFgAt(1, 0));
        assertEquals(3, buffer.getBgAt(1, 0));
        assertEquals(ScreenBuffer.FLAG_BOLD, buffer.getFlagsAt(1, 0));
    }

    @Test
    public void resizeDoesNotSplitWideCharacter() {
        ScreenBuffer buffer = new ScreenBuffer(1, 4);
        write(buffer, "a\u4e2d");
        buffer.resize(1, 3);
        assertEquals('a', buffer.getCodePointAt(0, 0));
        assertEquals(0x4e2d, buffer.getCodePointAt(0, 1));
        assertEquals(0, buffer.getCodePointAt(0, 2));
        assertTrue((buffer.getFlagsAt(0, 1) & ScreenBuffer.FLAG_WIDE) != 0);
    }

    @Test
    public void growingRowsKeepsContentAtTop() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "a\r\nb");
        buffer.resize(4, 4);
        assertEquals("a", buffer.getVisibleLineText(0));
        assertEquals("b", buffer.getVisibleLineText(1));
        assertEquals("", buffer.getVisibleLineText(2));
        assertEquals("", buffer.getVisibleLineText(3));
        assertEquals(1, buffer.getCursorRow());
    }

    @Test
    public void shrinkingRowsTrimsBlankRowsBelowCursor() {
        ScreenBuffer buffer = new ScreenBuffer(4, 4);
        write(buffer, "a");
        buffer.resize(2, 4);
        assertEquals("a", buffer.getVisibleLineText(0));
        assertEquals("", buffer.getVisibleLineText(1));
        assertEquals(0, buffer.getCursorRow());
    }

    @Test
    public void layoutThenKeyboardResizeKeepsPromptAtTop() {
        ScreenBuffer buffer = new ScreenBuffer(24, 80);
        write(buffer, "$ ");
        buffer.resize(39, 46);
        buffer.resize(20, 46);
        assertEquals("$", buffer.getVisibleLineText(0));
        assertEquals(0, buffer.getCursorRow());
    }

    @Test
    public void growingRowsRevealsScrollbackAbove() {
        ScreenBuffer buffer = new ScreenBuffer(2, 4);
        write(buffer, "a\r\nb\r\nc\r\nd\r\ne");
        buffer.resize(4, 4);
        assertEquals("b", buffer.getVisibleLineText(0));
        assertEquals("c", buffer.getVisibleLineText(1));
        assertEquals("d", buffer.getVisibleLineText(2));
        assertEquals("e", buffer.getVisibleLineText(3));
        assertEquals(3, buffer.getCursorRow());
    }

    @Test
    public void shrinkingRowsFollowsCursorToBottom() {
        ScreenBuffer buffer = new ScreenBuffer(4, 4);
        write(buffer, "a\r\nb\r\nc\r\nd");
        buffer.resize(2, 4);
        assertEquals("c", buffer.getVisibleLineText(0));
        assertEquals("d", buffer.getVisibleLineText(1));
        assertEquals(1, buffer.getCursorRow());
    }
}
