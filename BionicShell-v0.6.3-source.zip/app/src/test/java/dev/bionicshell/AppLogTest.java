package dev.bionicshell;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public final class AppLogTest {
    @Test
    public void appendsLinesAndClears() {
        AppLog.clearAll();
        AppLog.appendLine("one");
        AppLog.appendLine("two");
        String text = AppLog.read();
        assertTrue(text.contains("one"));
        assertTrue(text.contains("two"));
        assertTrue(text.endsWith("\n"));
        AppLog.clear();
        assertEquals("", AppLog.read());
    }

    @Test
    public void channelsAreSeparate() {
        AppLog.clearAll();
        AppLog.appendLine(AppLog.SYSTEM, "system");
        AppLog.appendLine(AppLog.TERMINAL, "terminal");
        AppLog.appendLine(AppLog.SERVER, "server");
        assertTrue(AppLog.read(AppLog.SYSTEM).contains("system"));
        assertFalse(AppLog.read(AppLog.SYSTEM).contains("terminal"));
        assertTrue(AppLog.read(AppLog.TERMINAL).contains("terminal"));
        assertFalse(AppLog.read(AppLog.TERMINAL).contains("server"));
        assertTrue(AppLog.read(AppLog.SERVER).contains("server"));
        AppLog.clearAll();
    }

    @Test
    public void redactsSecrets() {
        assertEquals("key=[redacted]", AppLog.redact("key=secret123", "secret123"));
        assertEquals("short", AppLog.redact("short", "abc"));
        assertEquals("", AppLog.redact(null, "secret123"));
    }

    @Test
    public void truncatesOldContent() {
        AppLog.clear();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < AppLog.MAX_CHARS + 100; i++) {
            text.append('x');
        }
        AppLog.append(text.toString());
        assertTrue(AppLog.read().length() <= AppLog.MAX_CHARS);
        assertTrue(AppLog.read().endsWith("x"));
    }
}
