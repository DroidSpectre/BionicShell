package dev.bionicshell;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LlamaArgsTest {
    private static List<String> args(boolean reasoning) {
        return LlamaArgs.build("/data/app/lib/liblauncher.so", "/models/model.gguf", 8080,
                4096, 4, 0, "test-api-key", 0.7, reasoning);
    }

    private static String valueAfter(List<String> args, String key) {
        int index = args.indexOf(key);
        assertTrue("missing " + key, index >= 0);
        assertTrue("missing value for " + key, index + 1 < args.size());
        return args.get(index + 1);
    }

    @Test
    public void reasoningOnIsExplicit() {
        assertEquals("on", valueAfter(args(true), "--reasoning"));
    }

    @Test
    public void reasoningOffIsExplicit() {
        assertEquals("off", valueAfter(args(false), "--reasoning"));
    }

    @Test
    public void keepsServerArguments() {
        List<String> args = args(true);
        assertEquals("llama-server", args.get(1));
        assertEquals("/models/model.gguf", valueAfter(args, "-m"));
        assertEquals("127.0.0.1", valueAfter(args, "--host"));
        assertEquals("8080", valueAfter(args, "--port"));
        assertEquals("test-api-key", valueAfter(args, "--api-key"));
    }
}
