#!/usr/bin/env python3
"""Gradle-free build for BionicShell.

Pipeline: aapt2 -> ECJ -> D8 -> apksigner, matching CodeAssist's native Android
build model. Unit tests run on a portable Temurin JRE with JUnit 4.
"""

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
BUILD = ROOT / "build"
DIST = ROOT / "dist"
RELEASES = ROOT / "releases"

SDK = Path(os.environ.get("ANDROID_HOME", "/opt/android-sdk"))
BUILD_TOOLS = SDK / "build-tools" / "36.0.0"
AAPT2 = BUILD_TOOLS / "aapt2"
ZIPALIGN = BUILD_TOOLS / "zipalign"
D8_JAR = BUILD_TOOLS / "lib" / "d8.jar"
APKSIGNER_JAR = BUILD_TOOLS / "lib" / "apksigner.jar"
ANDROID_JAR = SDK / "platforms" / "android-36" / "android.jar"

JAVA_HOME = Path(os.environ.get("JAVA_HOME", "/opt/jdk-17.0.20.1+1-jre"))
JAVA = JAVA_HOME / "bin" / "java"
TOOLCHAIN = Path(os.environ.get("BIONIC_BUILD_TOOLCHAIN", "/opt/bionic-build"))
ECJ_JAR = TOOLCHAIN / "lib" / "ecj-3.40.0.jar"
JUNIT_JAR = TOOLCHAIN / "lib" / "junit-4.13.2.jar"
HAMCREST_JAR = TOOLCHAIN / "lib" / "hamcrest-core-1.3.jar"

DEBUG_KEYSTORE = Path(os.environ.get("BIONIC_KEYSTORE", str(Path.home() / ".android" / "debug.keystore")))
DEBUG_ALIAS = os.environ.get("BIONIC_KEY_ALIAS", "androiddebugkey")
DEBUG_KEY_PASS = os.environ.get("BIONIC_KEY_PASS", "android")
DEBUG_STORE_PASS = os.environ.get("BIONIC_STORE_PASS", "android")

LLAMA_FILES = (
    "libllama-cli.so",
    "libllama-server.so",
    "libllama-cli-impl.so",
    "libllama-server-impl.so",
    "libllama-common.so",
    "libllama.so",
    "libmtmd.so",
    "libggml.so",
    "libggml-base.so",
    "libggml-cpu-android_armv8.0_1.so",
    "libggml-cpu-android_armv8.2_1.so",
    "libggml-cpu-android_armv8.2_2.so",
    "libggml-cpu-android_armv8.6_1.so",
    "libggml-cpu-android_armv9.0_1.so",
    "libggml-cpu-android_armv9.2_1.so",
    "libggml-cpu-android_armv9.2_2.so",
)

ENV = dict(os.environ)
ENV.setdefault("TZ", "UTC")
ENV.setdefault("LC_ALL", "C.UTF-8")


def log(message):
    print("[build] " + message, flush=True)


def run(args, cwd=ROOT, capture=False):
    log(" ".join(str(a) for a in args))
    result = subprocess.run([str(a) for a in args], cwd=str(cwd), env=ENV,
                            text=True, capture_output=capture)
    if capture:
        if result.stdout:
            print(result.stdout, end="")
        if result.stderr:
            print(result.stderr, end="", file=sys.stderr)
    if result.returncode != 0:
        raise SystemExit(result.returncode)
    return result


def read_version():
    values = {}
    path = APP / "version.properties"
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    if "versionCode" not in values or "versionName" not in values:
        raise SystemExit("app/version.properties must define versionCode and versionName")
    return int(values["versionCode"]), values["versionName"]


def require_tools():
    missing = []
    for path in (AAPT2, ZIPALIGN, D8_JAR, APKSIGNER_JAR, ANDROID_JAR,
                 JAVA, ECJ_JAR, JUNIT_JAR, HAMCREST_JAR):
        if not path.exists():
            missing.append(str(path))
    if missing:
        raise SystemExit("missing build tool(s):\n  " + "\n  ".join(missing))


def reset_build():
    if BUILD.exists():
        shutil.rmtree(BUILD)
    BUILD.mkdir(parents=True)


def java_sources():
    return sorted((APP / "src" / "main" / "java").rglob("*.java"))


def test_sources():
    return sorted((APP / "src" / "test" / "java").rglob("*.java"))


def instrument_sources():
    return sorted((APP / "src" / "androidTest" / "java").rglob("*.java"))


def ecj(sources, output, classpath=()):
    output.mkdir(parents=True, exist_ok=True)
    args = [JAVA, "-jar", ECJ_JAR, "-encoding", "UTF-8", "-source", "1.8",
            "-target", "1.8", "-proc:none", "-nowarn",
            "-bootclasspath", ANDROID_JAR, "-d", output]
    if classpath:
        args += ["-cp", os.pathsep.join(str(p) for p in classpath)]
    args += [str(p) for p in sources]
    run(args)


def compile_main():
    gen = BUILD / "gen"
    compiled = BUILD / "compiled"
    classes = BUILD / "classes"
    apk_dir = BUILD / "apk"
    for directory in (gen, compiled, classes, apk_dir):
        directory.mkdir(parents=True, exist_ok=True)

    version_code, version_name = read_version()
    res = APP / "src" / "main" / "res"
    if res.is_dir():
        run([AAPT2, "compile", "--dir", res, "-o", BUILD / "resources.zip"])
        run([AAPT2, "link", "-o", apk_dir / "unsigned.apk", "-I", ANDROID_JAR,
             "--manifest", APP / "src" / "main" / "AndroidManifest.xml",
             "--java", gen, "--min-sdk-version", "26", "--target-sdk-version", "36",
             "--version-code", str(version_code), "--version-name", version_name,
             BUILD / "resources.zip"])
    else:
        run([AAPT2, "link", "-o", apk_dir / "unsigned.apk", "-I", ANDROID_JAR,
             "--manifest", APP / "src" / "main" / "AndroidManifest.xml",
             "--java", gen, "--min-sdk-version", "26", "--target-sdk-version", "36",
             "--version-code", str(version_code), "--version-name", version_name])
    sources = java_sources() + sorted(gen.rglob("*.java"))
    ecj(sources, classes)
    return classes


def compile_test_classes(classes):
    test_classes = BUILD / "test-classes"
    ecj(test_sources(), test_classes, [classes, JUNIT_JAR, HAMCREST_JAR])
    return test_classes


def test_names(test_classes):
    names = []
    for path in test_classes.rglob("*Test.class"):
        rel = path.relative_to(test_classes).with_suffix("")
        names.append(str(rel).replace(os.sep, "."))
    return sorted(names)


def run_tests(selected=()):
    classes = compile_main()
    test_classes = compile_test_classes(classes)
    names = test_names(test_classes)
    if selected:
        names = [name for name in names if any(name == s or name.endswith("." + s) for s in selected)]
    if not names:
        raise SystemExit("no test classes found" + ((" for " + ", ".join(selected)) if selected else ""))
    log("running %d test class(es): %s" % (len(names), ", ".join(names)))
    run([JAVA, "-cp", os.pathsep.join([str(test_classes), str(classes),
                                       str(JUNIT_JAR), str(HAMCREST_JAR)]),
         "org.junit.runner.JUnitCore"] + names)
    return classes


def dex(classes):
    dex_dir = BUILD / "dex"
    dex_dir.mkdir(parents=True, exist_ok=True)
    class_files = sorted(classes.rglob("*.class"))
    if not class_files:
        raise SystemExit("no compiled classes to dex")
    run([JAVA, "-cp", D8_JAR, "com.android.tools.r8.D8", "--min-api", "26",
         "--lib", ANDROID_JAR, "--output", dex_dir] + class_files)
    return dex_dir / "classes.dex"


def add_tree(zf, source_dir, prefix):
    if not source_dir.is_dir():
        return
    for path in sorted(source_dir.rglob("*")):
        if path.is_file():
            zf.write(path, prefix + "/" + path.relative_to(source_dir).as_posix(),
                     compress_type=zipfile.ZIP_STORED if prefix.endswith("lib/arm64-v8a") else zipfile.ZIP_DEFLATED)


def package_apk(classes_dex, output):
    unsigned = BUILD / "apk" / "unsigned.apk"
    with_dex = BUILD / "apk" / "with-dex.apk"
    aligned = BUILD / "apk" / "aligned.apk"
    shutil.copyfile(unsigned, with_dex)
    with zipfile.ZipFile(with_dex, "a") as zf:
        zf.write(classes_dex, "classes.dex", compress_type=zipfile.ZIP_DEFLATED)
        add_tree(zf, APP / "src" / "main" / "assets", "assets")
        add_tree(zf, APP / "src" / "main" / "jniLibs", "lib")
    run([ZIPALIGN, "-f", "-p", "4", with_dex, aligned])
    output.parent.mkdir(parents=True, exist_ok=True)
    run([JAVA, "-jar", APKSIGNER_JAR, "sign",
         "--ks", DEBUG_KEYSTORE, "--ks-key-alias", DEBUG_ALIAS,
         "--ks-pass", "pass:" + DEBUG_STORE_PASS, "--key-pass", "pass:" + DEBUG_KEY_PASS,
         "--out", output, aligned])
    run([JAVA, "-jar", APKSIGNER_JAR, "verify", "--print-certs", output], capture=True)
    return output


def build_native():
    run([sys.executable, ROOT / "scripts" / "build_native.py"], cwd=ROOT)


def verify_payload():
    payload = APP / "src" / "main" / "jniLibs" / "arm64-v8a"
    missing = [name for name in LLAMA_FILES if not (payload / name).is_file()]
    if missing:
        raise SystemExit("missing llama.cpp payload: " + ", ".join(missing) +
                         "\nrun: python3 scripts/fetch_llama.py --variant generic")


def build_apk():
    build_native()
    verify_payload()
    classes = compile_main()
    classes_dex = dex(classes)
    version_code, version_name = read_version()
    output = DIST / ("BionicShell-v%s.apk" % version_name)
    package_apk(classes_dex, output)
    limit = 35 * 1024 * 1024
    if output.stat().st_size > limit:
        raise SystemExit("APK exceeds 35 MiB: %d bytes" % output.stat().st_size)
    log("APK: %s (%d bytes)" % (output, output.stat().st_size))
    return output


def source_files():
    excluded_parts = {".git", "build", "dist", "releases", "__pycache__", ".gradle", ".cxx",
                      "jniLibs"}
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if not path.is_file() or any(part in excluded_parts for part in rel.parts):
            continue
        if path.suffix in (".apk", ".dex", ".class", ".pyc"):
            continue
        if path == ROOT / "BUILD.txt":
            continue
        yield path


def archive_release(apk):
    version_code, version_name = read_version()
    out = RELEASES / ("v" + version_name)
    out.mkdir(parents=True, exist_ok=True)
    apk_copy = out / apk.name
    shutil.copyfile(apk, apk_copy)
    source_zip = out / ("BionicShell-v%s-source.zip" % version_name)
    with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in source_files():
            zf.write(path, path.relative_to(ROOT).as_posix())
        zf.writestr("BUILD.txt", "versionCode=%d\nversionName=%s\nbuilt=%s\n" %
                    (version_code, version_name, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())))
    downloads = Path(os.environ.get("BIONIC_DOWNLOADS", "/sdcard/Download/BionicShell")) / ("v" + version_name)
    downloads.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(apk_copy, downloads / apk_copy.name)
    shutil.copyfile(source_zip, downloads / source_zip.name)
    log("archive: %s" % out)
    log("export:  %s" % downloads)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", nargs="?", default="apk",
                        choices=["apk", "test", "check", "release", "clean", "info"])
    parser.add_argument("tests", nargs="*")
    args = parser.parse_args()
    require_tools()
    if args.command == "clean":
        for path in (BUILD, DIST):
            if path.exists():
                shutil.rmtree(path)
        return
    if args.command == "info":
        code, name = read_version()
        print("versionCode=%d\nversionName=%s\napk=%s" % (code, name, DIST / ("BionicShell-v%s.apk" % name)))
        return
    if args.command == "test":
        reset_build()
        run([sys.executable, str(ROOT / "scripts" / "test_check_java6.py")], cwd=ROOT / "scripts")
        run([sys.executable, str(ROOT / "scripts" / "test_fetch_llama.py")], cwd=ROOT / "scripts")
        run_tests(args.tests)
        return
    if args.command in ("apk", "check", "release"):
        reset_build()
        if args.command != "apk":
            run([sys.executable, str(ROOT / "scripts" / "test_check_java6.py")], cwd=ROOT / "scripts")
            run([sys.executable, str(ROOT / "scripts" / "test_fetch_llama.py")], cwd=ROOT / "scripts")
            run([sys.executable, str(ROOT / "scripts" / "check_java6.py"),
                 str(APP / "src" / "main" / "java")])
            run_tests()
        apk = build_apk()
        if args.command == "release":
            archive_release(apk)
        return


if __name__ == "__main__":
    main()
